plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.mymoney.tracker"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.mymoney.tracker"
        minSdk = 26
        targetSdk = 34
        versionCode = 10
        versionName = "1.9"
    }
    signingConfigs {
        create("fixed") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
        release { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }

    // user = সাধারণ ইউজারের অ্যাপ ("My Hisab"); master = ডেভেলপার/অ্যাডমিনের মাস্টার অ্যাপ ("Hisab")
    flavorDimensions += "edition"
    productFlavors {
        create("user") {
            dimension = "edition"
            buildConfigField("boolean", "IS_MASTER", "false")
            resValue("string", "app_name", "My Hisab")
        }
        create("master") {
            dimension = "edition"
            applicationId = "com.mymoney.hisab"
            buildConfigField("boolean", "IS_MASTER", "true")
            resValue("string", "app_name", "Hisab")
        }
    }
}

// google-services.json-এ com.mymoney.hisab না থাকলে মাস্টার সংস্করণ বিল্ড হবে না (ইউজার অ্যাপ ঠিকই বিল্ড হবে)
androidComponents {
    beforeVariants { variant ->
        val gs = file("google-services.json")
        val ok = gs.exists() && gs.readText().contains("com.mymoney.hisab")
        if (variant.productFlavors.any { it.second == "master" } && !ok) variant.enable = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.fragment:fragment:1.8.1")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.3")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.8.1")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    val room = "2.6.1"
    implementation("androidx.room:room-runtime:$room")
    implementation("androidx.room:room-ktx:$room")
    ksp("androidx.room:room-compiler:$room")
}

// google-services.json থাকলেই Firebase চালু হবে
if (file("google-services.json").exists()) {
    apply(plugin = "com.google.gms.google-services")
}
