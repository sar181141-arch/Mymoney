package com.mymoney.tracker.notify

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.mymoney.tracker.data.AppDb
import com.mymoney.tracker.data.Prefs
import com.mymoney.tracker.data.debtorRemaining
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.util.Locale
import java.util.concurrent.TimeUnit

/** প্রতিদিন সকাল ৯টায় চলে; আজ যাদের PTP তারিখ এবং আজ তারিখ দেওয়া পরিকল্পিত ব্যয়ের জন্য নোটিফিকেশন দেয় */
class PtpWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    private fun toDate(ms: Long): LocalDate = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate()

    @SuppressLint("MissingPermission")
    override suspend fun doWork(): Result {
        val app = applicationContext
        val dao = AppDb.get(app).dao()
        val today = LocalDate.now()
        val pays = dao.debtorPaymentsOnce()
        val due = dao.debtorsOnce().filter { d ->
            val p = d.ptpMillis
            !d.closed && p != null && toDate(p) == today
        }
        val planned = dao.plannedOnce().filter { it.hasDate && !it.done && toDate(it.dueMillis) == today }
        if (due.isEmpty() && planned.isEmpty()) return Result.success()
        val nm = NotificationManagerCompat.from(app)
        if (!nm.areNotificationsEnabled()) return Result.success()
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Reminders", NotificationManager.IMPORTANCE_HIGH)
            app.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        val bn = Prefs(app).read().lang == "bn"
        val launch = app.packageManager.getLaunchIntentForPackage(app.packageName) ?: android.content.Intent()
        val pi = PendingIntent.getActivity(app, 0, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        fun show(id: Int, title: String, text: String) {
            val n = NotificationCompat.Builder(app, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(id, n)
        }

        for (d in due) {
            val rem = String.format(Locale("en", "IN"), "%,.2f", debtorRemaining(d, pays))
            show(
                d.id.toInt() + 1000,
                if (bn) "আজ PTP তারিখ: ${d.name}" else "PTP due today: ${d.name}",
                if (bn) "বাকি ₹$rem ফেরত পাওয়ার কথা আজ।" else "₹$rem is due to be returned today."
            )
        }
        for (p in planned) {
            val amt = String.format(Locale("en", "IN"), "%,.2f", p.amount)
            val label = p.note.ifBlank { p.category }
            show(
                p.id.toInt() + 100000,
                if (bn) "আজ পরিকল্পিত ব্যয়: $label" else "Planned expense today: $label",
                "₹$amt"
            )
        }
        return Result.success()
    }

    companion object {
        private const val CHANNEL = "ptp"

        fun schedule(ctx: Context) {
            val now = LocalDateTime.now()
            var next = now.toLocalDate().atTime(9, 0)
            if (!next.isAfter(now)) next = next.plusDays(1)
            val delayMin = Duration.between(now, next).toMinutes()
            val req = PeriodicWorkRequestBuilder<PtpWorker>(1, TimeUnit.DAYS)
                .setInitialDelay(delayMin, TimeUnit.MINUTES)
                .build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("ptp_daily", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
