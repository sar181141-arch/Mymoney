package com.mymoney.tracker.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.mymoney.tracker.data.*
import java.time.LocalDate

private fun numText(d: Double): String = if (d % 1.0 == 0.0) d.toLong().toString() else d.toString()

private fun smsBody(bn: Boolean, debtor: String, owner: String, remaining: Double, ptp: String): String =
    if (bn) "প্রিয় $debtor, আপনি $owner এর কাছ থেকে নেওয়া ${money(remaining)}" +
        (if (ptp.isNotEmpty()) " $ptp তারিখের মধ্যে" else "") + " ফেরত দিন। ধন্যবাদ।"
    else "Dear $debtor, please return ${money(remaining)} to $owner" +
        (if (ptp.isNotEmpty()) " by $ptp" else "") + ". Thank you."

// ---------------- ঋণগ্রহীতার তালিকা ----------------
@Composable
fun DebtorsScreen(
    debtors: List<Debtor>, pays: List<DebtorPayment>, onSave: (Debtor) -> Unit, onOpen: (Long) -> Unit
) {
    val ctx = LocalContext.current
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    var showClosed by remember { mutableStateOf(false) }
    var adding by remember { mutableStateOf(false) }
    val today = LocalDate.now()
    val list = debtors.filter { it.closed == showClosed }
    val totalOpen = debtors.filter { !it.closed }.sumOf { debtorRemaining(it, pays) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { StatCard(tr("মোট পাওনা (চলমান)", "Total receivable (open)"), totalOpen, Modifier.fillMaxWidth(), Green) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(!showClosed, { showClosed = false }, { Text(tr("চলমান", "Open")) })
                FilterChip(showClosed, { showClosed = true }, { Text(tr("বন্ধ", "Closed")) })
            }
        }
        if (list.isEmpty()) item { Text(tr("কোনো ঋণগ্রহীতা নেই", "No debtors here")) }
        items(list, key = { it.id }) { d ->
            val rem = debtorRemaining(d, pays)
            val ptp = d.ptpMillis?.let { millisToDate(it) }
            Card(Modifier.fillMaxWidth().clickable { onOpen(d.id) }) {
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(d.name, fontWeight = FontWeight.Bold)
                        if (d.mobile.isNotBlank()) Text(d.mobile, style = MaterialTheme.typography.bodySmall)
                        if (ptp != null && !d.closed) {
                            Text("PTP: " + fmt(ptp, "dd MMM yyyy"),
                                color = if (ptp.isBefore(today)) Red else Color.Unspecified,
                                style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    if (d.closed) Text(tr("বন্ধ ✅", "Closed ✅"), color = Green, fontWeight = FontWeight.Bold)
                    else Text(money(rem), fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Button({ adding = true }, Modifier.fillMaxWidth()) { Text(tr("+ নতুন ঋণগ্রহীতা", "+ New debtor")) }
        }
    }
    if (adding) {
        DebtorDialog(null, { d ->
            onSave(d)
            adding = false
            if (d.ptpMillis != null && Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }) { adding = false }
    }
}

@Composable
fun DebtorDialog(existing: Debtor?, onSave: (Debtor) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var mobile by remember { mutableStateOf(existing?.mobile ?: "") }
    var amount by remember { mutableStateOf(existing?.amount?.let { numText(it) } ?: "") }
    var date by remember { mutableStateOf<Long?>(existing?.dateMillis ?: LocalDate.now().toMillis()) }
    var ptp by remember { mutableStateOf<Long?>(existing?.ptpMillis) }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    var error by remember { mutableStateOf<String?>(null) }
    val errName = tr("নাম লিখুন", "Enter the name")
    val errAmt = tr("সঠিক টাকার পরিমাণ দিন", "Enter a valid amount")

    fun save() {
        val amt = amount.toDoubleOrNull()
        if (name.isBlank()) { error = errName; return }
        if (amt == null || amt <= 0) { error = errAmt; return }
        onSave(
            (existing ?: Debtor(name = "", amount = 0.0, dateMillis = 0)).copy(
                name = name.trim(), mobile = mobile.trim(), amount = amt,
                dateMillis = date ?: LocalDate.now().toMillis(), ptpMillis = ptp, note = note.trim()
            )
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("নতুন ঋণগ্রহীতা", "New debtor") else tr("ঋণগ্রহীতা সম্পাদনা", "Edit debtor")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text(tr("ঋণগ্রহীতার নাম", "Debtor name")) })
                OutlinedTextField(mobile, { mobile = it }, singleLine = true, label = { Text(tr("মোবাইল নম্বর", "Mobile number")) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                OutlinedTextField(amount, { amount = it }, singleLine = true, label = { Text(tr("টাকার পরিমাণ (₹)", "Amount (₹)")) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                DateField(tr("দেওয়ার তারিখ", "Date given"), date, { date = it })
                DateField(tr("PTP তারিখ", "PTP date"), ptp, { ptp = it }, clearable = true)
                OutlinedTextField(note, { note = it }, label = { Text(tr("নোট (ঐচ্ছিক)", "Note (optional)")) })
                error?.let { Text(it, color = Red) }
            }
        },
        confirmButton = { TextButton({ save() }) { Text(tr("সেভ", "Save")) } },
        dismissButton = { TextButton(onDismiss) { Text(tr("বাতিল", "Cancel")) } }
    )
}

// ---------------- ঋণগ্রহীতার বিবরণ, পেমেন্ট, SMS এলার্ট ----------------
@Composable
fun DebtorDetailScreen(
    d: Debtor, pays: List<DebtorPayment>, ownerName: String, bn: Boolean,
    onSave: (Debtor) -> Unit, onPay: (Double, Boolean, Long?) -> Unit, onDelete: () -> Unit
) {
    val ctx = LocalContext.current
    val mine = pays.filter { it.debtorId == d.id }.sortedBy { it.dateMillis }
    val paid = mine.sumOf { it.amount }
    val rem = debtorRemaining(d, pays)
    var payMode by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf(false) }
    var confirmDel by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<String?>(null) }
    val noMobile = tr("এই ঋণগ্রহীতার মোবাইল নম্বর নেই", "No mobile number for this debtor")

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(d.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                if (d.mobile.isNotBlank()) Text(d.mobile)
                Text(tr("দেওয়া: ", "Given: ") + money(d.amount) + " · " + fmt(millisToDate(d.dateMillis), "dd MMM yyyy"))
                Text(tr("ফেরত পেয়েছি: ", "Received: ") + money(paid))
                if (d.closed) {
                    Text(tr("বন্ধ ✅ (সম্পূর্ণ পরিশোধ)", "Closed ✅ (fully paid)"), color = Green, fontWeight = FontWeight.Bold)
                } else {
                    Text(tr("বাকি: ", "Remaining: ") + money(rem), color = Red,
                        style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("PTP: " + (d.ptpMillis?.let { fmt(millisToDate(it), "dd MMM yyyy") } ?: "—"))
                }
                if (d.note.isNotBlank()) Text(d.note, style = MaterialTheme.typography.bodySmall)
            }
        }
        if (!d.closed) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ payMode = "part" }, Modifier.weight(1f)) { Text(tr("পার্ট পেমেন্ট", "Part payment")) }
                Button({ payMode = "full" }, Modifier.weight(1f)) { Text(tr("ফুল পেমেন্ট", "Full payment")) }
            }
            DateField("PTP", d.ptpMillis, { onSave(d.copy(ptpMillis = it)) }, clearable = true)
            OutlinedButton({
                if (d.mobile.isBlank()) {
                    info = noMobile
                } else {
                    val ptp = d.ptpMillis?.let { fmt(millisToDate(it), "dd MMM yyyy") } ?: ""
                    val who = ownerName.ifBlank { if (bn) "আমার" else "me" }
                    val body = smsBody(bn, d.name, who, rem, ptp)
                    try {
                        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(d.mobile)))
                        i.putExtra("sms_body", body)
                        ctx.startActivity(i)
                    } catch (e: Exception) {
                        info = noMobile
                    }
                }
            }, Modifier.fillMaxWidth()) { Text("✉ " + tr("SMS এলার্ট পাঠান", "Send SMS alert")) }
        }
        info?.let { Text(it, color = Red) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton({ editing = true }, Modifier.weight(1f)) { Text(tr("সম্পাদনা", "Edit")) }
            OutlinedButton({ confirmDel = true }, Modifier.weight(1f)) { Text(tr("মুছুন", "Delete"), color = Red) }
        }
        Text(tr("ফেরত পাওয়ার ইতিহাস", "Payment history"), style = MaterialTheme.typography.titleSmall)
        if (mine.isEmpty()) Text(tr("এখনও কিছু ফেরত পাওয়া যায়নি", "Nothing received yet"), style = MaterialTheme.typography.bodySmall)
        mine.forEach { p ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(fmt(millisToDate(p.dateMillis), "dd MMM yyyy") + " · " +
                    if (p.isFull) tr("ফুল", "Full") else tr("পার্ট", "Part"))
                Text(money(p.amount), color = Green, fontWeight = FontWeight.Bold)
            }
        }
    }

    if (payMode.isNotEmpty()) {
        PayDialog(payMode == "full", rem, { amt, newPtp -> onPay(amt, payMode == "full", newPtp); payMode = "" }) { payMode = "" }
    }
    if (editing) DebtorDialog(d, { onSave(it); editing = false }) { editing = false }
    if (confirmDel) {
        AlertDialog(
            onDismissRequest = { confirmDel = false },
            title = { Text(tr("এই ঋণগ্রহীতাকে মুছবেন?", "Delete this debtor?")) },
            text = { Text(tr("তার সব পেমেন্টের হিসাবসহ মুছে যাবে।", "All of his/her payment records will be deleted too.")) },
            confirmButton = { TextButton({ confirmDel = false; onDelete() }) { Text(tr("মুছুন", "Delete"), color = Red) } },
            dismissButton = { TextButton({ confirmDel = false }) { Text(tr("বাতিল", "Cancel")) } }
        )
    }
}

@Composable
private fun PayDialog(full: Boolean, remaining: Double, onSave: (Double, Long?) -> Unit, onDismiss: () -> Unit) {
    var amount by remember { mutableStateOf(if (full) numText(remaining) else "") }
    var ptp by remember { mutableStateOf<Long?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val errAmt = tr("সঠিক টাকার পরিমাণ দিন", "Enter a valid amount")
    val errPart = tr("পার্ট পেমেন্ট বাকি টাকার চেয়ে কম হতে হবে; পুরোটা হলে ফুল পেমেন্ট বেছে নিন",
        "A part payment must be less than the remaining amount; choose Full payment otherwise")
    val after = (remaining - (amount.toDoubleOrNull() ?: 0.0)).coerceAtLeast(0.0)

    fun save() {
        val amt = amount.toDoubleOrNull()
        if (amt == null || amt <= 0) { error = errAmt; return }
        if (!full && amt >= remaining) { error = errPart; return }
        onSave(amt, if (full) null else ptp)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (full) tr("ফুল পেমেন্ট", "Full payment") else tr("পার্ট পেমেন্ট", "Part payment")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("বর্তমান বাকি: ", "Remaining now: ") + money(remaining))
                OutlinedTextField(amount, { amount = it; error = null }, singleLine = true,
                    label = { Text(tr("ফেরত পাওয়া টাকা (₹)", "Amount received (₹)")) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                if (!full) {
                    Text(tr("এই পেমেন্টের পর বাকি: ", "Remaining after this: ") + money(after), fontWeight = FontWeight.Bold)
                    DateField(tr("নতুন PTP তারিখ", "New PTP date"), ptp, { ptp = it }, clearable = true)
                } else {
                    Text(tr("সেভ করলে এই ঋণগ্রহীতা বন্ধ (Closed) হয়ে যাবে।", "Saving will mark this debtor as Closed."),
                        style = MaterialTheme.typography.bodySmall)
                }
                error?.let { Text(it, color = Red) }
            }
        },
        confirmButton = { TextButton({ save() }) { Text(tr("সেভ", "Save")) } },
        dismissButton = { TextButton(onDismiss) { Text(tr("বাতিল", "Cancel")) } }
    )
}
