package com.mymoney.tracker.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mymoney.tracker.MoneyViewModel
import com.mymoney.tracker.cloud.Cloud
import kotlinx.coroutines.launch

/** মাস্টার অ্যাপ: ডেভেলপারের ইমেইল + ইমেইলে আসা সাইন-ইন লিংক দিয়ে লগইন */
@Composable
fun DevLoginScreen(vm: MoneyViewModel) {
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf(Cloud.DEV_EMAIL) }
    var link by remember { mutableStateOf("") }
    var step by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    val onlyDev = tr("শুধু ডেভেলপারের ইমেইল দিয়ে লগইন করা যাবে", "Only the developer email can log in")
    val sentMsg = tr("ইমেইলে লগইন লিংক পাঠানো হয়েছে", "A login link has been sent to the email")
    val needLink = tr("ইমেইলের লিংকটি পেস্ট করুন", "Paste the link from the email")
    val notVerified = tr("ইমেইল যাচাই হয়নি, আবার চেষ্টা করুন", "The email could not be verified, try again")

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Hisab", style = MaterialTheme.typography.headlineLarge)
        Text(tr("ডেভেলপার লগইন", "Developer login"), style = MaterialTheme.typography.titleMedium)
        if (step == 0) {
            Text(tr("ডেভেলপারের ইমেইল দিন। ওই ইমেইলে একটি লগইন লিংক (OTP) যাবে।",
                "Enter the developer email. A login link (OTP) will be sent to it."), textAlign = TextAlign.Center)
            OutlinedTextField(email, { email = it }, label = { Text("Developer email") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth())
            Button({
                if (!email.trim().equals(Cloud.DEV_EMAIL, ignoreCase = true)) {
                    msg = onlyDev
                } else {
                    scope.launch {
                        busy = true; msg = null; info = null
                        try {
                            Cloud.sendSignInLink(email.trim())
                            info = sentMsg
                            step = 1
                        } catch (e: Exception) {
                            msg = e.message ?: "Error"
                        }
                        busy = false
                    }
                }
            }, Modifier.fillMaxWidth(), enabled = !busy) { Text(tr("লগইন লিংক পাঠান", "Send login link")) }
        } else {
            Text(tr("ইমেইল খুলে লিংকটিতে চেপে ধরে 'Copy link' করুন এবং নিচে পেস্ট করুন।",
                "Open the email, long-press the link, choose 'Copy link' and paste it below."), textAlign = TextAlign.Center)
            OutlinedTextField(link, { link = it }, label = { Text(tr("ইমেইলের লিংক", "Link from email")) },
                modifier = Modifier.fillMaxWidth())
            Button({
                if (link.isBlank()) {
                    msg = needLink
                } else {
                    scope.launch {
                        busy = true; msg = null; info = null
                        try {
                            Cloud.signInWithLink(email.trim(), link.trim())
                            if (Cloud.emailVerified()) {
                                vm.refreshAccount()
                            } else {
                                Cloud.signOut()
                                msg = notVerified
                            }
                        } catch (e: Exception) {
                            msg = e.message ?: "Error"
                        }
                        busy = false
                    }
                }
            }, Modifier.fillMaxWidth(), enabled = !busy) { Text(tr("যাচাই করে লগইন", "Verify & log in")) }
            TextButton({ step = 0; msg = null; info = null; link = "" }) { Text(tr("← আবার লিংক পাঠান", "← Send a new link")) }
        }
        msg?.let { Text(it, color = Red, textAlign = TextAlign.Center) }
        info?.let { Text(it, textAlign = TextAlign.Center) }
        if (busy) CircularProgressIndicator()
    }
}

/** লগইনের পর: Administrator Login অথবা User Login বেছে নেওয়া */
@Composable
fun ChooseScreen(vm: MoneyViewModel, onAdmin: () -> Unit, onUser: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Hisab", style = MaterialTheme.typography.headlineLarge)
        Text(Cloud.DEV_EMAIL, style = MaterialTheme.typography.bodyMedium)
        Button(onAdmin, Modifier.fillMaxWidth().height(56.dp)) { Text("🛡 " + tr("অ্যাডমিনিস্ট্রেটর লগইন", "Administrator Login")) }
        Button(onUser, Modifier.fillMaxWidth().height(56.dp)) { Text("👤 " + tr("ইউজার লগইন", "User Login")) }
        TextButton({ vm.signOut() }) { Text(tr("ডেভেলপার লগআউট", "Developer logout")) }
    }
}

/** অ্যাডমিন: ইউজারের মোবাইল নম্বর বা ইমেইল দিয়ে তার ডেটা খোলা */
@Composable
fun AdminLookupScreen(onOpen: (Cloud.DirEntry) -> Unit, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var byMobile by remember { mutableStateOf(true) }
    var menu by remember { mutableStateOf(false) }
    var value by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    val lbMobile = tr("ইউজারের মোবাইল নম্বর", "User mobile number")
    val lbEmail = tr("ইউজারের ইমেইল আইডি", "User mail id")
    val notFound = tr(
        "এই ইউজার পাওয়া যায়নি। ইউজারকে নতুন সংস্করণের অ্যাপে একবার লগইন করে প্রোফাইল দিতে হবে।",
        "User not found. The user must open the updated app once (and save the profile for mobile search)."
    )
    val needValue = tr("নম্বর বা ইমেইল লিখুন", "Enter the number or email")

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🛡 " + tr("অ্যাডমিনিস্ট্রেটর লগইন", "Administrator Login"), style = MaterialTheme.typography.titleLarge)
        Text(tr("Login with", "Login with"), style = MaterialTheme.typography.labelMedium)
        Box {
            OutlinedButton({ menu = true }, Modifier.fillMaxWidth()) { Text((if (byMobile) lbMobile else lbEmail) + "  ▼") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text(lbMobile) }, onClick = { byMobile = true; menu = false; value = "" })
                DropdownMenuItem(text = { Text(lbEmail) }, onClick = { byMobile = false; menu = false; value = "" })
            }
        }
        OutlinedTextField(
            value, { value = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            label = { Text(if (byMobile) lbMobile else lbEmail) },
            keyboardOptions = KeyboardOptions(keyboardType = if (byMobile) KeyboardType.Phone else KeyboardType.Email)
        )
        Button({
            if (value.isBlank()) {
                msg = needValue
            } else {
                scope.launch {
                    busy = true; msg = null
                    try {
                        val e = Cloud.lookup(byMobile, value)
                        if (e == null) msg = notFound else onOpen(e)
                    } catch (ex: Exception) {
                        msg = ex.message ?: "Error"
                    }
                    busy = false
                }
            }
        }, Modifier.fillMaxWidth(), enabled = !busy) { Text(tr("ইউজারের ডেটা খুলুন", "Open user data")) }
        msg?.let { Text(it, color = Red, textAlign = TextAlign.Center) }
        if (busy) CircularProgressIndicator()
        TextButton(onBack) { Text(tr("← ফিরে যান", "← Back")) }
    }
}
