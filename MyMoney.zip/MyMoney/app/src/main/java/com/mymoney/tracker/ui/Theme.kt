package com.mymoney.tracker.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import com.mymoney.tracker.data.SettingsState

val LocalLang = compositionLocalOf { "bn" }

/** ভাষা অনুযায়ী বাংলা বা ইংরেজি লেখা */
@Composable
fun tr(bn: String, en: String): String = if (LocalLang.current == "bn") bn else en

@Composable
fun AppTheme(st: SettingsState, content: @Composable () -> Unit) {
    val dark = when (st.theme) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    val factor = when (st.fontSize) {
        "small" -> 0.88f
        "large" -> 1.15f
        "xlarge" -> 1.3f
        else -> 1.0f
    }
    val base = LocalDensity.current
    CompositionLocalProvider(
        LocalLang provides st.lang,
        LocalDensity provides Density(base.density, base.fontScale * factor)
    ) {
        MaterialTheme(
            colorScheme = if (dark) darkColorScheme() else lightColorScheme(),
            content = content
        )
    }
}
