package com.mymoney.tracker.ui

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mymoney.tracker.data.*
import java.io.File
import java.io.FileOutputStream
import java.time.YearMonth

private class StRow(val date: String, val desc: String, val acct: String, val debit: Double?, val credit: Double?)

private fun buildRows(accs: List<Account>, cards: List<CreditCard>, list: List<Txn>): List<StRow> {
    val an = accs.associate { it.id to it.name }
    val cn = cards.associate { it.id to "${it.bankName} ••${it.last4}" }
    return list.map { t ->
        val d = fmt(t.date(), "dd MMM")
        val what = listOf(t.category, t.note).filter { it.isNotBlank() }.joinToString(" - ")
        when (t.type) {
            "INCOME" -> StRow(d, what.ifEmpty { "Income" }, an[t.accountId] ?: "", null, t.amount)
            "EXPENSE" -> StRow(d, what.ifEmpty { "Expense" },
                if (t.cardId != null) "Card " + (cn[t.cardId] ?: "") else (an[t.accountId] ?: ""), t.amount, null)
            "CARD_BILL" -> StRow(d, "Card bill " + (cn[t.cardId] ?: ""), an[t.accountId] ?: "", t.amount, null)
            else -> StRow(d, "Transfer ${an[t.accountId] ?: ""} > ${an[t.toAccountId] ?: ""} (${money(t.amount)})",
                "", null, null)
        }
    }
}

/** পাতা ভাগ করে PDF লেখার ছোট সহায়ক */
private class PdfW(val doc: PdfDocument) {
    val w = 595
    val h = 842
    val m = 36f
    var no = 0
    lateinit var page: PdfDocument.Page
    lateinit var c: Canvas
    var y = 0f
    val txt = Paint().apply { textSize = 10f }
    val bold = Paint().apply { textSize = 10f; isFakeBoldText = true }
    val title = Paint().apply { textSize = 18f; isFakeBoldText = true }
    val right = Paint().apply { textSize = 10f; textAlign = Paint.Align.RIGHT }
    val rightBold = Paint().apply { textSize = 10f; textAlign = Paint.Align.RIGHT; isFakeBoldText = true }

    fun newPage() {
        if (no > 0) doc.finishPage(page)
        no++
        page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, no).create())
        c = page.canvas
        y = m + 10f
    }

    fun finish() {
        doc.finishPage(page)
    }

    fun cut(s: String, p: Paint, maxW: Float): String {
        val n = p.breakText(s, true, maxW, null)
        return if (n < s.length) s.substring(0, n) else s
    }

    fun tableHeader() {
        c.drawText("Date", m, y, bold)
        c.drawText("Description", 100f, y, bold)
        c.drawText("Account", 300f, y, bold)
        c.drawText("Debit", 500f, y, rightBold)
        c.drawText("Credit", 559f, y, rightBold)
        y += 4f
        c.drawLine(m, y, w - m, y, txt)
        y += 12f
    }
}

private fun makePdf(
    name: String, ym: YearMonth, opening: Double, income: Double, expense: Double, closing: Double, rows: List<StRow>
): PdfDocument {
    val p = PdfW(PdfDocument())
    p.newPage()
    p.c.drawText("My Hisab - Monthly Statement", p.m, p.y, p.title)
    p.y += 22f
    if (name.isNotBlank()) {
        p.c.drawText("Name: $name", p.m, p.y, p.txt)
        p.y += 14f
    }
    p.c.drawText("Month: " + fmt(ym.atDay(1), "MMMM yyyy"), p.m, p.y, p.txt)
    p.y += 20f
    listOf(
        "Opening balance" to opening, "Total income" to income,
        "Total expense" to expense, "Closing balance" to closing
    ).forEach { (l, v) ->
        p.c.drawText(l, p.m, p.y, p.bold)
        p.c.drawText(money(v), 250f, p.y, p.right)
        p.y += 14f
    }
    p.y += 12f
    p.tableHeader()
    for (r in rows) {
        if (p.y > p.h - 50) {
            p.newPage()
            p.tableHeader()
        }
        p.c.drawText(r.date, p.m, p.y, p.txt)
        p.c.drawText(p.cut(r.desc, p.txt, 190f), 100f, p.y, p.txt)
        p.c.drawText(p.cut(r.acct, p.txt, 110f), 300f, p.y, p.txt)
        if (r.debit != null) p.c.drawText(money(r.debit), 500f, p.y, p.right)
        if (r.credit != null) p.c.drawText(money(r.credit), 559f, p.y, p.right)
        p.y += 14f
    }
    p.finish()
    return p.doc
}

/** PDF-কে Downloads ফোল্ডারে সেভ করে; সফল হলে Uri ফেরত দেয় */
private fun savePdf(ctx: Context, fileName: String, doc: PdfDocument): Uri? {
    return try {
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
            if (uri != null) ctx.contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) }
            uri
        } else {
            val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            val f = File(dir, fileName)
            FileOutputStream(f).use { doc.writeTo(it) }
            Uri.fromFile(f)
        }
    } catch (e: Exception) {
        null
    } finally {
        doc.close()
    }
}

@Composable
fun StatementScreen(
    accs: List<Account>, cards: List<CreditCard>, txns: List<Txn>, ym: YearMonth, userName: String
) {
    val ctx = LocalContext.current
    val bn = LocalLang.current == "bn"
    var m by remember { mutableStateOf(ym) }
    var msg by remember { mutableStateOf<String?>(null) }
    var savedUri by remember { mutableStateOf<Uri?>(null) }

    val monthStart = m.atDay(1).toMillis()
    val nextStart = m.plusMonths(1).atDay(1).toMillis()
    val before = txns.filter { it.dateMillis < monthStart }
    val inMonth = txns.filter { it.dateMillis in monthStart until nextStart }
        .sortedWith(compareBy({ it.dateMillis }, { it.id }))
    val opening = accountBalances(accs, before).values.sum()
    val closing = accountBalances(accs, before + inMonth).values.sum()
    val income = inMonth.filter { it.type == "INCOME" }.sumOf { it.amount }
    val expense = inMonth.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    val rows = buildRows(accs, cards, inMonth)

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton({ m = m.minusMonths(1); msg = null }) { Text("◀") }
            Text(fmt(m.atDay(1), "MMMM yyyy"), style = MaterialTheme.typography.titleMedium)
            TextButton({ m = m.plusMonths(1); msg = null }) { Text("▶") }
        }
        Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (userName.isNotBlank()) Text(userName, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(tr("মাসের শুরুর ব্যালেন্স", "Opening balance")); Text(money(opening), fontWeight = FontWeight.Bold)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(tr("মোট আয়", "Total income")); Text(money(income), color = Green, fontWeight = FontWeight.Bold)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(tr("মোট ব্যয়", "Total expense")); Text(money(expense), color = Red, fontWeight = FontWeight.Bold)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(tr("মাসের শেষের ব্যালেন্স", "Closing balance")); Text(money(closing), fontWeight = FontWeight.Bold)
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Button({
                val doc = makePdf(userName, m, opening, income, expense, closing, rows)
                val uri = savePdf(ctx, "MyHisab_Statement_${m}.pdf", doc)
                savedUri = uri
                msg = if (uri != null) {
                    if (bn) "PDF সেভ হয়েছে (Downloads ফোল্ডার) ✅" else "PDF saved to Downloads ✅"
                } else {
                    if (bn) "PDF সেভ করা যায়নি" else "Could not save the PDF"
                }
            }) { Text(tr("PDF ডাউনলোড", "Download PDF")) }
            if (savedUri != null) {
                OutlinedButton({
                    try {
                        val i = Intent(Intent.ACTION_VIEW).apply {
                            setDataAndType(savedUri, "application/pdf")
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        ctx.startActivity(i)
                    } catch (e: Exception) {
                        msg = if (bn) "PDF খোলার অ্যাপ পাওয়া যায়নি, Files অ্যাপের Downloads থেকে খুলুন" else "No PDF viewer found; open it from Downloads"
                    }
                }) { Text(tr("খুলুন", "Open")) }
            }
        }
        msg?.let { Text(it, Modifier.padding(horizontal = 12.dp), style = MaterialTheme.typography.bodySmall) }
        HorizontalDivider(Modifier.padding(top = 8.dp))
        if (rows.isEmpty()) Text(tr("এই মাসে কোনো লেনদেন নেই", "No transactions this month"), Modifier.padding(16.dp))
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(rows.size) { i ->
                val r = rows[i]
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(r.date + "  " + r.desc, style = MaterialTheme.typography.bodyMedium)
                        if (r.acct.isNotBlank()) Text(r.acct, style = MaterialTheme.typography.labelSmall)
                    }
                    if (r.debit != null) Text("-" + money(r.debit), color = Red, style = MaterialTheme.typography.bodyMedium)
                    else if (r.credit != null) Text("+" + money(r.credit), color = Green, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
