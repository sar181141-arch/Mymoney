package com.mymoney.tracker.ui

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mymoney.tracker.data.*
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.time.YearMonth

/** স্টেটমেন্টের সাতটি কলাম: Date, Account Name, Category, Remarks, Credit, Debit, Balance */
private class SRow(
    val whenText: String, val account: String, val category: String, val remarks: String,
    val credit: Double?, val debit: Double?, val balance: Double
)

private class Sum(val label: String, val en: String, val amount: Double, val color: Color)

private fun catText(t: Txn): String = when (t.type) {
    "TRANSFER" -> "Transfer"
    "CARD_BILL" -> "Card bill"
    else -> t.category.ifBlank { if (t.type == "INCOME") "Income" else "Expense" }
}

/** সব অ্যাকাউন্ট মিলিয়ে: ব্যালেন্স = ব্যাংক + ক্যাশ। কার্ড খরচে ব্যালেন্স বদলায় না। */
private fun consolidatedRows(opening: Double, accs: List<Account>, cards: List<CreditCard>, list: List<Txn>): List<SRow> {
    val an = accs.associate { it.id to it.name }
    val cn = cards.associate { it.id to "${it.bankName} ••${it.last4}" }
    var bal = opening
    val out = ArrayList<SRow>()
    for (t in list) {
        val w = fmtDateTime(t.dateMillis)
        when (t.type) {
            "INCOME" -> {
                bal += t.amount
                out.add(SRow(w, an[t.accountId] ?: "", catText(t), t.note, t.amount, null, bal))
            }
            "EXPENSE" -> {
                if (t.cardId == null) bal -= t.amount
                val who = if (t.cardId != null) "Card " + (cn[t.cardId] ?: "") else (an[t.accountId] ?: "")
                out.add(SRow(w, who, catText(t), t.note, null, t.amount, bal))
            }
            "CARD_BILL" -> {
                bal -= t.amount
                out.add(SRow(w, (an[t.accountId] ?: "") + " > " + (cn[t.cardId] ?: ""), catText(t), t.note, null, t.amount, bal))
            }
            else -> {
                out.add(SRow(w, (an[t.accountId] ?: "") + " > " + (an[t.toAccountId] ?: ""), catText(t),
                    t.note.ifBlank { "Amount " + money(t.amount) }, null, null, bal))
            }
        }
    }
    return out
}

/** একটি অ্যাকাউন্টের দৃষ্টিতে: ব্যালেন্স = শুধু ওই অ্যাকাউন্টের */
private fun accountRows(
    acc: Account, opening: Double, accs: List<Account>, cards: List<CreditCard>, list: List<Txn>
): List<SRow> {
    val an = accs.associate { it.id to it.name }
    val cn = cards.associate { it.id to "${it.bankName} ••${it.last4}" }
    var bal = opening
    val out = ArrayList<SRow>()
    for (t in list) {
        val w = fmtDateTime(t.dateMillis)
        when (t.type) {
            "INCOME" -> if (t.accountId == acc.id) {
                bal += t.amount
                out.add(SRow(w, acc.name, catText(t), t.note, t.amount, null, bal))
            }
            "EXPENSE" -> if (t.cardId == null && t.accountId == acc.id) {
                bal -= t.amount
                out.add(SRow(w, acc.name, catText(t), t.note, null, t.amount, bal))
            }
            "CARD_BILL" -> if (t.accountId == acc.id) {
                bal -= t.amount
                out.add(SRow(w, acc.name, catText(t), t.note.ifBlank { "Card " + (cn[t.cardId] ?: "") }, null, t.amount, bal))
            }
            "TRANSFER" -> {
                if (t.accountId == acc.id) {
                    bal -= t.amount
                    out.add(SRow(w, acc.name, catText(t), t.note.ifBlank { "To " + (an[t.toAccountId] ?: "") }, null, t.amount, bal))
                } else if (t.toAccountId == acc.id) {
                    bal += t.amount
                    out.add(SRow(w, acc.name, catText(t), t.note.ifBlank { "From " + (an[t.accountId] ?: "") }, t.amount, null, bal))
                }
            }
        }
    }
    return out
}

/** পাতা ভাগ করে PDF লেখার সহায়ক (A4 আড়াআড়ি, ৭ কলাম) */
private class PdfW(val doc: PdfDocument) {
    val w = 842
    val h = 595
    val m = 36f
    var no = 0
    lateinit var page: PdfDocument.Page
    lateinit var c: Canvas
    var y = 0f
    val txt = Paint().apply { textSize = 9f }
    val bold = Paint().apply { textSize = 9f; isFakeBoldText = true }
    val title = Paint().apply { textSize = 15f; isFakeBoldText = true }
    val right = Paint().apply { textSize = 9f; textAlign = Paint.Align.RIGHT }
    val rightBold = Paint().apply { textSize = 9f; textAlign = Paint.Align.RIGHT; isFakeBoldText = true }

    fun newPage() {
        if (no > 0) doc.finishPage(page)
        no++
        page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, no).create())
        c = page.canvas
        y = m + 8f
    }

    fun finish() {
        doc.finishPage(page)
    }

    fun cut(s: String, p: Paint, maxW: Float): String {
        val n = p.breakText(s, true, maxW, null)
        return if (n < s.length) s.substring(0, n) else s
    }

    fun tableHeader() {
        c.drawText("Date", m, y, bold)
        c.drawText("Account Name", 135f, y, bold)
        c.drawText("Category", 255f, y, bold)
        c.drawText("Remarks", 345f, y, bold)
        c.drawText("Credit Amount", 640f, y, rightBold)
        c.drawText("Debit Amount", 722f, y, rightBold)
        c.drawText("Balance Amount", 806f, y, rightBold)
        y += 4f
        c.drawLine(m, y, w - m, y, txt)
        y += 11f
    }
}

private fun makePdf(heading: String, name: String, ym: YearMonth, summary: List<Sum>, rows: List<SRow>): PdfDocument {
    val p = PdfW(PdfDocument())
    p.newPage()
    p.c.drawText(heading, p.m, p.y, p.title)
    p.y += 20f
    if (name.isNotBlank()) {
        p.c.drawText("Name: $name", p.m, p.y, p.txt)
        p.y += 13f
    }
    p.c.drawText("Month: " + fmt(ym.atDay(1), "MMMM yyyy"), p.m, p.y, p.txt)
    p.y += 16f
    summary.forEach { s ->
        p.c.drawText(s.en, p.m, p.y, p.bold)
        p.c.drawText(money(s.amount), 280f, p.y, p.right)
        p.y += 13f
    }
    p.y += 10f
    p.tableHeader()
    for (r in rows) {
        if (p.y > p.h - 40) {
            p.newPage()
            p.tableHeader()
        }
        p.c.drawText(p.cut(r.whenText, p.txt, 95f), p.m, p.y, p.txt)
        p.c.drawText(p.cut(r.account, p.txt, 115f), 135f, p.y, p.txt)
        p.c.drawText(p.cut(r.category, p.txt, 85f), 255f, p.y, p.txt)
        p.c.drawText(p.cut(r.remarks, p.txt, 215f), 345f, p.y, p.txt)
        if (r.credit != null) p.c.drawText(money(r.credit), 640f, p.y, p.right)
        if (r.debit != null) p.c.drawText(money(r.debit), 722f, p.y, p.right)
        p.c.drawText(money(r.balance), 806f, p.y, p.right)
        p.y += 13f
    }
    p.finish()
    return p.doc
}

private fun makeXlsx(heading: String, name: String, ym: YearMonth, summary: List<Sum>, rows: List<SRow>): ByteArray {
    val data = ArrayList<List<Xlsx.Cell?>>()
    data.add(listOf(Xlsx.Cell(s = heading, bold = true)))
    if (name.isNotBlank()) data.add(listOf(Xlsx.Cell(s = "Name: $name")))
    data.add(listOf(Xlsx.Cell(s = "Month: " + fmt(ym.atDay(1), "MMMM yyyy"))))
    summary.forEach { data.add(listOf(Xlsx.Cell(s = it.en, bold = true), Xlsx.Cell(n = it.amount, bold = true))) }
    data.add(emptyList())
    data.add(
        listOf("Date", "Account Name", "Category", "Remarks", "Credit Amount", "Debit Amount", "Balance Amount")
            .map { Xlsx.Cell(s = it, bold = true) }
    )
    for (r in rows) {
        data.add(
            listOf(
                Xlsx.Cell(s = r.whenText), Xlsx.Cell(s = r.account), Xlsx.Cell(s = r.category), Xlsx.Cell(s = r.remarks),
                if (r.credit != null) Xlsx.Cell(n = r.credit) else null,
                if (r.debit != null) Xlsx.Cell(n = r.debit) else null,
                Xlsx.Cell(n = r.balance)
            )
        )
    }
    return Xlsx.build(data, listOf(24, 24, 18, 38, 16, 16, 18))
}

/** ফাইলকে Downloads ফোল্ডারে সেভ করে; সফল হলে Uri ফেরত দেয় */
private fun saveFile(ctx: Context, fileName: String, mime: String, write: (OutputStream) -> Unit): Uri? {
    return try {
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
            if (uri != null) ctx.contentResolver.openOutputStream(uri)?.use { write(it) }
            uri
        } else {
            val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            val f = File(dir, fileName)
            FileOutputStream(f).use { write(it) }
            Uri.fromFile(f)
        }
    } catch (e: Exception) {
        null
    }
}

private const val MIME_PDF = "application/pdf"
private const val MIME_XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

@Composable
private fun StatementBody(
    ym: YearMonth, onMonth: (YearMonth) -> Unit, heading: String, fileBase: String, userName: String,
    summary: List<Sum>, rows: List<SRow>, header: @Composable () -> Unit
) {
    val ctx = LocalContext.current
    val bn = LocalLang.current == "bn"
    var msg by remember { mutableStateOf<String?>(null) }
    var savedUri by remember { mutableStateOf<Uri?>(null) }
    var savedMime by remember { mutableStateOf(MIME_PDF) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item { header() }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton({ onMonth(ym.minusMonths(1)); msg = null }) { Text("◀") }
                Text(fmt(ym.atDay(1), "MMMM yyyy"), style = MaterialTheme.typography.titleMedium)
                TextButton({ onMonth(ym.plusMonths(1)); msg = null }) { Text("▶") }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (userName.isNotBlank()) Text(userName, fontWeight = FontWeight.Bold)
                    summary.forEach { s ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(s.label, Modifier.weight(1f))
                            Text(money(s.amount), color = s.color, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Button({
                    val doc = makePdf(heading, userName, ym, summary, rows)
                    val uri = try {
                        saveFile(ctx, "$fileBase.pdf", MIME_PDF) { doc.writeTo(it) }
                    } finally {
                        doc.close()
                    }
                    savedUri = uri
                    savedMime = MIME_PDF
                    msg = if (uri != null) {
                        if (bn) "PDF সেভ হয়েছে (Downloads ফোল্ডার) ✅" else "PDF saved to Downloads ✅"
                    } else {
                        if (bn) "PDF সেভ করা যায়নি" else "Could not save the PDF"
                    }
                }) { Text("PDF ⬇") }
                Button({
                    val bytes = makeXlsx(heading, userName, ym, summary, rows)
                    val uri = saveFile(ctx, "$fileBase.xlsx", MIME_XLSX) { it.write(bytes) }
                    savedUri = uri
                    savedMime = MIME_XLSX
                    msg = if (uri != null) {
                        if (bn) "Excel সেভ হয়েছে (Downloads ফোল্ডার) ✅" else "Excel saved to Downloads ✅"
                    } else {
                        if (bn) "Excel সেভ করা যায়নি" else "Could not save the Excel file"
                    }
                }) { Text("Excel ⬇") }
                if (savedUri != null) {
                    OutlinedButton({
                        try {
                            val i = Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(savedUri, savedMime)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            ctx.startActivity(i)
                        } catch (e: Exception) {
                            msg = if (bn) "ফাইল খোলার অ্যাপ পাওয়া যায়নি, Files অ্যাপের Downloads থেকে খুলুন" else "No app found to open it; open it from Downloads"
                        }
                    }) { Text(tr("খুলুন", "Open")) }
                }
            }
        }
        msg?.let { item { Text(it, style = MaterialTheme.typography.bodySmall) } }
        if (rows.isEmpty()) item { Text(tr("এই মাসে কোনো লেনদেন নেই", "No transactions this month")) }
        items(rows.size) { i ->
            val r = rows[i]
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(r.whenText + " · " + r.account, style = MaterialTheme.typography.labelMedium)
                    val line = listOf(r.category, r.remarks).filter { it.isNotBlank() }.joinToString(" · ")
                    if (line.isNotEmpty()) Text(line, style = MaterialTheme.typography.bodyMedium)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        if (r.credit != null) Text("Cr " + money(r.credit), color = Green, style = MaterialTheme.typography.bodySmall)
                        else if (r.debit != null) Text("Dr " + money(r.debit), color = Red, style = MaterialTheme.typography.bodySmall)
                        else Text("—", style = MaterialTheme.typography.bodySmall)
                        Text(tr("ব্যালেন্স ", "Balance ") + money(r.balance), fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

/** কনসোলিডেটেড স্টেটমেন্ট (সব অ্যাকাউন্ট মিলিয়ে), PDF ও Excel */
@Composable
fun StatementScreen(
    accs: List<Account>, cards: List<CreditCard>, txns: List<Txn>, ym: YearMonth, userName: String
) {
    var m by remember { mutableStateOf(ym) }
    val monthStart = m.atDay(1).toMillis()
    val nextStart = m.plusMonths(1).atDay(1).toMillis()
    val before = txns.filter { it.dateMillis < monthStart }
    val inMonth = txns.filter { it.dateMillis in monthStart until nextStart }
        .sortedWith(compareBy({ it.dateMillis }, { it.id }))
    val opening = accountBalances(accs, before).values.sum()
    val closing = accountBalances(accs, before + inMonth).values.sum()
    val income = inMonth.filter { it.type == "INCOME" }.sumOf { it.amount }
    val expense = inMonth.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    val summary = listOf(
        Sum(tr("মাসের শুরুর ব্যালেন্স", "Opening balance"), "Opening balance", opening, Color.Unspecified),
        Sum(tr("মোট আয় (Credit)", "Total credit"), "Total credit", income, Green),
        Sum(tr("মোট ব্যয় (Debit)", "Total debit"), "Total debit", expense, Red),
        Sum(tr("মাসের শেষের ব্যালেন্স", "Closing balance"), "Closing balance", closing, Color.Unspecified)
    )
    StatementBody(
        m, { m = it }, "My Hisab - Consolidated Statement", "MyHisab_Consolidated_$m", userName,
        summary, consolidatedRows(opening, accs, cards, inMonth)
    ) {}
}

/** একটি ব্যাংক অ্যাকাউন্টের ব্যালেন্স ও স্টেটমেন্ট (PDF + Excel) */
@Composable
fun AccountStatementScreen(
    acc: Account, accs: List<Account>, cards: List<CreditCard>, txns: List<Txn>, ym: YearMonth, userName: String
) {
    var m by remember { mutableStateOf(ym) }
    val monthStart = m.atDay(1).toMillis()
    val nextStart = m.plusMonths(1).atDay(1).toMillis()
    val before = txns.filter { it.dateMillis < monthStart }
    val inMonth = txns.filter { it.dateMillis in monthStart until nextStart }
        .sortedWith(compareBy({ it.dateMillis }, { it.id }))
    val current = accountBalances(accs, txns)[acc.id] ?: 0.0
    val opening = accountBalances(accs, before)[acc.id] ?: 0.0
    val closing = accountBalances(accs, before + inMonth)[acc.id] ?: 0.0
    val credits = inMonth.filter {
        (it.type == "INCOME" && it.accountId == acc.id) || (it.type == "TRANSFER" && it.toAccountId == acc.id)
    }.sumOf { it.amount }
    val expenses = inMonth.filter { it.type == "EXPENSE" && it.cardId == null && it.accountId == acc.id }
        .sumOf { it.amount }
    val others = inMonth.filter {
        (it.type == "CARD_BILL" && it.accountId == acc.id) || (it.type == "TRANSFER" && it.accountId == acc.id)
    }.sumOf { it.amount }
    val summary = listOf(
        Sum(tr("মাসের শুরুর ব্যালেন্স", "Opening balance"), "Opening balance", opening, Color.Unspecified),
        Sum(tr("মোট জমা (Credit)", "Total credit"), "Total credit", credits, Green),
        Sum(tr("এই অ্যাকাউন্ট থেকে খরচ", "Spent from this account"), "Expenses", expenses, Red),
        Sum(tr("কার্ড বিল ও ট্রান্সফার আউট", "Card bills & transfers out"), "Card bills & transfers out", others, Red),
        Sum(tr("মাসের শেষের ব্যালেন্স", "Closing balance"), "Closing balance", closing, Color.Unspecified)
    )
    val lbSms = tr("ব্যাংকের SMS ব্যালেন্স: ", "Bank SMS balance: ")
    val sb = acc.smsBalance
    val safeName = acc.name.filter { it.isLetterOrDigit() }.ifEmpty { "Account" }
    StatementBody(
        m, { m = it }, "My Hisab - Account Statement: ${acc.name} (${acc.last5})",
        "MyHisab_${safeName}_$m", userName, summary, accountRows(acc, opening, accs, cards, inMonth)
    ) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("${acc.name} ••••${acc.last5}", fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Text(tr("বর্তমান ব্যালেন্স", "Current balance"), style = MaterialTheme.typography.labelMedium)
                Text(money(current), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                if (sb != null) Text(lbSms + money(sb), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
