package com.mymoney.tracker.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mymoney.tracker.MoneyViewModel
import com.mymoney.tracker.data.*
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

@Composable
private fun Sec(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

@Composable
private fun ChipRow(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { (k, l) -> FilterChip(selected == k, { onSelect(k) }, { Text(l) }) }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked, onChange)
    }
}

private fun buildCsv(accs: List<Account>, cards: List<CreditCard>, txns: List<Txn>): String {
    val an = accs.associate { it.id to it.name }
    val cn = cards.associate { it.id to "${it.bankName} ••${it.last4}" }
    fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
    val sb = StringBuilder("Date,Type,Amount,Account/Card,Category,Note,Source\n")
    txns.sortedBy { it.dateMillis }.forEach { t ->
        val who = if (t.cardId != null && t.type == "EXPENSE") cn[t.cardId] ?: ""
        else an[t.accountId] ?: ""
        sb.append(listOf(t.date().toString(), t.type, t.amount.toString(), q(who), q(t.category), q(t.note), t.source)
            .joinToString(",")).append('\n')
    }
    return sb.toString()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    st: SettingsState, accs: List<Account>, cards: List<CreditCard>, txns: List<Txn>, vm: MoneyViewModel
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val uri = LocalUriHandler.current
    var hasSms by remember { mutableStateOf(smsGranted(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasSms = smsGranted(ctx)
    }
    var msg by remember { mutableStateOf<String?>(null) }
    var showDate by remember { mutableStateOf(false) }
    var pinMode by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }
    val bioOk = remember { biometricAvailable(ctx) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Sec(tr("ভাষা", "Language")) {
            ChipRow(listOf("bn" to "বাংলা", "en" to "English"), st.lang) { v -> vm.update { it.copy(lang = v) } }
        }
        Sec(tr("থিম", "Theme")) {
            ChipRow(
                listOf("system" to tr("ফোনের মতো", "System"), "light" to tr("লাইট", "Light"), "dark" to tr("ডার্ক", "Dark")),
                st.theme
            ) { v -> vm.update { it.copy(theme = v) } }
        }
        Sec(tr("ফন্ট সাইজ", "Font size")) {
            ChipRow(
                listOf(
                    "small" to tr("ছোট", "Small"), "medium" to tr("মাঝারি", "Medium"),
                    "large" to tr("বড়", "Large"), "xlarge" to tr("অনেক বড়", "Extra large")
                ),
                st.fontSize
            ) { v -> vm.update { it.copy(fontSize = v) } }
            Text(tr("এই লেখাটি ফন্ট সাইজের নমুনা", "This is a font size preview"))
        }
        Sec(tr("নিরাপত্তা", "Security")) {
            SwitchRow(tr("অ্যাপ লক (লগইন)", "App lock (login)"), st.lockEnabled) { on ->
                if (on) vm.update { it.copy(lockEnabled = true) } else pinMode = "disable"
            }
            if (bioOk) {
                SwitchRow(tr("ফিঙ্গারপ্রিন্ট দিয়ে খোলা", "Unlock with fingerprint"), st.biometric) { on ->
                    vm.update { it.copy(biometric = on) }
                }
            }
            OutlinedButton({ pinMode = "change" }) { Text(tr("PIN বদলান", "Change PIN")) }
        }
        Sec("SMS") {
            Text(
                if (hasSms) tr("SMS পড়ার অনুমতি দেওয়া আছে ✅", "SMS permission granted ✅")
                else tr("SMS পড়ার অনুমতি দেওয়া নেই", "SMS permission not granted")
            )
            if (!hasSms) {
                Button({
                    launcher.launch(arrayOf(android.Manifest.permission.READ_SMS, android.Manifest.permission.RECEIVE_SMS))
                }) { Text(tr("SMS অনুমতি দিন", "Grant SMS permission")) }
                Text(
                    tr(
                        "অনুমতির বাক্স না এলে: ফোনের Settings → Apps → আমার হিসাব → উপরে ডানের ⋮ → 'Allow restricted settings' চালু করুন, তারপর Permissions → SMS → Allow।",
                        "If no prompt appears: Settings → Apps → My Hisab → ⋮ (top right) → 'Allow restricted settings', then Permissions → SMS → Allow."
                    ),
                    style = MaterialTheme.typography.bodySmall
                )
            }
            SwitchRow(tr("নতুন SMS এলে অটো এন্ট্রি", "Auto-entry for new SMS"), st.autoSms) { on ->
                vm.update { it.copy(autoSms = on) }
            }
            OutlinedButton({ showDate = true }) {
                Text(tr("যে তারিখ থেকে SMS নেওয়া হবে: ", "Import SMS from: ") + st.smsStart)
            }
            Button({
                scope.launch {
                    val n = vm.importInbox()
                    msg = if (st.lang == "bn") "$n টি নতুন এন্ট্রি যোগ হয়েছে" else "$n new entries added"
                }
            }, enabled = hasSms) { Text(tr("ইনবক্স থেকে এখনই ইমপোর্ট করুন", "Import from inbox now")) }
            msg?.let { Text(it) }
        }
        Sec(tr("ডেটা", "Data")) {
            OutlinedButton({
                val i = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "MyHisab.csv")
                    putExtra(Intent.EXTRA_TEXT, buildCsv(accs, cards, txns))
                }
                ctx.startActivity(Intent.createChooser(i, null))
            }) { Text(tr("সব এন্ট্রি এক্সপোর্ট (CSV)", "Export all entries (CSV)")) }
            OutlinedButton({ confirmClear = true }) { Text(tr("সব এন্ট্রি মুছে ফেলুন", "Delete all entries"), color = Red) }
        }
        Sec(tr("অ্যাপ সম্পর্কে", "About")) {
            Text(tr("আমার হিসাব", "My Hisab"), fontWeight = FontWeight.Bold)
            Text(tr("ভার্সন", "Version") + ": 1.1")
            Text(tr("ডেভেলপার ও মালিক", "Developer & Owner") + ": Sahin Akter Rana")
            TextButton({ runCatching { uri.openUri("mailto:sahinakterrana@gmail.com") } }) {
                Text("sahinakterrana@gmail.com")
            }
        }
    }

    if (showDate) {
        val ds = rememberDatePickerState(
            initialSelectedDateMillis = st.startDate().atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        )
        DatePickerDialog(
            onDismissRequest = { showDate = false },
            confirmButton = {
                TextButton({
                    ds.selectedDateMillis?.let {
                        val d: LocalDate = Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate()
                        vm.update { s -> s.copy(smsStart = d.toString()) }
                    }
                    showDate = false
                }) { Text("OK") }
            }
        ) { DatePicker(state = ds) }
    }
    if (pinMode == "disable") {
        PinVerifyDialog(
            tr("লক বন্ধ করতে PIN দিন", "Enter PIN to turn off lock"), vm::verifyPin,
            { vm.update { it.copy(lockEnabled = false) }; pinMode = "" }, { pinMode = "" }
        )
    }
    if (pinMode == "change") {
        ChangePinDialog(vm::verifyPin, { vm.setPin(it); pinMode = "" }, { pinMode = "" })
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text(tr("সব এন্ট্রি মুছবেন?", "Delete all entries?")) },
            text = { Text(tr("এটি ফেরানো যাবে না। অ্যাকাউন্ট ও কার্ড থাকবে, শুধু এন্ট্রিগুলো মুছবে।", "This cannot be undone. Accounts and cards stay; only entries are deleted.")) },
            confirmButton = { TextButton({ vm.clearAll(); confirmClear = false }) { Text(tr("মুছুন", "Delete"), color = Red) } },
            dismissButton = { TextButton({ confirmClear = false }) { Text(tr("বাতিল", "Cancel")) } }
        )
    }
}
