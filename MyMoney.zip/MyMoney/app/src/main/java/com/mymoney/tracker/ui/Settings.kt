package com.mymoney.tracker.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mymoney.tracker.BuildConfig
import com.mymoney.tracker.MoneyViewModel
import com.mymoney.tracker.cloud.Cloud
import com.mymoney.tracker.data.*
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

/** শিরোনাম সবসময় দেখা যায়; শিরোনামে ট্যাপ করলে ভেতরের অপশনগুলো খোলে/বন্ধ হয় */
@Composable
private fun Sec(title: String, content: @Composable ColumnScope.() -> Unit) {
    var open by rememberSaveable(title) { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Column {
            Row(
                Modifier.fillMaxWidth().clickable { open = !open }.padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(if (open) "▲" else "▼")
            }
            if (open) {
                Column(
                    Modifier.padding(start = 14.dp, end = 14.dp, bottom = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) { content() }
            }
        }
    }
}

@Composable
private fun NavRow(title: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text("▸")
        }
    }
}

@Composable
private fun AboutRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ChipRow(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { (k, l) -> FilterChip(selected == k, { onSelect(k) }, { Text(l) }) }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked, onChange)
    }
}

private fun buildCsv(accs: List<Account>, cards: List<CreditCard>, txns: List<Txn>): String {
    val an = accs.associate { it.id to it.name }
    val cn = cards.associate { it.id to "${it.bankName} ••${it.last4}" }
    fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
    val sb = StringBuilder("Date,Type,Amount,Account/Card,Category,Note,Source\n")
    txns.sortedBy { it.dateMillis }.forEach { t ->
        val who = if (t.cardId != null && t.type == "EXPENSE") cn[t.cardId] ?: ""
        else an[t.accountId] ?: ""
        sb.append(listOf(t.date().toString(), t.type, t.amount.toString(), q(who), q(t.category), q(t.note), t.source)
            .joinToString(",")).append('\n')
    }
    return sb.toString()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    st: SettingsState, accs: List<Account>, cards: List<CreditCard>, txns: List<Txn>, vm: MoneyViewModel,
    onNav: (String) -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val uri = LocalUriHandler.current
    var hasSms by remember { mutableStateOf(smsGranted(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasSms = smsGranted(ctx)
    }
    var msg by remember { mutableStateOf<String?>(null) }
    var showDate by remember { mutableStateOf(false) }
    var pinMode by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }
    val bioOk = remember { biometricAvailable(ctx) }
    val tick = LocalTick.current
    val account by vm.account.collectAsState()
    val configured = remember { Cloud.configured(ctx) }
    val bn = st.lang == "bn"
    var cloudMsg by remember { mutableStateOf<String?>(null) }
    var confirmRestore by remember { mutableStateOf(false) }
    var nameField by remember(st.userName) { mutableStateOf(st.userName) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Sec(tr("ভাষা · Language", "Language")) {
            ChipRow(listOf("bn" to "বাংলা", "en" to "English"), st.lang) { v -> vm.update { it.copy(lang = v) } }
        }
        Sec(tr("থিম · Theme", "Theme")) {
            ChipRow(
                listOf("system" to tr("ফোনের মতো", "System"), "light" to tr("লাইট", "Light"), "dark" to tr("ডার্ক", "Dark")),
                st.theme
            ) { v -> vm.update { it.copy(theme = v) } }
        }
        Sec(tr("ফন্ট সাইজ · Font Size", "Font Size")) {
            ChipRow(
                listOf(
                    "small" to tr("ছোট", "Small"), "medium" to tr("মাঝারি", "Medium"),
                    "large" to tr("বড়", "Large"), "xlarge" to tr("অনেক বড়", "Extra large")
                ),
                st.fontSize
            ) { v -> vm.update { it.copy(fontSize = v) } }
            Text(tr("এই লেখাটি ফন্ট সাইজের নমুনা", "This is a font size preview"))
        }
        Sec(tr("নিরাপত্তা · Security", "Security")) {
            SwitchRow(tr("অ্যাপ লক (লগইন)", "App lock (login)"), st.lockEnabled) { on ->
                if (on) {
                    if (st.pinHash.isEmpty()) pinMode = "create" else vm.update { it.copy(lockEnabled = true) }
                } else {
                    pinMode = "disable"
                }
            }
            if (bioOk) {
                SwitchRow(tr("ফিঙ্গারপ্রিন্ট দিয়ে খোলা", "Unlock with fingerprint"), st.biometric) { on ->
                    vm.update { it.copy(biometric = on) }
                }
            }
            Text(tr("অটো-লক সময় (অ্যাপ থেকে বের হওয়ার পর)", "Auto-lock after leaving the app"),
                style = MaterialTheme.typography.labelMedium)
            ChipRow(
                listOf(
                    "0" to tr("সাথে সাথে", "Immediately"), "30" to tr("৩০ সেকেন্ড", "30 sec"),
                    "60" to tr("১ মিনিট", "1 min"), "300" to tr("৫ মিনিট", "5 min"),
                    "900" to tr("১৫ মিনিট", "15 min")
                ),
                st.lockTimeout.toString()
            ) { v -> vm.update { it.copy(lockTimeout = v.toInt()) } }
            OutlinedButton({ pinMode = if (st.pinHash.isEmpty()) "create" else "change" }) {
                Text(if (st.pinHash.isEmpty()) tr("MPIN তৈরি করুন", "Create MPIN") else tr("MPIN বদলান", "Change MPIN"))
            }
        }
        if (vm.target == null) Sec("SMS") {
            Text(
                if (hasSms) tr("SMS পড়ার অনুমতি দেওয়া আছে ✅", "SMS permission granted ✅")
                else tr("SMS পড়ার অনুমতি দেওয়া নেই", "SMS permission not granted")
            )
            if (!hasSms) {
                Button({
                    launcher.launch(arrayOf(android.Manifest.permission.READ_SMS, android.Manifest.permission.RECEIVE_SMS))
                }) { Text(tr("SMS অনুমতি দিন", "Grant SMS permission")) }
                Text(
                    tr(
                        "অনুমতির বাক্স না এলে: ফোনের Settings → Apps → My Hisab → উপরে ডানের ⋮ → 'Allow restricted settings' চালু করুন, তারপর Permissions → SMS → Allow।",
                        "If no prompt appears: Settings → Apps → My Hisab → ⋮ (top right) → 'Allow restricted settings', then Permissions → SMS → Allow."
                    ),
                    style = MaterialTheme.typography.bodySmall
                )
            }
            SwitchRow(tr("নতুন SMS এলে অটো এন্ট্রি", "Auto-entry for new SMS"), st.autoSms) { on ->
                vm.update { it.copy(autoSms = on) }
            }
            OutlinedButton({ showDate = true }) {
                Text(tr("যে তারিখ থেকে SMS নেওয়া হবে: ", "Import SMS from: ") + st.smsStart)
            }
            Button({
                scope.launch {
                    val n = vm.importInbox()
                    msg = if (st.lang == "bn") "$n টি নতুন এন্ট্রি যোগ হয়েছে" else "$n new entries added"
                }
            }, enabled = hasSms) { Text(tr("ইনবক্স থেকে এখনই ইমপোর্ট করুন", "Import from inbox now")) }
            msg?.let { Text(it) }
        }
        Sec(tr("ক্লাউড অ্যাকাউন্ট ও ব্যাকআপ · Cloud backup", "Cloud account & backup")) {
            if (!configured) {
                Text(tr("ক্লাউড সেটআপ হয়নি (google-services.json যোগ করা হয়নি)", "Cloud is not set up (google-services.json not added)"))
            } else {
                Text(tr("লগইন করা আছে: ", "Signed in as: ") + (account ?: "-"))
                SwitchRow(tr("অটো ব্যাকআপ (পরিবর্তনের পর)", "Auto backup (after changes)"), st.autoBackup) { on ->
                    vm.update { it.copy(autoBackup = on) }
                }
                Button({
                    scope.launch {
                        cloudMsg = if (bn) "ব্যাকআপ চলছে…" else "Backing up…"
                        val err = vm.backupNow()
                        cloudMsg = if (err == null) (if (bn) "ব্যাকআপ সম্পন্ন ✅" else "Backup complete ✅") else err
                        if (err == null) tick()
                    }
                }) { Text(tr("এখনই ব্যাকআপ করুন", "Back up now")) }
                OutlinedButton({ confirmRestore = true }) { Text(tr("ক্লাউড থেকে রিস্টোর", "Restore from cloud")) }
                if (vm.target == null) OutlinedButton({ vm.signOut() }) { Text(tr("লগআউট", "Log out")) }
                cloudMsg?.let { Text(it) }
            }
        }
        Sec(tr("ডেটা · Data", "Data")) {
            OutlinedButton({
                val i = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "MyHisab.csv")
                    putExtra(Intent.EXTRA_TEXT, buildCsv(accs, cards, txns))
                }
                ctx.startActivity(Intent.createChooser(i, null))
            }) { Text(tr("সব এন্ট্রি এক্সপোর্ট (CSV)", "Export all entries (CSV)")) }
            OutlinedButton({ confirmClear = true }) { Text(tr("সব এন্ট্রি মুছে ফেলুন", "Delete all entries"), color = Red) }
        }
        Sec(tr("অ্যাপ সম্পর্কে · About", "About")) {
            val appName = if (BuildConfig.IS_MASTER) "Hisab" else "My Hisab"
            Column(
                Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                AppLogo(72.dp)
                Text(appName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(tr("ব্যক্তিগত আর্থিক ব্যবস্থাপনা অ্যাপ", "Personal Finance Manager"), style = MaterialTheme.typography.bodyMedium)
                Text("Version ${BuildConfig.VERSION_NAME} (build ${BuildConfig.VERSION_CODE})", style = MaterialTheme.typography.labelMedium)
            }
            HorizontalDivider()
            AboutRow(tr("ডেভেলপার ও মালিক", "Developer & Owner"), "Sahin Akter Rana")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(tr("যোগাযোগ", "Contact"), style = MaterialTheme.typography.bodyMedium)
                TextButton({ runCatching { uri.openUri("mailto:sahinakterrana@gmail.com") } }) { Text("sahinakterrana@gmail.com") }
            }
            AboutRow(tr("প্ল্যাটফর্ম", "Platform"), "Android")
            AboutRow(tr("ক্লাউড ব্যাকআপ", "Cloud backup"), "Google Firebase")
            HorizontalDivider()
            Text(tr("মূল সুবিধা", "Key features"), fontWeight = FontWeight.Bold)
            listOf(
                tr("ব্যাংক SMS থেকে স্বয়ংক্রিয় আয়-ব্যয় এন্ট্রি", "Automatic income & expense entries from bank SMS"),
                tr("ক্রেডিট কার্ড, ঋণগ্রহীতা ও পরিকল্পিত ব্যয়ের হিসাব", "Credit card, debtor & planned expense tracking"),
                tr("বাজেট, খাতভিত্তিক চার্ট ও সতর্কতা", "Budgets, category charts & alerts"),
                tr("PDF ও Excel স্টেটমেন্ট", "PDF & Excel statements"),
                tr("নিরাপদ ক্লাউড ব্যাকআপ, যেকোনো ফোনে একই ডেটা", "Secure cloud backup with the same data on every phone"),
                tr("MPIN ও ফিঙ্গারপ্রিন্ট লক", "MPIN & fingerprint lock")
            ).forEach { Text("•  $it", style = MaterialTheme.typography.bodySmall) }
            HorizontalDivider()
            Text(tr("গোপনীয়তা ও নিরাপত্তা", "Privacy & security"), fontWeight = FontWeight.Bold)
            Text(
                tr(
                    "আপনার হিসাব এই ফোনে এবং আপনার ব্যক্তিগত ক্লাউড অ্যাকাউন্টে সংরক্ষিত থাকে। ব্যাংক SMS শুধু এই ফোনেই পড়া হয়, কোথাও শেয়ার করা হয় না। আপনার ডেটা শুধু আপনার অ্যাকাউন্ট এবং সহায়তার প্রয়োজনে অনুমোদিত অ্যাডমিন দেখতে পারেন।",
                    "Your data is stored on this phone and in your private cloud account. Bank SMS messages are read on this phone only and are never shared. Your data is accessible only through your account and, for support, by the authorized administrator."
                ),
                style = MaterialTheme.typography.bodySmall
            )
            HorizontalDivider()
            Text(
                "© 2026 Sahin Akter Rana. All rights reserved.",
                Modifier.fillMaxWidth(), style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center
            )
        }
    }

    if (showDate) {
        val ds = rememberDatePickerState(
            initialSelectedDateMillis = st.startDate().atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        )
        DatePickerDialog(
            onDismissRequest = { showDate = false },
            confirmButton = {
                TextButton({
                    ds.selectedDateMillis?.let {
                        val d: LocalDate = Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate()
                        vm.update { s -> s.copy(smsStart = d.toString()) }
                    }
                    showDate = false
                }) { Text("OK") }
            }
        ) { DatePicker(state = ds) }
    }
    if (pinMode == "disable") {
        PinVerifyDialog(
            tr("লক বন্ধ করতে MPIN দিন", "Enter MPIN to turn off lock"), vm::verifyPin,
            { vm.update { it.copy(lockEnabled = false) }; pinMode = "" }, { pinMode = "" }
        )
    }
    if (pinMode == "change") {
        ChangePinDialog(vm::verifyPin, { vm.setPin(it); pinMode = "" }, { pinMode = "" })
    }
    if (pinMode == "create") {
        CreatePinDialog({
            vm.setPin(it)
            vm.update { x -> x.copy(lockEnabled = true, pinSkipped = false) }
            pinMode = ""
        }) { pinMode = "" }
    }
    if (confirmRestore) {
        AlertDialog(
            onDismissRequest = { confirmRestore = false },
            title = { Text(tr("ক্লাউড থেকে রিস্টোর?", "Restore from cloud?")) },
            text = { Text(tr("ফোনের বর্তমান সব ডেটা ক্লাউডের ব্যাকআপ দিয়ে বদলে যাবে।", "All data on this phone will be replaced by the cloud backup.")) },
            confirmButton = {
                TextButton({
                    confirmRestore = false
                    scope.launch {
                        val err = vm.restoreNow()
                        cloudMsg = when (err) {
                            null -> if (bn) "রিস্টোর সম্পন্ন ✅" else "Restore complete ✅"
                            "NO_BACKUP" -> if (bn) "ক্লাউডে কোনো ব্যাকআপ নেই" else "No backup found in cloud"
                            else -> err
                        }
                    }
                }) { Text(tr("রিস্টোর", "Restore")) }
            },
            dismissButton = { TextButton({ confirmRestore = false }) { Text(tr("বাতিল", "Cancel")) } }
        )
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text(tr("সব এন্ট্রি মুছবেন?", "Delete all entries?")) },
            text = { Text(tr("এটি ফেরানো যাবে না। অ্যাকাউন্ট ও কার্ড থাকবে, শুধু এন্ট্রিগুলো মুছবে।", "This cannot be undone. Accounts and cards stay; only entries are deleted.")) },
            confirmButton = { TextButton({ vm.clearAll(); confirmClear = false }) { Text(tr("মুছুন", "Delete"), color = Red) } },
            dismissButton = { TextButton({ confirmClear = false }) { Text(tr("বাতিল", "Cancel")) } }
        )
    }
}
