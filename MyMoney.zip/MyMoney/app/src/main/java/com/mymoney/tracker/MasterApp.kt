package com.mymoney.tracker

import android.app.Application
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mymoney.tracker.cloud.Cloud
import com.mymoney.tracker.data.SettingsState
import com.mymoney.tracker.ui.*

/**
 * মাস্টার অ্যাপ ("Hisab"): ডেভেলপার লগইন → Administrator Login / User Login।
 * User Login = সাধারণ অ্যাপের সব সুবিধা (একই কোড, তাই আপডেটও একসাথে)।
 */
@Composable
fun MasterRoot(vm: MoneyViewModel, st: SettingsState) {
    val ctx = LocalContext.current
    val configured = remember { Cloud.configured(ctx) }
    val account by vm.account.collectAsState()
    var stage by rememberSaveable { mutableStateOf("choose") } // choose | adminLookup | adminApp | user
    var session by rememberSaveable { mutableIntStateOf(0) }
    var tUid by rememberSaveable { mutableStateOf("") }
    var tEmail by rememberSaveable { mutableStateOf("") }
    var tName by rememberSaveable { mutableStateOf("") }

    when {
        !configured -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(
                "Firebase is not set up for this app. Add google-services.json that includes the package com.mymoney.hisab.",
                textAlign = TextAlign.Center
            )
        }
        account?.equals(Cloud.DEV_EMAIL, ignoreCase = true) != true -> DevLoginScreen(vm)
        stage == "adminLookup" -> AdminLookupScreen(
            onOpen = { e ->
                tUid = e.uid
                tEmail = e.email
                tName = e.name
                session++
                stage = "adminApp"
            },
            onBack = { stage = "choose" }
        )
        stage == "adminApp" -> AdminHost(tUid, tEmail, tName, session) { stage = "choose" }
        stage == "user" -> {
            BackHandler(enabled = true) { stage = "choose" }
            Root(vm, st)
        }
        else -> ChooseScreen(vm, { stage = "adminLookup" }, { stage = "user" })
    }
}

/** অ্যাডমিন মোড: নির্বাচিত ইউজারের ডেটা নামিয়ে পুরো অ্যাপের সুবিধায় বদলানো; বদল ওই ইউজারের ক্লাউডে ফেরত যায় */
@Composable
fun AdminHost(uid: String, email: String, name: String, session: Int, onExit: () -> Unit) {
    val app = LocalContext.current.applicationContext as Application
    val avm: MoneyViewModel = viewModel(key = "admin_${uid}_$session", factory = MoneyVmFactory(app, uid, email))
    val ast by avm.settings.collectAsState()
    val ready by avm.ready.collectAsState()
    val err by avm.loadError.collectAsState()
    BackHandler(enabled = true) { onExit() }

    Column(Modifier.fillMaxSize()) {
        Surface(color = MaterialTheme.colorScheme.errorContainer) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "🛡 ADMIN · " + (if (name.isNotBlank()) "$name · " else "") + email,
                    Modifier.weight(1f), style = MaterialTheme.typography.labelMedium
                )
                TextButton(onExit) { Text("Exit") }
            }
        }
        Box(Modifier.weight(1f)) {
            val e = err
            when {
                e != null -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(e, color = Red, textAlign = TextAlign.Center)
                }
                !ready -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                else -> App(avm, ast)
            }
        }
    }
}
