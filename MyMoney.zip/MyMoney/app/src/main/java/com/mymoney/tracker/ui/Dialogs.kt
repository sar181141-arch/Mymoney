package com.mymoney.tracker.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mymoney.tracker.data.*
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

private val expenseCats = listOf("খাবার", "যাতায়াত/ফুয়েল", "বাড়ি ভাড়া", "EMI", "বিল", "চিকিৎসা", "কেনাকাটা", "শিক্ষা", "অন্যান্য")
private val incomeCats = listOf("বেতন", "ব্যবসা", "সুদ", "ভাড়া আয়", "অন্যান্য")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TxnDialog(
    accs: List<Account>,
    existing: Txn?,
    onSave: (Txn) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    var type by remember { mutableStateOf(existing?.type ?: "EXPENSE") }
    var amount by remember {
        mutableStateOf(existing?.amount?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: "")
    }
    var category by remember { mutableStateOf(existing?.category ?: "") }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    var accId by remember {
        mutableStateOf(existing?.accountId ?: accs.firstOrNull { it.isCash }?.id ?: accs.firstOrNull()?.id ?: 0L)
    }
    var toId by remember { mutableStateOf(existing?.toAccountId) }
    var date by remember { mutableStateOf(existing?.date() ?: LocalDate.now()) }
    var showPicker by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun accLabel(a: Account) = if (a.isCash) "Cash" else "${a.name} ••${a.last5}"

    fun save() {
        val amt = amount.toDoubleOrNull()
        if (amt == null || amt <= 0) { error = "সঠিক amount দিন"; return }
        if (type == "TRANSFER" && (toId == null || toId == accId)) { error = "যে অ্যাকাউন্টে যাবে সেটি আলাদা বেছে নিন"; return }
        onSave(
            Txn(
                id = existing?.id ?: 0,
                type = type,
                amount = amt,
                accountId = accId,
                toAccountId = if (type == "TRANSFER") toId else null,
                category = category.trim().ifEmpty { if (type == "TRANSFER") "Transfer" else "অন্যান্য" },
                note = note.trim(),
                dateMillis = date.toMillis(),
                source = existing?.source ?: "MANUAL"
            )
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "নতুন এন্ট্রি" else "এন্ট্রি সম্পাদনা") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(type == "EXPENSE", { type = "EXPENSE" }, { Text("ব্যয়") })
                    FilterChip(type == "INCOME", { type = "INCOME" }, { Text("আয়") })
                    FilterChip(type == "TRANSFER", { type = "TRANSFER" }, { Text("ট্রান্সফার") })
                }
                OutlinedTextField(amount, { amount = it }, label = { Text("Amount (₹)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())

                Text(if (type == "TRANSFER") "কোন অ্যাকাউন্ট থেকে" else if (type == "INCOME") "কোন অ্যাকাউন্টে" else "কোন অ্যাকাউন্ট থেকে",
                    style = MaterialTheme.typography.labelMedium)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(accs, key = { it.id }) { a -> FilterChip(accId == a.id, { accId = a.id }, { Text(accLabel(a)) }) }
                }
                if (type == "TRANSFER") {
                    Text("কোন অ্যাকাউন্টে যাবে", style = MaterialTheme.typography.labelMedium)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(accs.filter { it.id != accId }, key = { it.id }) { a ->
                            FilterChip(toId == a.id, { toId = a.id }, { Text(accLabel(a)) })
                        }
                    }
                } else {
                    Text("খাত", style = MaterialTheme.typography.labelMedium)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(if (type == "INCOME") incomeCats else expenseCats) { c ->
                            FilterChip(category == c, { category = c }, { Text(c) })
                        }
                    }
                    OutlinedTextField(category, { category = it }, label = { Text("খাত (নিজে লিখুন)") },
                        singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                OutlinedTextField(note, { note = it }, label = { Text("নোট (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth())
                OutlinedButton({ showPicker = true }) { Text("তারিখ: " + date.format(DateTimeFormatter.ofPattern("dd MMM yyyy"))) }
                error?.let { Text(it, color = Red) }
            }
        },
        confirmButton = { TextButton({ save() }) { Text("সেভ") } },
        dismissButton = {
            Row {
                if (onDelete != null) TextButton(onDelete) { Text("মুছুন", color = Red) }
                TextButton(onDismiss) { Text("বাতিল") }
            }
        }
    )

    if (showPicker) {
        val st = rememberDatePickerState(
            initialSelectedDateMillis = date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        )
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton({
                    st.selectedDateMillis?.let { date = Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate() }
                    showPicker = false
                }) { Text("ঠিক আছে") }
            }
        ) { DatePicker(state = st) }
    }
}

@Composable
fun AccountDialog(existing: Account?, onSave: (Account) -> Unit, onDismiss: () -> Unit) {
    val isCash = existing?.isCash == true
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var last5 by remember { mutableStateOf(existing?.last5 ?: "") }
    var opening by remember {
        mutableStateOf(existing?.openingBalance?.let { if (it == 0.0) "" else it.toString() } ?: "")
    }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "নতুন ব্যাংক অ্যাকাউন্ট" else "অ্যাকাউন্ট সম্পাদনা") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!isCash) {
                    OutlinedTextField(name, { name = it }, label = { Text("ব্যাংকের নাম (যেমন SBI, HDFC)") }, singleLine = true)
                    OutlinedTextField(last5, { if (it.length <= 5 && it.all(Char::isDigit)) last5 = it },
                        label = { Text("অ্যাকাউন্ট নম্বরের শেষ ৫ ডিজিট") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
                OutlinedTextField(opening, { opening = it }, label = { Text("শুরুর ব্যালেন্স (₹)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                error?.let { Text(it, color = Red) }
            }
        },
        confirmButton = {
            TextButton({
                if (!isCash && (name.isBlank() || last5.length != 5)) { error = "নাম ও ঠিক ৫ ডিজিট দিন"; return@TextButton }
                val ob = if (opening.isBlank()) 0.0 else opening.toDoubleOrNull()
                if (ob == null) { error = "ব্যালেন্স সঠিক নয়"; return@TextButton }
                onSave((existing ?: Account(name = name, isCash = false)).copy(
                    name = if (isCash) "Cash" else name.trim(), last5 = last5, openingBalance = ob))
            }) { Text("সেভ") }
        },
        dismissButton = { TextButton(onDismiss) { Text("বাতিল") } }
    )
}
