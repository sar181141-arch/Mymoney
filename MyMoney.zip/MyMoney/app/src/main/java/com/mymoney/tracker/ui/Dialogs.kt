package com.mymoney.tracker.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.text.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.dp
import com.mymoney.tracker.data.*
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneOffset

private val OPERATORS = listOf("Jio", "Airtel", "Vi", "BSNL")

/** ফর্মের ধরন: EXPENSE, INCOME, TRANSFER (Self Transfer), CARD_BILL (Credit Card), ATM, WIFI, POSTPAID, PREPAID */
private fun kindOf(t: Txn?): String {
    if (t == null) return "EXPENSE"
    if (t.type == "TRANSFER" && t.category == "ATM Withdrawal") return "ATM"
    if (t.type == "EXPENSE") {
        if (t.category == "Wifi") return "WIFI"
        if (t.category == "Postpaid") return "POSTPAID"
        if (t.category == "Prepaid") return "PREPAID"
    }
    return t.type
}

/**
 * এন্ট্রির ফর্ম: "New Entry" ট্যাবে এবং এডিটের ডায়ালগে ব্যবহৃত।
 * limited = true (Daily ট্যাব) হলে টাকা, তারিখ ও সময় বদলানো যায় না; বাকি সব বদলানো যায়।
 */
@Composable
fun TxnForm(
    accs: List<Account>,
    cards: List<CreditCard>,
    existing: Txn?,
    limited: Boolean,
    onSave: (Txn) -> Unit,
    onDelete: (() -> Unit)?,
    onCancel: (() -> Unit)?
) {
    val defaultAcc = accs.firstOrNull { it.isCash }?.id ?: accs.firstOrNull()?.id ?: 0L
    var kind by remember { mutableStateOf(kindOf(existing)) }
    var amount by remember {
        mutableStateOf(existing?.amount?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: "")
    }
    var category by remember {
        mutableStateOf(
            if (existing != null && (kindOf(existing) == "EXPENSE" || kindOf(existing) == "INCOME")) existing.category else ""
        )
    }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    // ক্রেডিট কার্ড বিলে accountId = 0 মানে "Others" (নিজের কোনো অ্যাকাউন্ট থেকে নয়)
    var accId by remember {
        mutableStateOf(
            existing?.takeIf { it.type == "CARD_BILL" }?.accountId
                ?: (existing?.accountId?.takeIf { it != 0L } ?: defaultAcc)
        )
    }
    var cardId by remember { mutableStateOf(existing?.cardId) }
    var toId by remember { mutableStateOf(existing?.toAccountId) }
    var telco by remember { mutableStateOf(existing?.telco ?: "") }
    var billNo by remember { mutableStateOf(existing?.billNo ?: "") }
    var date by remember { mutableStateOf(existing?.date() ?: LocalDate.now()) }
    var timeSel by remember { mutableStateOf<LocalTime?>(existing?.time()) }
    var opMenu by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val kinds = listOf(
        "EXPENSE" to tr("ব্যয়", "Expense"),
        "INCOME" to tr("আয়", "Income"),
        "TRANSFER" to tr("সেলফ ট্রান্সফার", "Self Transfer"),
        "CARD_BILL" to tr("ক্রেডিট কার্ড", "Credit Card"),
        "ATM" to "ATM Withdrawal",
        "WIFI" to "Wifi",
        "POSTPAID" to "Postpaid",
        "PREPAID" to "Prepaid"
    )
    val expCats = Cats.expense
    val incCats = Cats.income
    val errAmt = tr("সঠিক amount দিন", "Enter a valid amount")
    val errTo = tr("যে অ্যাকাউন্টে যাবে সেটি আলাদা বেছে নিন", "Choose a different destination account")
    val errCard = tr("কার্ড বেছে নিন", "Choose a card")
    val errAcc = tr("অ্যাকাউন্ট বেছে নিন", "Choose an account")
    val errOp = tr("অপারেটর বেছে নম্বর দিন", "Choose the operator and enter the number")
    val billDefault = tr("ক্রেডিট কার্ড বিল", "Credit card bill")
    val isUtil = kind == "WIFI" || kind == "POSTPAID" || kind == "PREPAID"
    val cardKinds = kind == "EXPENSE" || isUtil
    val fromAccs = if (kind == "ATM") accs.filter { !it.isCash } else accs

    fun accLabel(a: Account) = if (a.isCash) "Cash" else "${a.name} ••${a.last5}"

    fun switchKind(k: String) {
        val prev = kind
        kind = k
        val cardOk = k == "EXPENSE" || k == "WIFI" || k == "POSTPAID" || k == "PREPAID" || k == "CARD_BILL"
        if (!cardOk) cardId = null
        if (k == "TRANSFER") {
            if (prev == "INCOME" && accId != 0L) {
                // শুধু ক্রেডিট SMS এসেছিল: এই অ্যাকাউন্টটি "To", "From" নতুন করে বাছতে হবে
                toId = accId
                accId = accs.firstOrNull { it.id != toId }?.id ?: 0L
            } else if (accId == 0L) {
                accId = defaultAcc
            }
            if (toId == accId) toId = null
        } else if (k == "ATM") {
            val cur = accs.firstOrNull { it.id == accId }
            if (cur == null || cur.isCash) accId = accs.firstOrNull { !it.isCash }?.id ?: 0L
        } else if (accId == 0L && cardId == null) {
            accId = defaultAcc
        }
    }

    fun save() {
        val amt = if (limited) (existing?.amount ?: 0.0) else amount.toDoubleOrNull()
        if (amt == null || amt <= 0) { error = errAmt; return }
        val cashId = accs.firstOrNull { it.isCash }?.id
        when (kind) {
            "TRANSFER" -> {
                if (accId == 0L) { error = errAcc; return }
                if (toId == null || toId == accId) { error = errTo; return }
            }
            "ATM" -> {
                if (accId == 0L || cashId == null) { error = errAcc; return }
            }
            "CARD_BILL" -> {
                if (cardId == null) { error = errCard; return }
            }
            "EXPENSE", "WIFI", "POSTPAID", "PREPAID" -> {
                if (cardId == null && accId == 0L) { error = errAcc; return }
                if (isUtil && (telco.isBlank() || billNo.isBlank())) { error = errOp; return }
            }
            else -> if (accId == 0L) { error = errAcc; return }
        }
        val type = when (kind) {
            "ATM", "TRANSFER" -> "TRANSFER"
            "WIFI", "POSTPAID", "PREPAID" -> "EXPENSE"
            else -> kind
        }
        val onCard = cardKinds && cardId != null
        val cat = when (kind) {
            "WIFI" -> "Wifi"
            "POSTPAID" -> "Postpaid"
            "PREPAID" -> "Prepaid"
            "ATM" -> "ATM Withdrawal"
            "TRANSFER" -> "Self Transfer"
            "CARD_BILL" -> billDefault
            else -> category.trim().ifEmpty { "Other" }
        }
        val tm = timeSel ?: LocalTime.now()
        val millis = if (limited && existing != null) existing.dateMillis else date.atTimeMillis(tm)
        onSave(
            Txn(
                id = existing?.id ?: 0,
                type = type,
                amount = amt,
                accountId = if (onCard) 0L else accId,
                toAccountId = when (kind) {
                    "TRANSFER" -> toId
                    "ATM" -> cashId
                    else -> null
                },
                cardId = if (cardKinds || kind == "CARD_BILL") cardId else null,
                category = cat,
                note = note.trim(),
                dateMillis = millis,
                source = existing?.source ?: "MANUAL",
                telco = if (isUtil) telco else "",
                billNo = if (isUtil) billNo.trim() else ""
            )
        )
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            kinds.forEach { (k, l) -> FilterChip(kind == k, { switchKind(k) }, { Text(l) }) }
        }
        if (limited) {
            Text(tr("টাকা: ", "Amount: ") + money(existing?.amount ?: 0.0), fontWeight = FontWeight.Bold)
        } else {
            OutlinedTextField(amount, { amount = it }, label = { Text("Amount (₹)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
        }
        if (isUtil) {
            Text(tr("অপারেটর", "Operator"), style = MaterialTheme.typography.labelMedium)
            Box {
                OutlinedButton({ opMenu = true }) {
                    Text(if (telco.isBlank()) tr("অপারেটর বেছে নিন ▼", "Select operator ▼") else "$telco ▼")
                }
                DropdownMenu(expanded = opMenu, onDismissRequest = { opMenu = false }) {
                    OPERATORS.forEach { o ->
                        DropdownMenuItem(text = { Text(o) }, onClick = { telco = o; opMenu = false })
                    }
                }
            }
            OutlinedTextField(
                billNo, { billNo = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text(if (kind == "WIFI") tr("ওয়াইফাই নম্বর / আইডি", "Wifi number / ID") else tr("মোবাইল নম্বর", "Mobile number")) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
            )
        }

        Text(
            when (kind) {
                "INCOME" -> tr("কোন অ্যাকাউন্টে", "Into account")
                "CARD_BILL" -> tr("কোথা থেকে পরিশোধ (Paid From)", "Paid From")
                "ATM" -> tr("কোন ব্যাংক অ্যাকাউন্ট থেকে", "From bank account")
                "TRANSFER" -> tr("কোন অ্যাকাউন্ট থেকে (From)", "From account")
                else -> tr("কোথা থেকে খরচ (অ্যাকাউন্ট / কার্ড)", "Paid from (account / card)")
            },
            style = MaterialTheme.typography.labelMedium
        )
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(fromAccs, key = { "a${it.id}" }) { a ->
                FilterChip((!cardKinds || cardId == null) && accId == a.id, {
                    accId = a.id
                    if (cardKinds) cardId = null
                }, { Text(accLabel(a)) })
            }
            if (cardKinds) {
                items(cards, key = { "c${it.id}" }) { c ->
                    FilterChip(cardId == c.id, { cardId = c.id }, { Text("💳 ${c.bankName} ••${c.last4}") })
                }
            }
            if (kind == "CARD_BILL") {
                item(key = "others") {
                    FilterChip(accId == 0L, { accId = 0L }, { Text(tr("অন্যান্য (Others)", "Others")) })
                }
            }
        }
        if (kind == "TRANSFER") {
            Text(tr("কোন অ্যাকাউন্টে যাবে (To)", "To account"), style = MaterialTheme.typography.labelMedium)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(accs.filter { it.id != accId }, key = { it.id }) { a ->
                    FilterChip(toId == a.id, { toId = a.id }, { Text(accLabel(a)) })
                }
            }
        } else if (kind == "ATM") {
            Text(tr("টাকা সরাসরি Cash-এ যোগ হবে", "The amount is added to Cash"), style = MaterialTheme.typography.bodySmall)
        } else if (kind == "CARD_BILL") {
            Text(tr("কোন কার্ডে (To Which Card)", "To Which Card"), style = MaterialTheme.typography.labelMedium)
            if (cards.isEmpty()) Text(tr("আগে সেটিংস → Modify → ক্রেডিট কার্ডে কার্ড যোগ করুন", "Add a card first in Settings → Modify → Credit Card"))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(cards, key = { "c${it.id}" }) { c ->
                    FilterChip(cardId == c.id, { cardId = c.id }, { Text("${c.bankName} ••${c.last4}") })
                }
            }
        } else if (kind == "EXPENSE" || kind == "INCOME") {
            Text(tr("খাত", "Category"), style = MaterialTheme.typography.labelMedium)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(if (kind == "INCOME") incCats else expCats) { c ->
                    FilterChip(category == c, { category = c }, { Text(catLabel(c)) })
                }
            }
            OutlinedTextField(category, { category = it }, label = { Text(tr("খাত (নিজে লিখুন)", "Category (type your own)")) },
                singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        OutlinedTextField(note, { note = it }, label = { Text(tr("নোট / Remarks (ঐচ্ছিক)", "Note / Remarks (optional)")) },
            modifier = Modifier.fillMaxWidth())
        if (limited) {
            Text(tr("তারিখ ও সময়: ", "Date & time: ") + fmtDateTime(existing?.dateMillis ?: 0L),
                style = MaterialTheme.typography.bodyMedium)
        } else {
            DateField(tr("তারিখ", "Entry date"), date.toMillis(), { m -> if (m != null) date = millisToDate(m) })
            TimeField(tr("সময়", "Entry time"), timeSel ?: LocalTime.now(), { timeSel = it })
        }
        error?.let { Text(it, color = Red) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ save() }, Modifier.weight(1f)) { Text(tr("সেভ", "Save")) }
            if (onDelete != null) OutlinedButton(onDelete) { Text(tr("মুছুন", "Delete"), color = Red) }
            if (onCancel != null) TextButton(onCancel) { Text(tr("বাতিল", "Cancel")) }
        }
    }
}

/** এন্ট্রি এডিট/মোছার ডায়ালগ। limited = true হলে (Daily) টাকা, তারিখ ও সময় বদলানো যায় না। */
@Composable
fun TxnDialog(
    accs: List<Account>,
    cards: List<CreditCard>,
    existing: Txn?,
    limited: Boolean,
    onSave: (Txn) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (limited) tr("এন্ট্রি সম্পাদনা (টাকা, তারিখ ও সময় বাদে)", "Edit entry (except amount, date & time)")
                else if (existing == null) tr("নতুন এন্ট্রি", "New entry") else tr("এন্ট্রি সম্পাদনা", "Edit entry")
            )
        },
        text = {
            Box(Modifier.verticalScroll(rememberScrollState())) {
                TxnForm(accs, cards, existing, limited, onSave, onDelete, onDismiss)
            }
        },
        confirmButton = {}
    )
}

/** নিচের "New Entry" ট্যাব: এন্ট্রি যোগ করার পর্দা */
@Composable
fun EntryScreen(accs: List<Account>, cards: List<CreditCard>, onSave: (Txn) -> Unit) {
    var formKey by remember { mutableIntStateOf(0) }
    var lastSaved by remember { mutableStateOf<Long?>(null) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Entry Type", style = MaterialTheme.typography.titleMedium)
        lastSaved?.let { Text(tr("সেভ হয়েছে ✅ · ", "Saved ✅ · ") + fmtDateTime(it), color = Green) }
        key(formKey) {
            TxnForm(accs, cards, null, false, { onSave(it); lastSaved = it.dateMillis; formKey++ }, null, null)
        }
    }
}

/** যেসব এন্ট্রি বদলানো যায় না (ড্যাশবোর্ড ইত্যাদি) সেগুলোতে ট্যাপ করলে Remarks সহ বিবরণ */
@Composable
fun TxnDetailDialog(t: Txn, accs: List<Account>, cards: List<CreditCard>, onDismiss: () -> Unit) {
    val an = accs.associate { it.id to it.name }
    val cn = cards.associate { it.id to "${it.bankName} ••${it.last4}" }
    val others = tr("অন্যান্য (Others)", "Others")
    val dash = "—"
    val typeLabel = when (kindOf(t)) {
        "INCOME" -> tr("আয়", "Income")
        "TRANSFER" -> tr("সেলফ ট্রান্সফার", "Self Transfer")
        "CARD_BILL" -> tr("ক্রেডিট কার্ড", "Credit Card")
        "ATM" -> "ATM Withdrawal"
        "WIFI" -> "Wifi"
        "POSTPAID" -> "Postpaid"
        "PREPAID" -> "Prepaid"
        else -> tr("ব্যয়", "Expense")
    }
    val lines = ArrayList<Pair<String, String>>()
    lines.add(tr("ধরন", "Type") to typeLabel)
    lines.add(tr("টাকা", "Amount") to money(t.amount))
    lines.add(tr("তারিখ ও সময়", "Date & time") to fmtDateTime(t.dateMillis))
    when (t.type) {
        "TRANSFER" -> {
            lines.add("From" to (an[t.accountId] ?: dash))
            lines.add("To" to (an[t.toAccountId] ?: dash))
        }
        "CARD_BILL" -> {
            lines.add(tr("পরিশোধ (Paid From)", "Paid From") to (if (t.accountId == 0L) others else (an[t.accountId] ?: dash)))
            lines.add(tr("কোন কার্ডে (To)", "To Which Card") to (cn[t.cardId] ?: dash))
        }
        "INCOME" -> lines.add(tr("অ্যাকাউন্ট", "Account") to (an[t.accountId] ?: dash))
        else -> lines.add(
            tr("পরিশোধ (Paid From)", "Paid From") to
                (if (t.cardId != null) "💳 " + (cn[t.cardId] ?: "") else (an[t.accountId] ?: dash))
        )
    }
    if (t.category.isNotBlank()) lines.add(tr("খাত", "Category") to catLabel(t.category))
    if (t.telco.isNotBlank()) lines.add(tr("অপারেটর", "Operator") to t.telco)
    if (t.billNo.isNotBlank()) lines.add(tr("নম্বর", "Number") to t.billNo)
    lines.add("Remarks" to t.note.ifBlank { dash })
    lines.add(tr("সূত্র", "Source") to (if (t.source == "SMS") "SMS" else tr("ম্যানুয়াল", "Manual")))

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("এন্ট্রির বিবরণ", "Entry details")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                lines.forEach { (k, v) ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(k, Modifier.weight(0.4f), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                        Text(v, Modifier.weight(0.6f), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("OK") } }
    )
}

@Composable
fun AccountDialog(existing: Account?, onSave: (Account) -> Unit, onDismiss: () -> Unit) {
    val isCash = existing?.isCash == true
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var last5 by remember { mutableStateOf(existing?.last5 ?: "") }
    var opening by remember {
        mutableStateOf(existing?.openingBalance?.let { if (it == 0.0) "" else it.toString() } ?: "")
    }
    var error by remember { mutableStateOf<String?>(null) }
    val errName = tr("নাম ও ঠিক ৫ ডিজিট দিন", "Enter a name and exactly 5 digits")
    val errBal = tr("ব্যালেন্স সঠিক নয়", "Invalid balance")

    fun save() {
        if (!isCash && (name.isBlank() || last5.length != 5)) { error = errName; return }
        val ob = if (opening.isBlank()) 0.0 else opening.toDoubleOrNull()
        if (ob == null) { error = errBal; return }
        onSave((existing ?: Account(name = name, isCash = false)).copy(
            name = if (isCash) "Cash" else name.trim(), last5 = last5, openingBalance = ob))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("নতুন ব্যাংক অ্যাকাউন্ট", "New bank account") else tr("অ্যাকাউন্ট সম্পাদনা", "Edit account")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!isCash) {
                    OutlinedTextField(name, { name = it }, label = { Text(tr("ব্যাংকের নাম (যেমন SBI, Axis)", "Bank name (e.g. SBI, Axis)")) }, singleLine = true)
                    OutlinedTextField(last5, { if (it.length <= 5 && it.all(Char::isDigit)) last5 = it },
                        label = { Text(tr("অ্যাকাউন্ট নম্বরের শেষ ৫ ডিজিট", "Last 5 digits of account number")) }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
                OutlinedTextField(opening, { opening = it }, label = { Text(tr("শুরুর ব্যালেন্স (₹)", "Opening balance (₹)")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                error?.let { Text(it, color = Red) }
            }
        },
        confirmButton = { TextButton({ save() }) { Text(tr("সেভ", "Save")) } },
        dismissButton = { TextButton(onDismiss) { Text(tr("বাতিল", "Cancel")) } }
    )
}

@Composable
fun CardDialog(existing: CreditCard?, onSave: (CreditCard) -> Unit, onDismiss: () -> Unit) {
    var bank by remember { mutableStateOf(existing?.bankName ?: "") }
    var last4 by remember { mutableStateOf(existing?.last4 ?: "") }
    var limit by remember {
        mutableStateOf(existing?.creditLimit?.let { if (it == 0.0) "" else it.toString() } ?: "")
    }
    var due by remember {
        mutableStateOf(existing?.openingDue?.let { if (it == 0.0) "" else it.toString() } ?: "")
    }
    var error by remember { mutableStateOf<String?>(null) }
    val errName = tr("ব্যাংকের নাম ও ঠিক ৪ ডিজিট দিন", "Enter bank name and exactly 4 digits")
    val errNum = tr("লিমিট বা বকেয়া সঠিক নয়", "Invalid limit or outstanding amount")

    fun save() {
        if (bank.isBlank() || last4.length != 4) { error = errName; return }
        val l = if (limit.isBlank()) 0.0 else limit.toDoubleOrNull()
        val d = if (due.isBlank()) 0.0 else due.toDoubleOrNull()
        if (l == null || d == null) { error = errNum; return }
        onSave((existing ?: CreditCard(bankName = bank, last4 = last4)).copy(
            bankName = bank.trim(), last4 = last4, openingDue = d, creditLimit = l))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("নতুন ক্রেডিট কার্ড", "New credit card") else tr("কার্ড সম্পাদনা", "Edit card")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(bank, { bank = it }, label = { Text(tr("ব্যাংকের নাম (যেমন Axis, SBI Card)", "Bank name (e.g. Axis, SBI Card)")) }, singleLine = true)
                OutlinedTextField(last4, { if (it.length <= 4 && it.all(Char::isDigit)) last4 = it },
                    label = { Text(tr("কার্ডের শেষ ৪ ডিজিট", "Last 4 digits of card")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(limit, { limit = it }, label = { Text(tr("ক্রেডিট কার্ড লিমিট (₹)", "Credit card limit (₹)")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(due, { due = it }, label = { Text(tr("এখনকার খরচ/বকেয়া (ঐচ্ছিক)", "Current spent/due (optional)")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                error?.let { Text(it, color = Red) }
            }
        },
        confirmButton = { TextButton({ save() }) { Text(tr("সেভ", "Save")) } },
        dismissButton = { TextButton(onDismiss) { Text(tr("বাতিল", "Cancel")) } }
    )
}
