package com.mymoney.tracker.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.text.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.dp
import com.mymoney.tracker.data.*
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

/** এন্ট্রির ফর্ম: নিচের "Expense" ট্যাবে নতুন এন্ট্রির জন্য এবং ব্যয় এডিটের ডায়ালগে ব্যবহৃত */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TxnForm(
    accs: List<Account>,
    cards: List<CreditCard>,
    existing: Txn?,
    onSave: (Txn) -> Unit,
    onDelete: (() -> Unit)?,
    onCancel: (() -> Unit)?
) {
    var type by remember { mutableStateOf(existing?.type ?: "EXPENSE") }
    var amount by remember {
        mutableStateOf(existing?.amount?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: "")
    }
    var category by remember { mutableStateOf(existing?.category ?: "") }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    var accId by remember {
        mutableStateOf(
            existing?.accountId?.takeIf { it != 0L } ?: accs.firstOrNull { it.isCash }?.id ?: accs.firstOrNull()?.id ?: 0L
        )
    }
    var cardId by remember { mutableStateOf(existing?.cardId) }
    var toId by remember { mutableStateOf(existing?.toAccountId) }
    var date by remember { mutableStateOf(existing?.date() ?: LocalDate.now()) }
    var showPicker by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val types = listOf(
        "EXPENSE" to tr("ব্যয়", "Expense"),
        "INCOME" to tr("আয়", "Income"),
        "TRANSFER" to tr("ট্রান্সফার", "Transfer"),
        "CARD_BILL" to tr("কার্ড বিল", "Card bill")
    )
    val expCats = listOf(
        tr("খাবার", "Food"), tr("যাতায়াত/ফুয়েল", "Travel/Fuel"), tr("বাড়ি ভাড়া", "Rent"), "EMI",
        tr("বিল", "Bills"), tr("চিকিৎসা", "Medical"), tr("কেনাকাটা", "Shopping"),
        tr("শিক্ষা", "Education"), tr("অন্যান্য", "Other")
    )
    val incCats = listOf(
        tr("বেতন", "Salary"), tr("ব্যবসা", "Business"), tr("সুদ", "Interest"),
        tr("ভাড়া আয়", "Rental income"), tr("অন্যান্য", "Other")
    )
    val errAmt = tr("সঠিক amount দিন", "Enter a valid amount")
    val errTo = tr("যে অ্যাকাউন্টে যাবে সেটি আলাদা বেছে নিন", "Choose a different destination account")
    val errCard = tr("কার্ড বেছে নিন", "Choose a card")
    val errAcc = tr("অ্যাকাউন্ট বেছে নিন", "Choose an account")
    val billDefault = tr("ক্রেডিট কার্ড বিল", "Credit card bill")
    val otherDefault = tr("অন্যান্য", "Other")

    fun accLabel(a: Account) = if (a.isCash) "Cash" else "${a.name} ••${a.last5}"

    fun save() {
        val amt = amount.toDoubleOrNull()
        if (amt == null || amt <= 0) { error = errAmt; return }
        when (type) {
            "TRANSFER" -> if (toId == null || toId == accId) { error = errTo; return }
            "CARD_BILL" -> {
                if (cardId == null) { error = errCard; return }
                if (accId == 0L) { error = errAcc; return }
            }
            "EXPENSE" -> if (cardId == null && accId == 0L) { error = errAcc; return }
            else -> if (accId == 0L) { error = errAcc; return }
        }
        val onCard = type == "EXPENSE" && cardId != null
        onSave(
            Txn(
                id = existing?.id ?: 0,
                type = type,
                amount = amt,
                accountId = if (onCard) 0L else accId,
                toAccountId = if (type == "TRANSFER") toId else null,
                cardId = if (type == "EXPENSE" || type == "CARD_BILL") cardId else null,
                category = category.trim().ifEmpty {
                    when (type) {
                        "TRANSFER" -> "Transfer"
                        "CARD_BILL" -> billDefault
                        else -> otherDefault
                    }
                },
                note = note.trim(),
                dateMillis = date.toMillis(),
                source = existing?.source ?: "MANUAL"
            )
        )
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            types.forEach { (k, l) ->
                FilterChip(type == k, {
                    type = k
                    if (k != "EXPENSE" && k != "CARD_BILL") cardId = null
                }, { Text(l) })
            }
        }
        OutlinedTextField(amount, { amount = it }, label = { Text("Amount (₹)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())

        Text(
            when (type) {
                "INCOME" -> tr("কোন অ্যাকাউন্টে", "Into account")
                "CARD_BILL" -> tr("কোন অ্যাকাউন্ট থেকে বিল দিলেন", "Paid from account")
                "EXPENSE" -> tr("কোথা থেকে খরচ (অ্যাকাউন্ট / কার্ড)", "Paid from (account / card)")
                else -> tr("কোন অ্যাকাউন্ট থেকে", "From account")
            },
            style = MaterialTheme.typography.labelMedium
        )
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(accs, key = { "a${it.id}" }) { a ->
                FilterChip((type != "EXPENSE" || cardId == null) && accId == a.id, {
                    accId = a.id
                    if (type == "EXPENSE") cardId = null
                }, { Text(accLabel(a)) })
            }
            if (type == "EXPENSE") {
                items(cards, key = { "c${it.id}" }) { c ->
                    FilterChip(cardId == c.id, { cardId = c.id }, { Text("💳 ${c.bankName} ••${c.last4}") })
                }
            }
        }
        if (type == "TRANSFER") {
            Text(tr("কোন অ্যাকাউন্টে যাবে", "To account"), style = MaterialTheme.typography.labelMedium)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(accs.filter { it.id != accId }, key = { it.id }) { a ->
                    FilterChip(toId == a.id, { toId = a.id }, { Text(accLabel(a)) })
                }
            }
        } else if (type == "CARD_BILL") {
            Text(tr("কোন কার্ডের বিল", "Which card"), style = MaterialTheme.typography.labelMedium)
            if (cards.isEmpty()) Text(tr("আগে অ্যাকাউন্ট ট্যাবে কার্ড যোগ করুন", "Add a card in the Accounts tab first"))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(cards, key = { "c${it.id}" }) { c ->
                    FilterChip(cardId == c.id, { cardId = c.id }, { Text("${c.bankName} ••${c.last4}") })
                }
            }
        } else {
            Text(tr("খাত", "Category"), style = MaterialTheme.typography.labelMedium)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(if (type == "INCOME") incCats else expCats) { c ->
                    FilterChip(category == c, { category = c }, { Text(c) })
                }
            }
            OutlinedTextField(category, { category = it }, label = { Text(tr("খাত (নিজে লিখুন)", "Category (type your own)")) },
                singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        OutlinedTextField(note, { note = it }, label = { Text(tr("নোট (ঐচ্ছিক)", "Note (optional)")) },
            modifier = Modifier.fillMaxWidth())
        OutlinedButton({ showPicker = true }) { Text(tr("তারিখ: ", "Date: ") + fmt(date, "dd MMM yyyy")) }
        error?.let { Text(it, color = Red) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ save() }, Modifier.weight(1f)) { Text(tr("সেভ", "Save")) }
            if (onDelete != null) OutlinedButton(onDelete) { Text(tr("মুছুন", "Delete"), color = Red) }
            if (onCancel != null) TextButton(onCancel) { Text(tr("বাতিল", "Cancel")) }
        }
    }

    if (showPicker) {
        val st = rememberDatePickerState(
            initialSelectedDateMillis = date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        )
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton({
                    st.selectedDateMillis?.let { date = Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate() }
                    showPicker = false
                }) { Text("OK") }
            }
        ) { DatePicker(state = st) }
    }
}

/** মাসের ব্যয় তালিকা থেকে এন্ট্রি এডিট/মোছার ডায়ালগ */
@Composable
fun TxnDialog(
    accs: List<Account>,
    cards: List<CreditCard>,
    existing: Txn?,
    onSave: (Txn) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("নতুন এন্ট্রি", "New entry") else tr("এন্ট্রি সম্পাদনা", "Edit entry")) },
        text = {
            Box(Modifier.verticalScroll(rememberScrollState())) {
                TxnForm(accs, cards, existing, onSave, onDelete, onDismiss)
            }
        },
        confirmButton = {}
    )
}

/** নিচের "Expense" ট্যাব: নতুন এন্ট্রি (ব্যয়/আয়/ট্রান্সফার/কার্ড বিল) যোগ করার পর্দা */
@Composable
fun EntryScreen(accs: List<Account>, cards: List<CreditCard>, onSave: (Txn) -> Unit) {
    var formKey by remember { mutableIntStateOf(0) }
    var saved by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(tr("নতুন এন্ট্রি", "New entry"), style = MaterialTheme.typography.titleMedium)
        if (saved) Text(tr("সেভ হয়েছে ✅", "Saved ✅"), color = Green)
        key(formKey) {
            TxnForm(accs, cards, null, { onSave(it); saved = true; formKey++ }, null, null)
        }
    }
}

@Composable
fun AccountDialog(existing: Account?, onSave: (Account) -> Unit, onDismiss: () -> Unit) {
    val isCash = existing?.isCash == true
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var last5 by remember { mutableStateOf(existing?.last5 ?: "") }
    var opening by remember {
        mutableStateOf(existing?.openingBalance?.let { if (it == 0.0) "" else it.toString() } ?: "")
    }
    var error by remember { mutableStateOf<String?>(null) }
    val errName = tr("নাম ও ঠিক ৫ ডিজিট দিন", "Enter a name and exactly 5 digits")
    val errBal = tr("ব্যালেন্স সঠিক নয়", "Invalid balance")

    fun save() {
        if (!isCash && (name.isBlank() || last5.length != 5)) { error = errName; return }
        val ob = if (opening.isBlank()) 0.0 else opening.toDoubleOrNull()
        if (ob == null) { error = errBal; return }
        onSave((existing ?: Account(name = name, isCash = false)).copy(
            name = if (isCash) "Cash" else name.trim(), last5 = last5, openingBalance = ob))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("নতুন ব্যাংক অ্যাকাউন্ট", "New bank account") else tr("অ্যাকাউন্ট সম্পাদনা", "Edit account")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!isCash) {
                    OutlinedTextField(name, { name = it }, label = { Text(tr("ব্যাংকের নাম (যেমন SBI, Axis)", "Bank name (e.g. SBI, Axis)")) }, singleLine = true)
                    OutlinedTextField(last5, { if (it.length <= 5 && it.all(Char::isDigit)) last5 = it },
                        label = { Text(tr("অ্যাকাউন্ট নম্বরের শেষ ৫ ডিজিট", "Last 5 digits of account number")) }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
                OutlinedTextField(opening, { opening = it }, label = { Text(tr("শুরুর ব্যালেন্স (₹)", "Opening balance (₹)")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                error?.let { Text(it, color = Red) }
            }
        },
        confirmButton = { TextButton({ save() }) { Text(tr("সেভ", "Save")) } },
        dismissButton = { TextButton(onDismiss) { Text(tr("বাতিল", "Cancel")) } }
    )
}

@Composable
fun CardDialog(existing: CreditCard?, onSave: (CreditCard) -> Unit, onDismiss: () -> Unit) {
    var bank by remember { mutableStateOf(existing?.bankName ?: "") }
    var last4 by remember { mutableStateOf(existing?.last4 ?: "") }
    var limit by remember {
        mutableStateOf(existing?.creditLimit?.let { if (it == 0.0) "" else it.toString() } ?: "")
    }
    var due by remember {
        mutableStateOf(existing?.openingDue?.let { if (it == 0.0) "" else it.toString() } ?: "")
    }
    var error by remember { mutableStateOf<String?>(null) }
    val errName = tr("ব্যাংকের নাম ও ঠিক ৪ ডিজিট দিন", "Enter bank name and exactly 4 digits")
    val errNum = tr("লিমিট বা বকেয়া সঠিক নয়", "Invalid limit or outstanding amount")

    fun save() {
        if (bank.isBlank() || last4.length != 4) { error = errName; return }
        val l = if (limit.isBlank()) 0.0 else limit.toDoubleOrNull()
        val d = if (due.isBlank()) 0.0 else due.toDoubleOrNull()
        if (l == null || d == null) { error = errNum; return }
        onSave((existing ?: CreditCard(bankName = bank, last4 = last4)).copy(
            bankName = bank.trim(), last4 = last4, openingDue = d, creditLimit = l))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("নতুন ক্রেডিট কার্ড", "New credit card") else tr("কার্ড সম্পাদনা", "Edit card")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(bank, { bank = it }, label = { Text(tr("ব্যাংকের নাম (যেমন Axis, SBI Card)", "Bank name (e.g. Axis, SBI Card)")) }, singleLine = true)
                OutlinedTextField(last4, { if (it.length <= 4 && it.all(Char::isDigit)) last4 = it },
                    label = { Text(tr("কার্ডের শেষ ৪ ডিজিট", "Last 4 digits of card")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(limit, { limit = it }, label = { Text(tr("ক্রেডিট কার্ড লিমিট (₹)", "Credit card limit (₹)")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(due, { due = it }, label = { Text(tr("এখনকার খরচ/বকেয়া (ঐচ্ছিক)", "Current spent/due (optional)")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                error?.let { Text(it, color = Red) }
            }
        },
        confirmButton = { TextButton({ save() }) { Text(tr("সেভ", "Save")) } },
        dismissButton = { TextButton(onDismiss) { Text(tr("বাতিল", "Cancel")) } }
    )
}
