package com.mymoney.tracker.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MoneyDao {
    @Query("SELECT * FROM accounts ORDER BY isCash DESC, id")
    fun accounts(): Flow<List<Account>>

    @Query("SELECT COUNT(*) FROM accounts WHERE isCash = 1")
    suspend fun cashCount(): Int

    @Insert suspend fun insertAccount(a: Account): Long
    @Update suspend fun updateAccount(a: Account)

    @Query("SELECT * FROM txns ORDER BY dateMillis DESC, id DESC")
    fun txns(): Flow<List<Txn>>

    @Insert suspend fun insertTxn(t: Txn): Long
    @Update suspend fun updateTxn(t: Txn)
    @Delete suspend fun deleteTxn(t: Txn)
}

@Database(entities = [Account::class, Txn::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): MoneyDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "money.db")
                .build().also { inst = it }
        }
    }
}

/** প্রতিটি অ্যাকাউন্টের বর্তমান ব্যালেন্স = opening + আয় − ব্যয় ± ট্রান্সফার */
fun accountBalances(accs: List<Account>, txns: List<Txn>): Map<Long, Double> {
    val m = accs.associate { it.id to it.openingBalance }.toMutableMap()
    for (t in txns) {
        when (t.type) {
            "INCOME" -> m[t.accountId] = (m[t.accountId] ?: 0.0) + t.amount
            "EXPENSE" -> m[t.accountId] = (m[t.accountId] ?: 0.0) - t.amount
            "TRANSFER" -> {
                m[t.accountId] = (m[t.accountId] ?: 0.0) - t.amount
                t.toAccountId?.let { m[it] = (m[it] ?: 0.0) + t.amount }
            }
        }
    }
    return m
}
