package com.mymoney.tracker.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface MoneyDao {
    @Query("SELECT * FROM accounts ORDER BY isCash DESC, id")
    fun accounts(): Flow<List<Account>>

    @Query("SELECT * FROM accounts")
    suspend fun accountsOnce(): List<Account>

    @Query("SELECT COUNT(*) FROM accounts WHERE isCash = 1")
    suspend fun cashCount(): Int

    @Insert suspend fun insertAccount(a: Account): Long
    @Update suspend fun updateAccount(a: Account)

    @Query("SELECT * FROM cards ORDER BY id")
    fun cards(): Flow<List<CreditCard>>

    @Query("SELECT * FROM cards")
    suspend fun cardsOnce(): List<CreditCard>

    @Insert suspend fun insertCard(c: CreditCard): Long
    @Update suspend fun updateCard(c: CreditCard)

    @Query("SELECT * FROM txns ORDER BY dateMillis DESC, id DESC")
    fun txns(): Flow<List<Txn>>

    @Insert suspend fun insertTxn(t: Txn): Long
    @Update suspend fun updateTxn(t: Txn)
    @Delete suspend fun deleteTxn(t: Txn)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertSeen(s: SmsSeen): Long

    @Query("SELECT * FROM txns") suspend fun txnsOnce(): List<Txn>
    @Query("SELECT hash FROM sms_seen") suspend fun seenOnce(): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putAccounts(l: List<Account>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putCards(l: List<CreditCard>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putTxns(l: List<Txn>)
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun putSeen(l: List<SmsSeen>)
    @Query("DELETE FROM accounts") suspend fun clearAccounts()
    @Query("DELETE FROM cards") suspend fun clearCards()

    @Query("DELETE FROM txns") suspend fun clearTxns()
    @Query("DELETE FROM sms_seen") suspend fun clearSeen()
}

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE txns ADD COLUMN cardId INTEGER")
        db.execSQL("CREATE TABLE IF NOT EXISTS cards (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, bankName TEXT NOT NULL, last4 TEXT NOT NULL, openingDue REAL NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS sms_seen (hash TEXT NOT NULL, PRIMARY KEY(hash))")
    }
}

@Database(
    entities = [Account::class, CreditCard::class, Txn::class, SmsSeen::class],
    version = 2,
    exportSchema = false
)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): MoneyDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "money.db")
                .addMigrations(MIGRATION_1_2)
                .build().also { inst = it }
        }
    }
}

/** অ্যাকাউন্টের বর্তমান ব্যালেন্স। ক্রেডিট কার্ড খরচ ব্যাংক/ক্যাশ ব্যালেন্সে প্রভাব ফেলে না। */
fun accountBalances(accs: List<Account>, txns: List<Txn>): Map<Long, Double> {
    val m = accs.associate { it.id to it.openingBalance }.toMutableMap()
    for (t in txns) {
        when (t.type) {
            "INCOME" -> m[t.accountId] = (m[t.accountId] ?: 0.0) + t.amount
            "EXPENSE" -> if (t.cardId == null) m[t.accountId] = (m[t.accountId] ?: 0.0) - t.amount
            "CARD_BILL" -> m[t.accountId] = (m[t.accountId] ?: 0.0) - t.amount
            "TRANSFER" -> {
                m[t.accountId] = (m[t.accountId] ?: 0.0) - t.amount
                t.toAccountId?.let { m[it] = (m[it] ?: 0.0) + t.amount }
            }
        }
    }
    return m
}

/** কার্ডের মোট বকেয়া = শুরুর বকেয়া + কার্ড খরচ − কার্ড বিল পেমেন্ট */
fun cardDue(c: CreditCard, txns: List<Txn>): Double =
    c.openingDue + txns.filter { it.cardId == c.id }.sumOf {
        when (it.type) {
            "EXPENSE" -> it.amount
            "CARD_BILL" -> -it.amount
            else -> 0.0
        }
    }
