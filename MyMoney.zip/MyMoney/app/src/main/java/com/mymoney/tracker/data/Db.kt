package com.mymoney.tracker.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface MoneyDao {
    @Query("SELECT * FROM accounts ORDER BY isCash DESC, id")
    fun accounts(): Flow<List<Account>>

    @Query("SELECT * FROM accounts")
    suspend fun accountsOnce(): List<Account>

    @Query("SELECT COUNT(*) FROM accounts WHERE isCash = 1")
    suspend fun cashCount(): Int

    @Insert suspend fun insertAccount(a: Account): Long
    @Update suspend fun updateAccount(a: Account)

    /** SMS-এ জানানো সর্বশেষ ব্যাংক ব্যালেন্স (নতুন SMS হলেই বদলায়) */
    @Query("UPDATE accounts SET smsBalance = :bal, smsBalanceAt = :at WHERE id = :id AND smsBalanceAt <= :at")
    suspend fun setSmsBalance(id: Long, bal: Double, at: Long)

    @Query("SELECT * FROM cards ORDER BY id")
    fun cards(): Flow<List<CreditCard>>

    @Query("SELECT * FROM cards")
    suspend fun cardsOnce(): List<CreditCard>

    @Insert suspend fun insertCard(c: CreditCard): Long
    @Update suspend fun updateCard(c: CreditCard)

    @Query("SELECT * FROM txns ORDER BY dateMillis DESC, id DESC")
    fun txns(): Flow<List<Txn>>

    @Insert suspend fun insertTxn(t: Txn): Long
    @Update suspend fun updateTxn(t: Txn)
    @Delete suspend fun deleteTxn(t: Txn)

    @Query("SELECT * FROM budgets")
    fun budgets(): Flow<List<Budget>>

    @Query("SELECT * FROM budgets")
    suspend fun budgetsOnce(): List<Budget>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putBudget(b: Budget)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putBudgets(l: List<Budget>)
    @Query("DELETE FROM budgets WHERE category = :c") suspend fun deleteBudget(c: String)
    @Query("DELETE FROM budgets") suspend fun clearBudgets()

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertSeen(s: SmsSeen): Long

    @Query("SELECT * FROM txns") suspend fun txnsOnce(): List<Txn>
    @Query("SELECT hash FROM sms_seen") suspend fun seenOnce(): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putAccounts(l: List<Account>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putCards(l: List<CreditCard>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putTxns(l: List<Txn>)
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun putSeen(l: List<SmsSeen>)
    @Query("DELETE FROM accounts") suspend fun clearAccounts()
    @Query("DELETE FROM cards") suspend fun clearCards()

    @Query("SELECT * FROM debtors ORDER BY closed, id DESC")
    fun debtors(): Flow<List<Debtor>>
    @Query("SELECT * FROM debtors") suspend fun debtorsOnce(): List<Debtor>
    @Insert suspend fun insertDebtor(d: Debtor): Long
    @Update suspend fun updateDebtor(d: Debtor)
    @Delete suspend fun deleteDebtor(d: Debtor)

    @Query("SELECT * FROM debtor_payments ORDER BY dateMillis, id")
    fun debtorPayments(): Flow<List<DebtorPayment>>
    @Query("SELECT * FROM debtor_payments") suspend fun debtorPaymentsOnce(): List<DebtorPayment>
    @Insert suspend fun insertDebtorPayment(p: DebtorPayment): Long
    @Query("DELETE FROM debtor_payments WHERE debtorId = :id") suspend fun deletePaymentsOf(id: Long)

    @Query("SELECT * FROM planned ORDER BY dueMillis, id")
    fun planned(): Flow<List<Planned>>
    @Query("SELECT * FROM planned") suspend fun plannedOnce(): List<Planned>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putPlanned(p: Planned)
    @Delete suspend fun deletePlanned(p: Planned)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putDebtors(l: List<Debtor>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putDebtorPayments(l: List<DebtorPayment>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putPlannedList(l: List<Planned>)
    @Query("DELETE FROM debtors") suspend fun clearDebtors()
    @Query("DELETE FROM debtor_payments") suspend fun clearDebtorPayments()
    @Query("DELETE FROM planned") suspend fun clearPlanned()

    @Query("DELETE FROM txns") suspend fun clearTxns()
    @Query("DELETE FROM sms_seen") suspend fun clearSeen()
}

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE txns ADD COLUMN cardId INTEGER")
        db.execSQL("CREATE TABLE IF NOT EXISTS cards (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, bankName TEXT NOT NULL, last4 TEXT NOT NULL, openingDue REAL NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS sms_seen (hash TEXT NOT NULL, PRIMARY KEY(hash))")
    }
}

val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE cards ADD COLUMN creditLimit REAL NOT NULL DEFAULT 0")
    }
}

val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE accounts ADD COLUMN smsBalance REAL")
        db.execSQL("ALTER TABLE accounts ADD COLUMN smsBalanceAt INTEGER NOT NULL DEFAULT 0")
        db.execSQL("CREATE TABLE IF NOT EXISTS budgets (category TEXT NOT NULL, limitAmount REAL NOT NULL, PRIMARY KEY(category))")
    }
}

val MIGRATION_4_5 = object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS debtors (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, mobile TEXT NOT NULL, amount REAL NOT NULL, dateMillis INTEGER NOT NULL, ptpMillis INTEGER, closed INTEGER NOT NULL, note TEXT NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS debtor_payments (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, debtorId INTEGER NOT NULL, amount REAL NOT NULL, dateMillis INTEGER NOT NULL, isFull INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS planned (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, category TEXT NOT NULL, note TEXT NOT NULL, amount REAL NOT NULL, dueMillis INTEGER NOT NULL, done INTEGER NOT NULL)")
    }
}

val MIGRATION_5_6 = object : Migration(5, 6) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE planned ADD COLUMN hasDate INTEGER NOT NULL DEFAULT 1")
    }
}

@Database(
    entities = [Account::class, CreditCard::class, Txn::class, SmsSeen::class, Budget::class,
        Debtor::class, DebtorPayment::class, Planned::class],
    version = 6,
    exportSchema = false
)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): MoneyDao

    companion object {
        private val insts = java.util.concurrent.ConcurrentHashMap<String, AppDb>()

        /** name = "money.db" (নিজের ডেটা) বা "admin_session.db" (অ্যাডমিন যে ইউজারের ডেটা খুলেছে) */
        fun get(c: Context, name: String = "money.db"): AppDb = insts.getOrPut(name) {
            Room.databaseBuilder(c.applicationContext, AppDb::class.java, name)
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6)
                .build()
        }
    }
}

/** অ্যাকাউন্টের বর্তমান ব্যালেন্স = শুরুর ব্যালেন্স + আয় − ব্যয় − কার্ড বিল ± ট্রান্সফার। কার্ড খরচ ব্যাংক/ক্যাশ ব্যালেন্সে প্রভাব ফেলে না। */
fun accountBalances(accs: List<Account>, txns: List<Txn>): Map<Long, Double> {
    val m = accs.associate { it.id to it.openingBalance }.toMutableMap()
    for (t in txns) {
        when (t.type) {
            "INCOME" -> m[t.accountId] = (m[t.accountId] ?: 0.0) + t.amount
            "EXPENSE" -> if (t.cardId == null) m[t.accountId] = (m[t.accountId] ?: 0.0) - t.amount
            "CARD_BILL" -> m[t.accountId] = (m[t.accountId] ?: 0.0) - t.amount
            "TRANSFER" -> {
                m[t.accountId] = (m[t.accountId] ?: 0.0) - t.amount
                t.toAccountId?.let { m[it] = (m[it] ?: 0.0) + t.amount }
            }
        }
    }
    return m
}

/** কার্ডের মোট বকেয়া = শুরুর বকেয়া + কার্ড খরচ − কার্ড বিল পেমেন্ট */
fun cardDue(c: CreditCard, txns: List<Txn>): Double =
    c.openingDue + txns.filter { it.cardId == c.id }.sumOf {
        when (it.type) {
            "EXPENSE" -> it.amount
            "CARD_BILL" -> -it.amount
            else -> 0.0
        }
    }
