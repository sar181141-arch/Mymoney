package com.mymoney.tracker.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.mymoney.tracker.data.toMillis
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset

fun millisToDate(ms: Long): LocalDate = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate()

/** মোবাইল নম্বরের শুধু শেষ ১০ ডিজিট */
fun normMobile(s: String): String = s.filter { it.isDigit() }.takeLast(10)

/** তারিখ বাছাইয়ের বাটন; clearable হলে ✕ দিয়ে মুছে ফেলা যায় */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateField(label: String, millis: Long?, onChange: (Long?) -> Unit, clearable: Boolean = false) {
    var show by remember { mutableStateOf(false) }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        OutlinedButton({ show = true }) {
            Text(label + ": " + (if (millis != null) fmt(millisToDate(millis), "dd MMM yyyy") else "—"))
        }
        if (clearable && millis != null) TextButton({ onChange(null) }) { Text("✕") }
    }
    if (show) {
        val initial = (if (millis != null) millisToDate(millis) else LocalDate.now())
            .atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        val st = rememberDatePickerState(initialSelectedDateMillis = initial)
        DatePickerDialog(
            onDismissRequest = { show = false },
            confirmButton = {
                TextButton({
                    st.selectedDateMillis?.let {
                        onChange(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate().toMillis())
                    }
                    show = false
                }) { Text("OK") }
            }
        ) { DatePicker(state = st) }
    }
}

/** ডান পাশে চোখের চিহ্নসহ পাসওয়ার্ড ঘর */
@Composable
fun PasswordField(value: String, onChange: (String) -> Unit, label: String) {
    var show by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        trailingIcon = { TextButton({ show = !show }) { Text(if (show) "🙈" else "👁") } },
        modifier = Modifier.fillMaxWidth()
    )
}
