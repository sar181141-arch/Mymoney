package com.mymoney.tracker.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.mymoney.tracker.R
import com.mymoney.tracker.data.toMillis
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale

fun millisToDate(ms: Long): LocalDate = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate()

private val timeFmt = DateTimeFormatter.ofPattern("hh:mm a", Locale.ENGLISH)

/** সময় (hh:mm a); মধ্যরাত (পুরনো এন্ট্রি, যাতে সময় সেভ ছিল না) হলে ফাঁকা */
fun fmtTime(ms: Long): String {
    val t = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalTime()
    return if (t == LocalTime.MIDNIGHT) "" else t.format(timeFmt)
}

/** তারিখ ও সময় একসাথে, যেমন "08 Oct 2026, 03:45 PM" */
fun fmtDateTime(ms: Long): String {
    val d = fmt(millisToDate(ms), "dd MMM yyyy")
    val t = fmtTime(ms)
    return if (t.isEmpty()) d else "$d, $t"
}

/** মোবাইল নম্বরের শুধু শেষ ১০ ডিজিট */
fun normMobile(s: String): String = s.filter { it.isDigit() }.takeLast(10)

/** শিরোনামে ট্যাপ করলে ভেতরের অংশ খোলে/বন্ধ হয় */
@Composable
fun CollapsibleCard(title: String, startOpen: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    var open by rememberSaveable(title) { mutableStateOf(startOpen) }
    Card(Modifier.fillMaxWidth()) {
        Column {
            Row(
                Modifier.fillMaxWidth().clickable { open = !open }.padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(if (open) "▲" else "▼")
            }
            if (open) {
                Column(
                    Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) { content() }
            }
        }
    }
}

/** তারিখ বাছাইয়ের ডায়ালগ */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DatePickDialog(initial: LocalDate, onPick: (LocalDate) -> Unit, onDismiss: () -> Unit) {
    val st = rememberDatePickerState(
        initialSelectedDateMillis = initial.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
    )
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton({
                st.selectedDateMillis?.let { onPick(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate()) }
                onDismiss()
            }) { Text("OK") }
        }
    ) { DatePicker(state = st) }
}

/** তারিখ বাছাইয়ের বাটন; clearable হলে ✕ দিয়ে মুছে ফেলা যায় */
@Composable
fun DateField(label: String, millis: Long?, onChange: (Long?) -> Unit, clearable: Boolean = false) {
    var show by remember { mutableStateOf(false) }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        OutlinedButton({ show = true }) {
            Text(label + ": " + (if (millis != null) fmt(millisToDate(millis), "dd MMM yyyy") else "—"))
        }
        if (clearable && millis != null) TextButton({ onChange(null) }) { Text("✕") }
    }
    if (show) {
        DatePickDialog(
            if (millis != null) millisToDate(millis) else LocalDate.now(),
            { onChange(it.toMillis()) },
            { show = false }
        )
    }
}

/** ডান পাশে চোখের চিহ্নসহ পাসওয়ার্ড ঘর */
@Composable
fun PasswordField(value: String, onChange: (String) -> Unit, label: String) {
    var show by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        trailingIcon = { TextButton({ show = !show }) { Text(if (show) "🙈" else "👁") } },
        modifier = Modifier.fillMaxWidth()
    )
}

/** সময় বাছাইয়ের বাটন (এন্ট্রির সময়) */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimeField(label: String, time: LocalTime, onChange: (LocalTime) -> Unit) {
    var show by remember { mutableStateOf(false) }
    OutlinedButton({ show = true }) { Text(label + ": " + time.format(timeFmt)) }
    if (show) {
        val st = rememberTimePickerState(initialHour = time.hour, initialMinute = time.minute, is24Hour = false)
        AlertDialog(
            onDismissRequest = { show = false },
            confirmButton = {
                TextButton({ onChange(LocalTime.of(st.hour, st.minute)); show = false }) { Text("OK") }
            },
            dismissButton = { TextButton({ show = false }) { Text(tr("বাতিল", "Cancel")) } },
            text = { TimePicker(state = st) }
        )
    }
}

/** অ্যাপের গোল লোগো (সবুজ জমিনে সাদা ₹) */
@Composable
fun AppLogo(size: Dp) {
    Image(
        painterResource(R.drawable.ic_launcher_fg),
        contentDescription = null,
        modifier = Modifier.size(size).clip(CircleShape).background(Color(0xFF1B7F4B))
    )
}
