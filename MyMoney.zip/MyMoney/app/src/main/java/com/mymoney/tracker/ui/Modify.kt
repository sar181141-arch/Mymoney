package com.mymoney.tracker.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mymoney.tracker.data.*
import java.time.YearMonth

/** সেটিংস → Modify: মাস বদলে যেকোনো এন্ট্রিতে ট্যাপ করে বদলানো বা মোছা */
@Composable
fun ModifyEntriesScreen(
    accs: List<Account>, cards: List<CreditCard>, txns: List<Txn>,
    types: Set<String>, emptyText: String, onEdit: (Txn) -> Unit
) {
    var m by remember { mutableStateOf(YearMonth.now()) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton({ m = m.minusMonths(1) }) { Text("◀") }
            Text(fmt(m.atDay(1), "MMMM yyyy"), style = MaterialTheme.typography.titleMedium)
            TextButton({ m = m.plusMonths(1) }) { Text("▶") }
        }
        Box(Modifier.weight(1f)) {
            MonthListScreen(accs, cards, txns, m, types, emptyText, true, onEdit)
        }
    }
}

/** ক্যাশ ও ব্যাংক অ্যাকাউন্ট: নতুন যোগ বা বিবরণ বদলানো */
@Composable
fun ModifyAccountsScreen(accs: List<Account>, txns: List<Txn>, onSave: (Account) -> Unit) {
    val bal = remember(accs, txns) { accountBalances(accs, txns) }
    var editing by remember { mutableStateOf<Account?>(null) }
    var adding by remember { mutableStateOf(false) }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Text(tr("বদলাতে অ্যাকাউন্টে ট্যাপ করুন", "Tap an account to edit it"), style = MaterialTheme.typography.bodySmall) }
        items(accs, key = { it.id }) { a ->
            Card(Modifier.fillMaxWidth().clickable { editing = a }) {
                Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(a.name, fontWeight = FontWeight.Bold)
                        Text(if (a.isCash) tr("ক্যাশ", "Cash") else "A/c ••••${a.last5}", style = MaterialTheme.typography.bodySmall)
                    }
                    Text(money(bal[a.id] ?: 0.0), fontWeight = FontWeight.Bold)
                }
            }
        }
        item { Button({ adding = true }, Modifier.fillMaxWidth()) { Text(tr("+ নতুন ব্যাংক অ্যাকাউন্ট", "+ New bank account")) } }
    }
    if (adding) AccountDialog(null, { onSave(it); adding = false }) { adding = false }
    editing?.let { e -> AccountDialog(e, { onSave(it); editing = null }) { editing = null } }
}

/** ক্রেডিট কার্ড: নতুন যোগ বা বিবরণ বদলানো */
@Composable
fun ModifyCardsScreen(cards: List<CreditCard>, txns: List<Txn>, onSave: (CreditCard) -> Unit) {
    var editing by remember { mutableStateOf<CreditCard?>(null) }
    var adding by remember { mutableStateOf(false) }
    val lbLimit = tr(" • লিমিট ", " • Limit ")
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Text(tr("বদলাতে কার্ডে ট্যাপ করুন", "Tap a card to edit it"), style = MaterialTheme.typography.bodySmall) }
        items(cards, key = { it.id }) { c ->
            Card(Modifier.fillMaxWidth().clickable { editing = c }) {
                Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(c.bankName, fontWeight = FontWeight.Bold)
                        Text("Card ••${c.last4}" + (if (c.creditLimit > 0) lbLimit + money(c.creditLimit) else ""),
                            style = MaterialTheme.typography.bodySmall)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(tr("বকেয়া", "Due"), style = MaterialTheme.typography.labelSmall)
                        Text(money(cardDue(c, txns)), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item { Button({ adding = true }, Modifier.fillMaxWidth()) { Text(tr("+ নতুন ক্রেডিট কার্ড", "+ New credit card")) } }
    }
    if (adding) CardDialog(null, { onSave(it); adding = false }) { adding = false }
    editing?.let { e -> CardDialog(e, { onSave(it); editing = null }) { editing = null } }
}
