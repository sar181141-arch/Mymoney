package com.mymoney.tracker

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mymoney.tracker.data.*
import com.mymoney.tracker.sms.SmsImporter
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class MoneyViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    private val prefs = Prefs(app)

    val accounts: StateFlow<List<Account>> =
        dao.accounts().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val cards: StateFlow<List<CreditCard>> =
        dao.cards().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val txns: StateFlow<List<Txn>> =
        dao.txns().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val settings = MutableStateFlow(prefs.read())

    init {
        viewModelScope.launch {
            if (dao.cashCount() == 0) dao.insertAccount(Account(name = "Cash", isCash = true))
        }
    }

    fun update(f: (SettingsState) -> SettingsState) {
        val n = f(settings.value)
        prefs.write(n)
        settings.value = n
    }

    fun setPin(pin: String) {
        val salt = UUID.randomUUID().toString()
        update { it.copy(pinSalt = salt, pinHash = sha256(salt + pin)) }
    }

    fun verifyPin(pin: String): Boolean {
        val s = settings.value
        return s.pinHash.isNotEmpty() && sha256(s.pinSalt + pin) == s.pinHash
    }

    fun saveTxn(t: Txn) = viewModelScope.launch {
        if (t.id == 0L) dao.insertTxn(t) else dao.updateTxn(t)
    }

    fun deleteTxn(t: Txn) = viewModelScope.launch { dao.deleteTxn(t) }

    fun saveAccount(a: Account) = viewModelScope.launch {
        if (a.id == 0L) dao.insertAccount(a) else dao.updateAccount(a)
    }

    fun saveCard(c: CreditCard) = viewModelScope.launch {
        if (c.id == 0L) dao.insertCard(c) else dao.updateCard(c)
    }

    suspend fun importInbox(): Int = SmsImporter.importInbox(getApplication())

    fun autoImportIfAllowed() {
        if (settings.value.autoSms && smsGranted(getApplication())) {
            viewModelScope.launch { SmsImporter.importInbox(getApplication()) }
        }
    }

    fun clearAll() = viewModelScope.launch {
        dao.clearTxns()
        dao.clearSeen()
    }
}
