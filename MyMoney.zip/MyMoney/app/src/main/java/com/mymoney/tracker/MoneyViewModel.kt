package com.mymoney.tracker

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import com.mymoney.tracker.cloud.Cloud
import com.mymoney.tracker.data.*
import com.mymoney.tracker.sms.SmsImporter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.time.LocalDate
import java.util.UUID

/**
 * target == null  : নিজের ডেটা (সাধারণ ইউজার বা মাস্টার অ্যাপের "User Login")
 * target != null  : অ্যাডমিন মোড — target ইউজারের ক্লাউড ডেটা আলাদা ডাটাবেসে নামিয়ে সেটিই বদলানো হয়,
 *                   বদল ক্লাউডে ওই ইউজারের জায়গাতেই ফেরত লেখা হয়।
 */
class MoneyViewModel @JvmOverloads constructor(
    app: Application,
    val target: String? = null,
    val targetEmail: String? = null
) : AndroidViewModel(app) {
    private val db = AppDb.get(app, if (target == null) "money.db" else "admin_session.db")
    private val dao = db.dao()
    private val prefs = Prefs(app, if (target == null) "settings" else "admin_settings")
    private var syncJob: Job? = null
    private var lastKey: Int? = null // সর্বশেষ সিঙ্ক/লোড হওয়া ডেটার ছাপ; বদল না হলে আবার আপলোড হয় না

    /** প্রোফাইল ছবির ফাইল (অ্যাডমিন মোডে আলাদা, যাতে নিজের ছবি না বদলায়) */
    val photoName = if (target == null) "profile.jpg" else "profile_admin.jpg"

    val accounts: StateFlow<List<Account>> =
        dao.accounts().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val cards: StateFlow<List<CreditCard>> =
        dao.cards().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val txns: StateFlow<List<Txn>> =
        dao.txns().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val budgets: StateFlow<List<Budget>> =
        dao.budgets().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val debtors: StateFlow<List<Debtor>> =
        dao.debtors().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val debtorPayments: StateFlow<List<DebtorPayment>> =
        dao.debtorPayments().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val planned: StateFlow<List<Planned>> =
        dao.planned().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val settings = MutableStateFlow(initialSettings(app))

    /** লগইন করা ইমেইল; null = লগইন নেই। অ্যাডমিন মোডে target ইউজারের ইমেইল। */
    val account = MutableStateFlow<String?>(if (target == null) Cloud.email(app) else (targetEmail ?: "user"))

    /** অ্যাডমিন মোডে ইউজারের ডেটা নামানো শেষ হয়েছে কি না */
    val ready = MutableStateFlow(target == null)
    val loadError = MutableStateFlow<String?>(null)

    init {
        if (target == null) {
            viewModelScope.launch {
                if (dao.cashCount() == 0) dao.insertAccount(Account(name = "Cash", isCash = true))
            }
        } else {
            viewModelScope.launch {
                val err = restoreNow()
                if (err == null) ready.value = true
                else loadError.value = if (err == "NO_BACKUP") "This user has no cloud data yet." else err
            }
        }
    }

    private fun initialSettings(app: Application): SettingsState {
        if (target == null) return prefs.read()
        val main = Prefs(app).read()
        val s = prefs.read().copy(
            lang = main.lang, theme = main.theme, fontSize = main.fontSize,
            lockEnabled = false, autoSms = false, autoBackup = true
        )
        prefs.write(s)
        return s
    }

    fun update(f: (SettingsState) -> SettingsState) {
        val n = f(settings.value)
        prefs.write(n)
        settings.value = n
    }

    fun setPin(pin: String) {
        val salt = UUID.randomUUID().toString()
        update { it.copy(pinSalt = salt, pinHash = sha256(salt + pin)) }
    }

    fun verifyPin(pin: String): Boolean {
        val s = settings.value
        return s.pinHash.isNotEmpty() && sha256(s.pinSalt + pin) == s.pinHash
    }

    fun refreshAccount() {
        if (target == null) account.value = Cloud.email(getApplication())
    }

    // ---------- প্রোফাইল ----------
    fun saveProfile(name: String, mobile: String, dob: String) {
        update { it.copy(userName = name, mobile = mobile, dob = dob) }
        if (target != null) {
            // অ্যাডমিন: ওই ইউজারের ডিরেক্টরি হালনাগাদ; প্রোফাইল নিজেই পরের সিঙ্কে ক্লাউডে যাবে
            viewModelScope.launch {
                try {
                    Cloud.saveDirectory(target, targetEmail ?: "", mobile, name)
                } catch (e: Exception) {
                    // উপেক্ষা
                }
            }
            return
        }
        val email = account.value
        if (email != null) {
            viewModelScope.launch {
                try {
                    Cloud.setName(name)
                } catch (e: Exception) {
                    // উপেক্ষা
                }
                try {
                    Cloud.saveResetCheck(email, mobile, dob)
                } catch (e: Exception) {
                    // উপেক্ষা
                }
                try {
                    Cloud.uid()?.let { Cloud.saveDirectory(it, email, mobile, name) }
                } catch (e: Exception) {
                    // উপেক্ষা
                }
            }
        }
    }

    /** অ্যাডমিন যাতে মোবাইল/ইমেইল দিয়ে এই ইউজারকে খুঁজে পায়, সেজন্য ডিরেক্টরিতে নাম রাখে */
    fun ensureDirectory() {
        if (target != null) return
        val email = account.value ?: return
        val uid = Cloud.uid() ?: return
        val s = settings.value
        viewModelScope.launch {
            try {
                Cloud.saveDirectory(uid, email, s.mobile, s.userName)
            } catch (e: Exception) {
                // উপেক্ষা
            }
        }
    }

    /** বাছাই করা ছবি ছোট করে ফোনেই রাখে */
    fun setPhoto(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val ctx = getApplication<Application>()
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    ?: return@launch
                val side = minOf(bmp.width, bmp.height)
                val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
                val scaled = Bitmap.createScaledBitmap(square, 320, 320, true)
                FileOutputStream(File(ctx.filesDir, photoName)).use { scaled.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                update { it.copy(photoVersion = it.photoVersion + 1) }
            } catch (e: Exception) {
                // উপেক্ষা
            }
        }
    }

    // ---------- এন্ট্রি ----------
    fun saveTxn(t: Txn) = viewModelScope.launch {
        if (t.id == 0L) dao.insertTxn(t) else dao.updateTxn(t)
    }

    fun deleteTxn(t: Txn) = viewModelScope.launch { dao.deleteTxn(t) }

    fun saveAccount(a: Account) = viewModelScope.launch {
        if (a.id == 0L) dao.insertAccount(a) else dao.updateAccount(a)
    }

    fun saveCard(c: CreditCard) = viewModelScope.launch {
        if (c.id == 0L) dao.insertCard(c) else dao.updateCard(c)
    }

    fun saveBudget(category: String, amount: Double) = viewModelScope.launch {
        dao.putBudget(Budget(category, amount))
    }

    fun deleteBudget(category: String) = viewModelScope.launch { dao.deleteBudget(category) }

    // ---------- ঋণগ্রহীতা ----------
    fun saveDebtor(d: Debtor) = viewModelScope.launch {
        if (d.id == 0L) dao.insertDebtor(d) else dao.updateDebtor(d)
    }

    fun deleteDebtor(d: Debtor) = viewModelScope.launch {
        dao.deletePaymentsOf(d.id)
        dao.deleteDebtor(d)
    }

    /** full = true হলে সম্পূর্ণ পরিশোধ ধরে বন্ধ করে; নয়তো পার্ট পেমেন্ট (newPtp দিলে নতুন PTP তারিখ) */
    fun payDebtor(d: Debtor, amount: Double, full: Boolean, newPtp: Long?) = viewModelScope.launch {
        dao.insertDebtorPayment(DebtorPayment(debtorId = d.id, amount = amount,
            dateMillis = LocalDate.now().toMillis(), isFull = full))
        if (full) dao.updateDebtor(d.copy(closed = true, ptpMillis = null))
        else if (newPtp != null) dao.updateDebtor(d.copy(ptpMillis = newPtp))
    }

    // ---------- পরিকল্পিত ব্যয় ----------
    fun savePlanned(p: Planned) = viewModelScope.launch { dao.putPlanned(p) }
    fun deletePlanned(p: Planned) = viewModelScope.launch { dao.deletePlanned(p) }

    // ---------- SMS (অ্যাডমিন মোডে বন্ধ, কারণ সেটা অ্যাডমিনের নিজের ফোনের SMS) ----------
    suspend fun importInbox(): Int = if (target != null) 0 else SmsImporter.importInbox(getApplication())

    fun autoImportIfAllowed() {
        if (target != null) return
        if (settings.value.autoSms && smsGranted(getApplication())) {
            viewModelScope.launch { SmsImporter.importInbox(getApplication()) }
        }
    }

    fun clearAll() = viewModelScope.launch {
        dao.clearTxns()
        dao.clearSeen()
    }

    // ---------- ক্লাউড অ্যাকাউন্ট ----------
    /** সফল হলে null, ব্যর্থ হলে ত্রুটির বার্তা */
    suspend fun signIn(email: String, pass: String, create: Boolean, name: String, mobile: String, dob: String): String? {
        return try {
            if (create) {
                Cloud.signUp(email, pass)
                try {
                    Cloud.setName(name)
                } catch (e: Exception) {
                    // নাম সেভ না হলেও অ্যাকাউন্ট খোলা হয়েছে
                }
                update { it.copy(userName = name, mobile = mobile, dob = dob) }
                try {
                    Cloud.saveResetCheck(email, mobile, dob)
                } catch (e: Exception) {
                    // Firestore rules হালনাগাদ না থাকলে এটি সেভ হবে না; পরে প্রোফাইল সেভ করলে হবে
                }
            } else {
                Cloud.signIn(email, pass)
            }
            account.value = Cloud.email(getApplication())
            Cloud.resetCache()
            if (!create) {
                restoreIfEmpty()
                val n = Cloud.displayName() ?: ""
                if (settings.value.userName.isBlank() && n.isNotBlank()) update { it.copy(userName = n) }
            }
            null
        } catch (e: Exception) {
            e.message ?: "Error"
        }
    }

    fun signOut() {
        if (target != null) return // অ্যাডমিন মোডে ডেভেলপারকে লগআউট করা যাবে না
        try {
            Cloud.signOut()
        } catch (e: Exception) {
            // উপেক্ষা
        }
        Cloud.resetCache()
        account.value = null
    }

    /** নতুন ফোনে লগইনের পর লোকাল ডেটা খালি থাকলে ক্লাউড থেকে নিজে ফিরিয়ে আনে */
    private suspend fun restoreIfEmpty() {
        try {
            if (dao.txnsOnce().isEmpty() && dao.accountsOnce().size <= 1) restoreNow()
        } catch (e: Exception) {
            // উপেক্ষা
        }
    }

    private suspend fun snapshot(): Cloud.BackupData {
        val s = settings.value
        return Cloud.BackupData(
            dao.accountsOnce(), dao.cardsOnce(), dao.txnsOnce(), dao.seenOnce(), dao.budgetsOnce(),
            dao.debtorsOnce(), dao.debtorPaymentsOnce(), dao.plannedOnce(),
            Cloud.ProfileData(s.userName, s.mobile, s.dob)
        )
    }

    private val editor: String get() = if (target == null) "user" else "admin"

    private fun keyOf(d: Cloud.BackupData): Int = listOf(
        d.accs, d.cards, d.txns, d.budgets, d.debtors, d.payments, d.planned,
        d.profile.name + "|" + d.profile.mobile + "|" + d.profile.dob
    ).hashCode()

    suspend fun backupNow(): String? {
        return try {
            val d = snapshot()
            val t = Cloud.backup(d, target, editor)
            lastKey = keyOf(d)
            if (target == null) update { it.copy(syncAt = t) }
            null
        } catch (e: Exception) {
            e.message ?: "Error"
        }
    }

    /** পরিবর্তন হলেই কল হয়; আগের সিঙ্ক চলতে থাকলে বাতিল করে নতুনটা শুরু করে। খালি ডেটা দিয়ে ভালো ব্যাকআপ মোছা এড়াতে খালি থাকলে সিঙ্ক হয় না। */
    fun backupSilently() {
        if (!ready.value) return
        syncJob?.cancel()
        syncJob = viewModelScope.launch {
            try {
                val d = snapshot()
                if (keyOf(d) == lastKey) return@launch
                if (d.txns.isEmpty() && d.cards.isEmpty() && d.accs.size <= 1 &&
                    d.debtors.isEmpty() && d.planned.isEmpty()
                ) return@launch
                val t = Cloud.backup(d, target, editor)
                lastKey = keyOf(d)
                if (target == null) update { it.copy(syncAt = t) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // উপেক্ষা
            }
        }
    }

    /** অ্যাডমিন ক্লাউডে ডেটা বদলালে ইউজারের অ্যাপ খুললে সেটি ফোনে নামিয়ে নেয় */
    fun pullAdminEdits() {
        if (target != null || account.value == null) return
        viewModelScope.launch {
            try {
                val info = Cloud.metaInfo() ?: return@launch
                if (info.second == "admin" && info.first > settings.value.syncAt) {
                    if (restoreNow() == null) update { it.copy(syncAt = info.first) }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // উপেক্ষা
            }
        }
    }

    /** সফল হলে null; ব্যাকআপ না থাকলে "NO_BACKUP"; অন্যথায় ত্রুটির বার্তা */
    suspend fun restoreNow(): String? {
        return try {
            val snap = Cloud.fetch(target) ?: return "NO_BACKUP"
            db.withTransaction {
                dao.clearTxns()
                dao.clearCards()
                dao.clearAccounts()
                dao.clearSeen()
                dao.clearBudgets()
                dao.clearDebtors()
                dao.clearDebtorPayments()
                dao.clearPlanned()
                dao.putAccounts(snap.accs)
                dao.putCards(snap.cards)
                dao.putTxns(snap.txns)
                dao.putSeen(snap.seen.map { SmsSeen(it) })
                dao.putBudgets(snap.budgets)
                dao.putDebtors(snap.debtors)
                dao.putDebtorPayments(snap.payments)
                dao.putPlannedList(snap.planned)
            }
            if (snap.profile.name.isNotBlank() || target != null) {
                update { it.copy(userName = snap.profile.name, mobile = snap.profile.mobile, dob = snap.profile.dob) }
            }
            lastKey = keyOf(snapshot())
            null
        } catch (e: Exception) {
            e.message ?: "Error"
        }
    }
}

/** অ্যাডমিন সেশনের জন্য নির্দিষ্ট ইউজারের ভিউমডেল বানায় */
class MoneyVmFactory(
    private val app: Application,
    private val target: String?,
    private val email: String?
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = MoneyViewModel(app, target, email) as T
}
