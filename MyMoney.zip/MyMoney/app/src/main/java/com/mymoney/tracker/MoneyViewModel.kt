package com.mymoney.tracker

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import com.mymoney.tracker.cloud.Cloud
import com.mymoney.tracker.data.*
import com.mymoney.tracker.sms.SmsImporter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.time.LocalDate
import java.util.UUID

class MoneyViewModel(app: Application) : AndroidViewModel(app) {
    private val db = AppDb.get(app)
    private val dao = db.dao()
    private val prefs = Prefs(app)

    val accounts: StateFlow<List<Account>> =
        dao.accounts().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val cards: StateFlow<List<CreditCard>> =
        dao.cards().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val txns: StateFlow<List<Txn>> =
        dao.txns().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val budgets: StateFlow<List<Budget>> =
        dao.budgets().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val debtors: StateFlow<List<Debtor>> =
        dao.debtors().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val debtorPayments: StateFlow<List<DebtorPayment>> =
        dao.debtorPayments().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val planned: StateFlow<List<Planned>> =
        dao.planned().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val settings = MutableStateFlow(prefs.read())
    private var syncJob: Job? = null

    /** লগইন করা ইমেইল; null = লগইন নেই */
    val account = MutableStateFlow<String?>(Cloud.email(app))

    init {
        viewModelScope.launch {
            if (dao.cashCount() == 0) dao.insertAccount(Account(name = "Cash", isCash = true))
        }
    }

    fun update(f: (SettingsState) -> SettingsState) {
        val n = f(settings.value)
        prefs.write(n)
        settings.value = n
    }

    fun setPin(pin: String) {
        val salt = UUID.randomUUID().toString()
        update { it.copy(pinSalt = salt, pinHash = sha256(salt + pin)) }
    }

    fun verifyPin(pin: String): Boolean {
        val s = settings.value
        return s.pinHash.isNotEmpty() && sha256(s.pinSalt + pin) == s.pinHash
    }

    // ---------- প্রোফাইল ----------
    fun saveProfile(name: String, mobile: String, dob: String) {
        update { it.copy(userName = name, mobile = mobile, dob = dob) }
        val email = account.value
        if (email != null) {
            viewModelScope.launch {
                try {
                    Cloud.setName(name)
                } catch (e: Exception) {
                    // উপেক্ষা
                }
                try {
                    Cloud.saveResetCheck(email, mobile, dob)
                } catch (e: Exception) {
                    // উপেক্ষা
                }
            }
        }
    }

    /** বাছাই করা ছবি ছোট করে ফোনেই রাখে (filesDir/profile.jpg) */
    fun setPhoto(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val ctx = getApplication<Application>()
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    ?: return@launch
                val side = minOf(bmp.width, bmp.height)
                val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
                val scaled = Bitmap.createScaledBitmap(square, 320, 320, true)
                FileOutputStream(File(ctx.filesDir, "profile.jpg")).use { scaled.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                update { it.copy(photoVersion = it.photoVersion + 1) }
            } catch (e: Exception) {
                // উপেক্ষা
            }
        }
    }

    // ---------- এন্ট্রি ----------
    fun saveTxn(t: Txn) = viewModelScope.launch {
        if (t.id == 0L) dao.insertTxn(t) else dao.updateTxn(t)
    }

    fun deleteTxn(t: Txn) = viewModelScope.launch { dao.deleteTxn(t) }

    fun saveAccount(a: Account) = viewModelScope.launch {
        if (a.id == 0L) dao.insertAccount(a) else dao.updateAccount(a)
    }

    fun saveCard(c: CreditCard) = viewModelScope.launch {
        if (c.id == 0L) dao.insertCard(c) else dao.updateCard(c)
    }

    fun saveBudget(category: String, amount: Double) = viewModelScope.launch {
        dao.putBudget(Budget(category, amount))
    }

    fun deleteBudget(category: String) = viewModelScope.launch { dao.deleteBudget(category) }

    // ---------- ঋণগ্রহীতা ----------
    fun saveDebtor(d: Debtor) = viewModelScope.launch {
        if (d.id == 0L) dao.insertDebtor(d) else dao.updateDebtor(d)
    }

    fun deleteDebtor(d: Debtor) = viewModelScope.launch {
        dao.deletePaymentsOf(d.id)
        dao.deleteDebtor(d)
    }

    /** full = true হলে সম্পূর্ণ পরিশোধ ধরে বন্ধ করে; নয়তো পার্ট পেমেন্ট (newPtp দিলে নতুন PTP তারিখ) */
    fun payDebtor(d: Debtor, amount: Double, full: Boolean, newPtp: Long?) = viewModelScope.launch {
        dao.insertDebtorPayment(DebtorPayment(debtorId = d.id, amount = amount,
            dateMillis = LocalDate.now().toMillis(), isFull = full))
        if (full) dao.updateDebtor(d.copy(closed = true, ptpMillis = null))
        else if (newPtp != null) dao.updateDebtor(d.copy(ptpMillis = newPtp))
    }

    // ---------- পরিকল্পিত ব্যয় ----------
    fun savePlanned(p: Planned) = viewModelScope.launch { dao.putPlanned(p) }
    fun deletePlanned(p: Planned) = viewModelScope.launch { dao.deletePlanned(p) }

    // ---------- SMS ----------
    suspend fun importInbox(): Int = SmsImporter.importInbox(getApplication())

    fun autoImportIfAllowed() {
        if (settings.value.autoSms && smsGranted(getApplication())) {
            viewModelScope.launch { SmsImporter.importInbox(getApplication()) }
        }
    }

    fun clearAll() = viewModelScope.launch {
        dao.clearTxns()
        dao.clearSeen()
    }

    // ---------- ক্লাউড অ্যাকাউন্ট ----------
    /** সফল হলে null, ব্যর্থ হলে ত্রুটির বার্তা */
    suspend fun signIn(email: String, pass: String, create: Boolean, name: String, mobile: String, dob: String): String? {
        return try {
            if (create) {
                Cloud.signUp(email, pass)
                try {
                    Cloud.setName(name)
                } catch (e: Exception) {
                    // নাম সেভ না হলেও অ্যাকাউন্ট খোলা হয়েছে
                }
                update { it.copy(userName = name, mobile = mobile, dob = dob) }
                try {
                    Cloud.saveResetCheck(email, mobile, dob)
                } catch (e: Exception) {
                    // Firestore rules হালনাগাদ না থাকলে এটি সেভ হবে না; পরে প্রোফাইল সেভ করলে হবে
                }
            } else {
                Cloud.signIn(email, pass)
            }
            account.value = Cloud.email(getApplication())
            Cloud.resetCache()
            if (!create) {
                restoreIfEmpty()
                val n = Cloud.displayName() ?: ""
                if (settings.value.userName.isBlank() && n.isNotBlank()) update { it.copy(userName = n) }
            }
            null
        } catch (e: Exception) {
            e.message ?: "Error"
        }
    }

    fun signOut() {
        try {
            Cloud.signOut()
        } catch (e: Exception) {
            // উপেক্ষা
        }
        Cloud.resetCache()
        account.value = null
    }

    /** নতুন ফোনে লগইনের পর লোকাল ডেটা খালি থাকলে ক্লাউড থেকে নিজে ফিরিয়ে আনে */
    private suspend fun restoreIfEmpty() {
        try {
            if (dao.txnsOnce().isEmpty() && dao.accountsOnce().size <= 1) restoreNow()
        } catch (e: Exception) {
            // উপেক্ষা
        }
    }

    private suspend fun snapshot(): Cloud.BackupData {
        val s = settings.value
        return Cloud.BackupData(
            dao.accountsOnce(), dao.cardsOnce(), dao.txnsOnce(), dao.seenOnce(), dao.budgetsOnce(),
            dao.debtorsOnce(), dao.debtorPaymentsOnce(), dao.plannedOnce(),
            Cloud.ProfileData(s.userName, s.mobile, s.dob)
        )
    }

    suspend fun backupNow(): String? {
        return try {
            Cloud.backup(snapshot())
            null
        } catch (e: Exception) {
            e.message ?: "Error"
        }
    }

    /** পরিবর্তন হলেই কল হয়; আগের সিঙ্ক চলতে থাকলে বাতিল করে নতুনটা শুরু করে। ফাঁকা ডেটা দিয়ে ভালো ব্যাকআপ মোছা এড়াতে খালি থাকলে সিঙ্ক হয় না। */
    fun backupSilently() {
        syncJob?.cancel()
        syncJob = viewModelScope.launch {
            try {
                val d = snapshot()
                if (d.txns.isEmpty() && d.cards.isEmpty() && d.accs.size <= 1 &&
                    d.debtors.isEmpty() && d.planned.isEmpty()
                ) return@launch
                Cloud.backup(d)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // উপেক্ষা
            }
        }
    }

    /** সফল হলে null; ব্যাকআপ না থাকলে "NO_BACKUP"; অন্যথায় ত্রুটির বার্তা */
    suspend fun restoreNow(): String? {
        return try {
            val snap = Cloud.fetch() ?: return "NO_BACKUP"
            db.withTransaction {
                dao.clearTxns()
                dao.clearCards()
                dao.clearAccounts()
                dao.clearSeen()
                dao.clearBudgets()
                dao.clearDebtors()
                dao.clearDebtorPayments()
                dao.clearPlanned()
                dao.putAccounts(snap.accs)
                dao.putCards(snap.cards)
                dao.putTxns(snap.txns)
                dao.putSeen(snap.seen.map { SmsSeen(it) })
                dao.putBudgets(snap.budgets)
                dao.putDebtors(snap.debtors)
                dao.putDebtorPayments(snap.payments)
                dao.putPlannedList(snap.planned)
            }
            if (snap.profile.name.isNotBlank()) {
                update { it.copy(userName = snap.profile.name, mobile = snap.profile.mobile, dob = snap.profile.dob) }
            }
            null
        } catch (e: Exception) {
            e.message ?: "Error"
        }
    }
}
