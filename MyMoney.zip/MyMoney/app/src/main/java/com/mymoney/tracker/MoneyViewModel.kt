package com.mymoney.tracker

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mymoney.tracker.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MoneyViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()

    val accounts: StateFlow<List<Account>> =
        dao.accounts().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val txns: StateFlow<List<Txn>> =
        dao.txns().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        viewModelScope.launch {
            if (dao.cashCount() == 0) dao.insertAccount(Account(name = "Cash", isCash = true))
        }
    }

    fun saveTxn(t: Txn) = viewModelScope.launch {
        if (t.id == 0L) dao.insertTxn(t) else dao.updateTxn(t)
    }

    fun deleteTxn(t: Txn) = viewModelScope.launch { dao.deleteTxn(t) }

    fun saveAccount(a: Account) = viewModelScope.launch {
        if (a.id == 0L) dao.insertAccount(a) else dao.updateAccount(a)
    }
}
