package com.mymoney.tracker

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import com.mymoney.tracker.cloud.Cloud
import com.mymoney.tracker.data.*
import com.mymoney.tracker.sms.SmsImporter
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class MoneyViewModel(app: Application) : AndroidViewModel(app) {
    private val db = AppDb.get(app)
    private val dao = db.dao()
    private val prefs = Prefs(app)

    val accounts: StateFlow<List<Account>> =
        dao.accounts().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val cards: StateFlow<List<CreditCard>> =
        dao.cards().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val txns: StateFlow<List<Txn>> =
        dao.txns().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val settings = MutableStateFlow(prefs.read())

    /** লগইন করা ইমেইল; null = লগইন নেই */
    val account = MutableStateFlow<String?>(Cloud.email(app))

    init {
        viewModelScope.launch {
            if (dao.cashCount() == 0) dao.insertAccount(Account(name = "Cash", isCash = true))
        }
    }

    fun update(f: (SettingsState) -> SettingsState) {
        val n = f(settings.value)
        prefs.write(n)
        settings.value = n
    }

    fun setPin(pin: String) {
        val salt = UUID.randomUUID().toString()
        update { it.copy(pinSalt = salt, pinHash = sha256(salt + pin)) }
    }

    fun verifyPin(pin: String): Boolean {
        val s = settings.value
        return s.pinHash.isNotEmpty() && sha256(s.pinSalt + pin) == s.pinHash
    }

    fun saveTxn(t: Txn) = viewModelScope.launch {
        if (t.id == 0L) dao.insertTxn(t) else dao.updateTxn(t)
    }

    fun deleteTxn(t: Txn) = viewModelScope.launch { dao.deleteTxn(t) }

    fun saveAccount(a: Account) = viewModelScope.launch {
        if (a.id == 0L) dao.insertAccount(a) else dao.updateAccount(a)
    }

    fun saveCard(c: CreditCard) = viewModelScope.launch {
        if (c.id == 0L) dao.insertCard(c) else dao.updateCard(c)
    }

    suspend fun importInbox(): Int = SmsImporter.importInbox(getApplication())

    fun autoImportIfAllowed() {
        if (settings.value.autoSms && smsGranted(getApplication())) {
            viewModelScope.launch { SmsImporter.importInbox(getApplication()) }
        }
    }

    fun clearAll() = viewModelScope.launch {
        dao.clearTxns()
        dao.clearSeen()
    }

    // ---------- ক্লাউড অ্যাকাউন্ট ----------
    /** সফল হলে null, ব্যর্থ হলে ত্রুটির বার্তা */
    suspend fun signIn(email: String, pass: String, create: Boolean): String? {
        return try {
            if (create) Cloud.signUp(email, pass) else Cloud.signIn(email, pass)
            account.value = Cloud.email(getApplication())
            if (!create) restoreIfEmpty()
            null
        } catch (e: Exception) {
            e.message ?: "Error"
        }
    }

    suspend fun resetPassword(email: String): String? {
        return try {
            Cloud.reset(email)
            null
        } catch (e: Exception) {
            e.message ?: "Error"
        }
    }

    fun signOut() {
        try {
            Cloud.signOut()
        } catch (e: Exception) {
            // উপেক্ষা
        }
        account.value = null
    }

    /** নতুন ফোনে লগইনের পর লোকাল ডেটা খালি থাকলে ক্লাউড থেকে নিজে ফিরিয়ে আনে */
    private suspend fun restoreIfEmpty() {
        try {
            if (dao.txnsOnce().isEmpty() && dao.accountsOnce().size <= 1) restoreNow()
        } catch (e: Exception) {
            // উপেক্ষা
        }
    }

    suspend fun backupNow(): String? {
        return try {
            Cloud.backup(dao.accountsOnce(), dao.cardsOnce(), dao.txnsOnce(), dao.seenOnce())
            null
        } catch (e: Exception) {
            e.message ?: "Error"
        }
    }

    /** ফাঁকা ডেটা দিয়ে ভালো ব্যাকআপ যাতে মুছে না যায়, তাই খালি থাকলে ব্যাকআপ হয় না */
    fun backupSilently() {
        viewModelScope.launch {
            try {
                val a = dao.accountsOnce()
                val c = dao.cardsOnce()
                val t = dao.txnsOnce()
                if (t.isEmpty() && c.isEmpty() && a.size <= 1) return@launch
                Cloud.backup(a, c, t, dao.seenOnce())
            } catch (e: Exception) {
                // উপেক্ষা
            }
        }
    }

    /** সফল হলে null; ব্যাকআপ না থাকলে "NO_BACKUP"; অন্যথায় ত্রুটির বার্তা */
    suspend fun restoreNow(): String? {
        return try {
            val snap = Cloud.fetch() ?: return "NO_BACKUP"
            db.withTransaction {
                dao.clearTxns()
                dao.clearCards()
                dao.clearAccounts()
                dao.clearSeen()
                dao.putAccounts(snap.accs)
                dao.putCards(snap.cards)
                dao.putTxns(snap.txns)
                dao.putSeen(snap.seen.map { SmsSeen(it) })
            }
            null
        } catch (e: Exception) {
            e.message ?: "Error"
        }
    }
}
