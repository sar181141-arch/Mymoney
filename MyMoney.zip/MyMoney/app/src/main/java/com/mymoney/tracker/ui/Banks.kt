package com.mymoney.tracker.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mymoney.tracker.data.*

/** সেটিংসের ব্যাংক অ্যাকাউন্ট তালিকা; ট্যাপ করলে ওই অ্যাকাউন্টের স্টেটমেন্ট খোলে */
@Composable
fun BanksScreen(accs: List<Account>, txns: List<Txn>, onOpen: (Long) -> Unit) {
    val bal = remember(accs, txns) { accountBalances(accs, txns) }
    val banks = accs.filter { !it.isCash }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (banks.isEmpty()) {
            item { Text(tr("কোনো ব্যাংক অ্যাকাউন্ট যোগ করা হয়নি। অ্যাকাউন্ট ট্যাবে গিয়ে যোগ করুন।", "No bank accounts yet. Add one in the Accounts tab.")) }
        }
        items(banks, key = { it.id }) { a ->
            Card(Modifier.fillMaxWidth().clickable { onOpen(a.id) }) {
                Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(a.name, fontWeight = FontWeight.Bold)
                        Text("A/c ••••${a.last5}", style = MaterialTheme.typography.bodySmall)
                        Text(tr("স্টেটমেন্ট ও PDF ▸", "Statement & PDF ▸"), style = MaterialTheme.typography.labelSmall)
                    }
                    Text(money(bal[a.id] ?: 0.0), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
