package com.mymoney.tracker.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import java.security.MessageDigest
import java.time.LocalDate

data class SettingsState(
    val lang: String = "bn",            // bn | en
    val theme: String = "system",       // system | light | dark
    val fontSize: String = "medium",    // small | medium | large | xlarge
    val lockEnabled: Boolean = true,
    val lockTimeout: Int = 30,          // সেকেন্ড; ০ = সাথে সাথে
    val biometric: Boolean = false,
    val autoSms: Boolean = true,
    val autoBackup: Boolean = true,
    val smsStart: String = "2026-10-01",
    val pinHash: String = "",
    val pinSalt: String = ""
)

fun SettingsState.startDate(): LocalDate =
    runCatching { LocalDate.parse(smsStart) }.getOrDefault(LocalDate.of(2026, 10, 1))

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun read() = SettingsState(
        lang = sp.getString("lang", "bn") ?: "bn",
        theme = sp.getString("theme", "system") ?: "system",
        fontSize = sp.getString("fontSize", "medium") ?: "medium",
        lockEnabled = sp.getBoolean("lockEnabled", true),
        lockTimeout = sp.getInt("lockTimeout", 30),
        biometric = sp.getBoolean("biometric", false),
        autoSms = sp.getBoolean("autoSms", true),
        autoBackup = sp.getBoolean("autoBackup", true),
        smsStart = sp.getString("smsStart", "2026-10-01") ?: "2026-10-01",
        pinHash = sp.getString("pinHash", "") ?: "",
        pinSalt = sp.getString("pinSalt", "") ?: ""
    )

    fun write(s: SettingsState) {
        sp.edit()
            .putString("lang", s.lang)
            .putString("theme", s.theme)
            .putString("fontSize", s.fontSize)
            .putBoolean("lockEnabled", s.lockEnabled)
            .putInt("lockTimeout", s.lockTimeout)
            .putBoolean("biometric", s.biometric)
            .putBoolean("autoSms", s.autoSms)
            .putBoolean("autoBackup", s.autoBackup)
            .putString("smsStart", s.smsStart)
            .putString("pinHash", s.pinHash)
            .putString("pinSalt", s.pinSalt)
            .apply()
    }
}

fun sha256(s: String): String =
    MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

fun smsGranted(ctx: Context): Boolean =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED &&
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
