package com.mymoney.tracker.ui

import androidx.compose.runtime.Composable

/** পুরো অ্যাপে কমন খাতের তালিকা (ইংরেজি নামে সেভ হয়, ভাষা অনুযায়ী দেখায়) */
object Cats {
    val common = listOf("Tuition Fee", "School Fee", "Abacus Fee", "EMI", "Grocery", "Fuel", "Milk", "Water")
    val expense = common + "Other"
    val income = listOf("Salary", "Business", "Interest", "Rental income", "Other")
}

@Composable
fun catLabel(c: String): String {
    if (LocalLang.current != "bn") return c
    return when (c) {
        "Tuition Fee" -> "টিউশন ফি"
        "School Fee" -> "স্কুল ফি"
        "Salary" -> "বেতন"
        "Business" -> "ব্যবসা"
        "Interest" -> "সুদ"
        "Rental income" -> "ভাড়া আয়"
        "Other" -> "অন্যান্য"
        else -> c
    }
}
