package com.mymoney.tracker.ui

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.mymoney.tracker.data.SettingsState

fun biometricAvailable(ctx: Context): Boolean =
    BiometricManager.from(ctx).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) ==
        BiometricManager.BIOMETRIC_SUCCESS

fun showBiometric(activity: FragmentActivity, title: String, negative: String, onOk: () -> Unit) {
    val executor = ContextCompat.getMainExecutor(activity)
    val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
            onOk()
        }
    })
    val info = BiometricPrompt.PromptInfo.Builder()
        .setTitle(title)
        .setNegativeButtonText(negative)
        .build()
    prompt.authenticate(info)
}

@Composable
fun PinField(value: String, onChange: (String) -> Unit, label: String) {
    OutlinedTextField(
        value = value,
        onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) onChange(it) },
        label = { Text(label) },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        modifier = Modifier.fillMaxWidth()
    )
}

/** প্রথমবার অ্যাপ খুললে PIN সেট করার স্ক্রিন */
@Composable
fun SetPinScreen(onSet: (String) -> Unit) {
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    val e1 = tr("PIN কমপক্ষে ৪ ডিজিট হতে হবে", "PIN must be at least 4 digits")
    val e2 = tr("দুটি PIN মেলেনি", "PINs do not match")
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("My Hisab", style = MaterialTheme.typography.headlineMedium)
        Text(tr("অ্যাপ সুরক্ষার জন্য একটি PIN সেট করুন (৪-৬ ডিজিট)", "Set a PIN to protect the app (4-6 digits)"))
        PinField(a, { a = it }, tr("নতুন PIN", "New PIN"))
        PinField(b, { b = it }, tr("PIN আবার লিখুন", "Confirm PIN"))
        err?.let { Text(it, color = Red) }
        Button({
            if (a.length < 4) err = e1 else if (a != b) err = e2 else onSet(a)
        }, Modifier.fillMaxWidth()) { Text(tr("সেভ করুন", "Save")) }
    }
}

/** অ্যাপে ঢোকার লগইন (PIN / ফিঙ্গারপ্রিন্ট) */
@Composable
fun LockScreen(st: SettingsState, verify: (String) -> Boolean, onUnlock: () -> Unit) {
    val ctx = LocalContext.current
    val activity = ctx as? FragmentActivity
    val bioOk = remember { biometricAvailable(ctx) }
    var pin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    val wrong = tr("ভুল PIN", "Wrong PIN")
    val bioTitle = tr("My Hisab আনলক করুন", "Unlock My Hisab")
    val bioNeg = tr("PIN ব্যবহার করুন", "Use PIN")

    LaunchedEffect(Unit) {
        if (st.biometric && bioOk && activity != null) showBiometric(activity, bioTitle, bioNeg, onUnlock)
    }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("My Hisab", style = MaterialTheme.typography.headlineMedium)
        Text(tr("PIN দিয়ে লগইন করুন", "Log in with your PIN"))
        PinField(pin, { pin = it; err = null }, "PIN")
        err?.let { Text(it, color = Red) }
        Button({
            if (verify(pin)) onUnlock() else { err = wrong; pin = "" }
        }, Modifier.fillMaxWidth()) { Text(tr("লগইন", "Log in")) }
        if (st.biometric && bioOk && activity != null) {
            OutlinedButton({ showBiometric(activity, bioTitle, bioNeg, onUnlock) }, Modifier.fillMaxWidth()) {
                Text(tr("ফিঙ্গারপ্রিন্ট দিয়ে খুলুন", "Use fingerprint"))
            }
        }
    }
}

@Composable
fun PinVerifyDialog(title: String, verify: (String) -> Boolean, onOk: () -> Unit, onDismiss: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    val wrong = tr("ভুল PIN", "Wrong PIN")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PinField(pin, { pin = it; err = null }, "PIN")
                err?.let { Text(it, color = Red) }
            }
        },
        confirmButton = { TextButton({ if (verify(pin)) onOk() else err = wrong }) { Text("OK") } },
        dismissButton = { TextButton(onDismiss) { Text(tr("বাতিল", "Cancel")) } }
    )
}

@Composable
fun ChangePinDialog(verify: (String) -> Boolean, onSet: (String) -> Unit, onDismiss: () -> Unit) {
    var stage by remember { mutableIntStateOf(0) }
    var cur by remember { mutableStateOf("") }
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    val wrong = tr("ভুল PIN", "Wrong PIN")
    val e1 = tr("PIN কমপক্ষে ৪ ডিজিট হতে হবে", "PIN must be at least 4 digits")
    val e2 = tr("দুটি PIN মেলেনি", "PINs do not match")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("PIN বদলান", "Change PIN")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (stage == 0) {
                    PinField(cur, { cur = it; err = null }, tr("বর্তমান PIN", "Current PIN"))
                } else {
                    PinField(a, { a = it; err = null }, tr("নতুন PIN", "New PIN"))
                    PinField(b, { b = it; err = null }, tr("নতুন PIN আবার", "Confirm new PIN"))
                }
                err?.let { Text(it, color = Red) }
            }
        },
        confirmButton = {
            TextButton({
                if (stage == 0) {
                    if (verify(cur)) stage = 1 else err = wrong
                } else {
                    if (a.length < 4) err = e1 else if (a != b) err = e2 else onSet(a)
                }
            }) { Text(if (stage == 0) tr("পরবর্তী", "Next") else tr("সেভ", "Save")) }
        },
        dismissButton = { TextButton(onDismiss) { Text(tr("বাতিল", "Cancel")) } }
    )
}
