package com.mymoney.tracker.sms

import com.mymoney.tracker.data.Account
import com.mymoney.tracker.data.CreditCard
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

data class Parsed(
    val type: String,
    val amount: Double,
    val accountId: Long,
    val cardId: Long?,
    val category: String,
    val note: String,
    val date: LocalDate,
    val balance: Double?
)

/**
 * SBI, Axis Bank, Airtel Payments Bank (UPI সহ) ডেবিট/ক্রেডিট এবং সাধারণ ক্রেডিট কার্ড খরচের SMS পার্স করে।
 * SMS-এ অ্যাকাউন্টের শেষ ৪ ডিজিট থাকলে সেটি আপনার দেওয়া শেষ ৫ ডিজিটের শেষ ৪টির সাথে মেলানো হয়।
 * Airtel Payments Bank-এর মতো যেখানে কোনো নম্বর নেই, সেখানে ব্যাংকের নামের প্রথম শব্দ দিয়ে মেলানো হয়।
 */
object SmsParser {
    private val reject = Regex("(?i)\\b(otp|will be debited|will be credited|failed|declined|unsuccessful|mandate|collect request)\\b")
    private val amtBy = Regex("(?i)(?:debited|credited)\\s+by\\s+(?:Rs\\.?|INR|₹)?\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)")
    private val amtCur = Regex("(?i)(?:Rs\\.?|INR|₹)\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)")
    private val debitW = Regex("(?i)\\b(debited|spent|withdrawn|purchase|paid|deducted|charged|sent to|paid to|transferred to)\\b")
    private val creditW = Regex("(?i)\\b(credited|received|deposited|credit of|received from)\\b")
    private val balRe = Regex("(?i)(?:avl\\.?\\s*bal(?:ance)?|available\\s+bal(?:ance)?|\\bbal(?:ance)?)\\s*(?:is|:|-)?\\s*(?:Rs\\.?|INR|₹)?\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)")
    private val masked = Regex("(?<![A-Za-z])[xX*]+\\s?(\\d{4,6})(?!\\d)")
    private val ending = Regex("(?i)(?:ending(?:\\s+with|\\s+in)?|a/c(?:\\s+no\\.?)?|card(?:\\s+no\\.?)?)\\s*:?\\s*(\\d{4,6})(?!\\d)")
    private val cardW = Regex("(?i)\\bcard\\b")
    private val acctW = Regex("(?i)\\b(a/c|account)\\b")

    private val months = mapOf(
        "jan" to 1, "feb" to 2, "mar" to 3, "apr" to 4, "may" to 5, "jun" to 6,
        "jul" to 7, "aug" to 8, "sep" to 9, "oct" to 10, "nov" to 11, "dec" to 12
    )
    private val dNum = Regex("(?<![0-9])(\\d{1,2})[-/](\\d{1,2})[-/](\\d{2,4})(?!\\d)")
    private val dMon = Regex("(?<![0-9])(\\d{1,2})[\\s\\-/]?([A-Za-z]{3})[A-Za-z]*[\\s\\-/,]*(\\d{2,4})(?!\\d)")

    private val merchantPatterns = listOf(
        Regex("(?i)trf to\\s+(.+?)\\s+Ref\\s*no"),
        Regex("(?i)transfer from\\s+(.+?)\\s+Ref\\s*no"),
        Regex("UPI/[A-Za-z0-9]+/\\d+/([^\\r\\n]+)"),
        Regex("(?i)\\bRef:\\s*(.+)\$"),
        Regex("(?i)\\b(?:at|to)\\s+([A-Za-z0-9][A-Za-z0-9 &.*_-]{2,30}?)\\s+(?:on|Ref|Avl|Bal)\\b")
    )

    /** অ্যাকাউন্টের নামের প্রথম শব্দ (যেমন "Airtel Payments Bank" → "Airtel") */
    private fun bankWord(name: String): String =
        name.trim().split(Regex("\\s+")).firstOrNull() ?: ""

    private fun mkDate(d: Int, m: Int, y: Int): LocalDate? =
        runCatching { LocalDate.of(if (y < 100) 2000 + y else y, m, d) }.getOrNull()

    private fun parseDate(b: String): LocalDate? {
        for (m in dNum.findAll(b)) {
            val (d, mo, y) = m.destructured
            mkDate(d.toInt(), mo.toInt(), y.toInt())?.let { return it }
        }
        for (m in dMon.findAll(b)) {
            val (d, mon, y) = m.destructured
            val mo = months[mon.lowercase()] ?: continue
            mkDate(d.toInt(), mo, y.toInt())?.let { return it }
        }
        return null
    }

    private fun merchant(b: String): String {
        for (r in merchantPatterns) {
            val m = r.find(b)
            if (m != null) return m.groupValues[1].trim().take(40)
        }
        return ""
    }

    /** লেনদেনের পরিমাণ; "Bal ..." এর পরের অঙ্ক বাদ দেওয়া হয় */
    private fun findAmount(body: String): Double? {
        val by = amtBy.find(body)
        if (by != null) return by.groupValues[1].replace(",", "").toDoubleOrNull()
        for (m in amtCur.findAll(body)) {
            val pre = body.substring(maxOf(0, m.range.first - 16), m.range.first)
            if (pre.contains("bal", ignoreCase = true)) continue
            return m.groupValues[1].replace(",", "").toDoubleOrNull()
        }
        return null
    }

    private fun findBalance(body: String): Double? =
        balRe.find(body)?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull()

    fun parse(body: String, ts: Long, accs: List<Account>, cards: List<CreditCard>): Parsed? {
        if (reject.containsMatchIn(body)) return null
        val d = debitW.find(body)
        val c = creditW.find(body)
        if (d == null && c == null) return null
        // যে শব্দ আগে এসেছে সেটাই লেনদেনের দিক
        val isDebit = d != null && (c == null || d.range.first < c.range.first)

        val amount = findAmount(body) ?: return null
        if (amount <= 0) return null

        val cands = LinkedHashSet<String>()
        masked.findAll(body).forEach { cands.add(it.groupValues[1]) }
        ending.findAll(body).forEach { cands.add(it.groupValues[1]) }

        var card: CreditCard? = null
        if (cardW.containsMatchIn(body)) {
            card = cards.firstOrNull { cc -> cands.any { it.takeLast(4) == cc.last4 } }
        }
        val acc: Account? = if (card == null) {
            accs.firstOrNull { a ->
                !a.isCash && a.last5.isNotEmpty() && cands.any {
                    val x = it.takeLast(5)
                    a.last5.endsWith(x) || x.endsWith(a.last5)
                }
            } ?: run {
                // Airtel Payments Bank-এর মতো যে SMS-এ অ্যাকাউন্ট নম্বরই থাকে না: ব্যাংকের নাম দিয়ে মেলানো
                if (cands.isEmpty() && acctW.containsMatchIn(body)) {
                    val hits = accs.filter { a ->
                        val w = bankWord(a.name)
                        !a.isCash && w.length >= 3 &&
                            Regex("(?i)\\b" + Regex.escape(w) + "\\b").containsMatchIn(body)
                    }
                    if (hits.size == 1) hits[0] else null
                } else null
            }
        } else null

        if (card == null && acc == null) return null
        if (card != null && !isDebit) return null // কার্ডে ক্রেডিট (পেমেন্ট/রিফান্ড) আপাতত বাদ

        val note = merchant(body)
        val type = if (isDebit) "EXPENSE" else "INCOME"
        val category = if (!isDebit && note.contains("SALAR", ignoreCase = true)) "বেতন" else ""
        val date = parseDate(body)
            ?: Instant.ofEpochMilli(ts).atZone(ZoneId.systemDefault()).toLocalDate()
        return Parsed(type, amount, acc?.id ?: 0L, card?.id, category, note, date, findBalance(body))
    }
}
