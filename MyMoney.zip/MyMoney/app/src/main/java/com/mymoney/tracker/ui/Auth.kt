package com.mymoney.tracker.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mymoney.tracker.MoneyViewModel
import com.mymoney.tracker.cloud.Cloud
import kotlinx.coroutines.launch

/** ইমেইলের লিংক বা শুধু কোড যা-ই পেস্ট করা হোক, থেকে oobCode বের করে */
private fun extractCode(s: String): String {
    val m = Regex("oobCode=([^&\\s]+)").find(s)
    return (m?.groupValues?.get(1) ?: s).trim()
}

/** লগইন / নতুন অ্যাকাউন্ট (নাম, মোবাইল, ইমেইল, জন্মতারিখ) / পাসওয়ার্ড ভুলে গেলে রিসেট */
@Composable
fun AuthScreen(vm: MoneyViewModel) {
    val scope = rememberCoroutineScope()
    var mode by remember { mutableStateOf("login") } // login | signup | forgot1 | forgot2 | forgot3
    var name by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var dob by remember { mutableStateOf<Long?>(null) }
    var pass by remember { mutableStateOf("") }
    var pass2 by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var resetCode by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    var noCheck by remember { mutableStateOf(false) }
    val dobStr = dob?.let { millisToDate(it).toString() } ?: ""

    val invalid = tr("সঠিক ইমেইল ও কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন", "Enter a valid email and a password of at least 6 characters")
    val needName = tr("আপনার নাম লিখুন", "Enter your name")
    val needMobile = tr("১০ ডিজিটের মোবাইল নম্বর দিন", "Enter a 10-digit mobile number")
    val needEmail = tr("সঠিক ইমেইল দিন", "Enter a valid email")
    val needDob = tr("জন্মতারিখ বেছে নিন", "Choose your date of birth")
    val noMatch = tr("দুটি পাসওয়ার্ড মেলেনি", "The two passwords do not match")
    val needAll = tr("ইমেইল, মোবাইল নম্বর ও জন্মতারিখ দিন", "Enter email, mobile number and date of birth")
    val mismatch = tr("মোবাইল নম্বর বা জন্মতারিখ মেলেনি", "Mobile number or date of birth did not match")
    val noCheckMsg = tr("এই অ্যাকাউন্টে মোবাইল/জন্মতারিখ সেট করা নেই। চাইলে শুধু ইমেইলে রিসেট কোড পাঠাতে পারেন।",
        "No mobile/date of birth is set on this account. You can still send the reset code by email only.")
    val sentMsg = tr("ইমেইলে রিসেট লিংক পাঠানো হয়েছে", "A reset link has been sent to your email")
    val needCode = tr("ইমেইলের লিংক বা কোড পেস্ট করুন", "Paste the link or code from the email")
    val doneMsg = tr("নতুন পাসওয়ার্ড সেট হয়েছে। এখন লগইন করুন।", "New password set. Please log in.")
    val newLabel = tr("নতুন পাসওয়ার্ড", "New password")
    val confirmLabel = tr("পাসওয়ার্ড আবার লিখুন", "Confirm password")

    fun goMode(m: String) {
        mode = m
        msg = null
        info = null
        noCheck = false
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("My Hisab", style = MaterialTheme.typography.headlineMedium)
        when (mode) {
            "login" -> {
                Text(tr("আপনার অ্যাকাউন্টে লগইন করুন। ফোন বদলালেও একই অ্যাকাউন্টে লগইন করলে হিসাব ফিরে পাবেন।",
                    "Log in to your account. On a new phone, log in with the same account to get your data back."),
                    textAlign = TextAlign.Center)
                OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth())
                PasswordField(pass, { pass = it }, tr("পাসওয়ার্ড", "Password"))
                Button({
                    if (email.isBlank() || pass.length < 6) {
                        msg = invalid
                    } else {
                        scope.launch {
                            busy = true; msg = null; info = null
                            msg = vm.signIn(email.trim(), pass, false, "", "", "")
                            busy = false
                        }
                    }
                }, Modifier.fillMaxWidth(), enabled = !busy) { Text(tr("লগইন", "Log in")) }
                OutlinedButton({ goMode("signup") }, Modifier.fillMaxWidth()) { Text(tr("নতুন অ্যাকাউন্ট খুলুন", "Create new account")) }
                TextButton({ goMode("forgot1") }) { Text(tr("পাসওয়ার্ড ভুলে গেছেন?", "Forgot password?")) }
            }
            "signup" -> {
                Text(tr("নতুন অ্যাকাউন্ট", "Create account"), style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(name, { name = it }, label = { Text(tr("আপনার নাম", "Your name")) }, singleLine = true,
                    modifier = Modifier.fillMaxWidth())
                OutlinedTextField(mobile, { mobile = it }, label = { Text(tr("মোবাইল নম্বর", "Mobile number")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth())
                DateField(tr("জন্মতারিখ", "Date of birth"), dob, { dob = it })
                PasswordField(pass, { pass = it }, tr("পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)", "Password (min 6 characters)"))
                PasswordField(pass2, { pass2 = it }, confirmLabel)
                Button({
                    if (name.isBlank()) {
                        msg = needName
                    } else if (normMobile(mobile).length < 10) {
                        msg = needMobile
                    } else if (!email.contains("@")) {
                        msg = needEmail
                    } else if (dob == null) {
                        msg = needDob
                    } else if (pass.length < 6) {
                        msg = invalid
                    } else if (pass != pass2) {
                        msg = noMatch
                    } else {
                        scope.launch {
                            busy = true; msg = null; info = null
                            msg = vm.signIn(email.trim(), pass, true, name.trim(), normMobile(mobile), dobStr)
                            busy = false
                        }
                    }
                }, Modifier.fillMaxWidth(), enabled = !busy) { Text(tr("অ্যাকাউন্ট খুলুন", "Create account")) }
            }
            "forgot1" -> {
                Text(tr("পাসওয়ার্ড রিসেট", "Reset password"), style = MaterialTheme.typography.titleMedium)
                Text(tr("অ্যাকাউন্ট খোলার সময় দেওয়া ইমেইল, মোবাইল নম্বর ও জন্মতারিখ মেলালে ইমেইলে রিসেট কোড/লিংক যাবে।",
                    "If your email, mobile number and date of birth match, a reset code/link is sent to your email."),
                    textAlign = TextAlign.Center)
                OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(mobile, { mobile = it }, label = { Text(tr("মোবাইল নম্বর", "Mobile number")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
                DateField(tr("জন্মতারিখ", "Date of birth"), dob, { dob = it })
                Button({
                    if (email.isBlank() || normMobile(mobile).length < 10 || dob == null) {
                        msg = needAll
                    } else {
                        scope.launch {
                            busy = true; msg = null; info = null; noCheck = false
                            try {
                                when (Cloud.verifyResetCheck(email.trim(), normMobile(mobile), dobStr)) {
                                    0 -> {
                                        Cloud.reset(email.trim())
                                        info = sentMsg
                                        mode = "forgot2"
                                    }
                                    1 -> { msg = mismatch }
                                    else -> {
                                        msg = noCheckMsg
                                        noCheck = true
                                    }
                                }
                            } catch (e: Exception) {
                                msg = e.message ?: "Error"
                            }
                            busy = false
                        }
                    }
                }, Modifier.fillMaxWidth(), enabled = !busy) { Text(tr("যাচাই করে কোড পাঠান", "Verify & send code")) }
                if (noCheck) {
                    OutlinedButton({
                        scope.launch {
                            busy = true; msg = null
                            try {
                                Cloud.reset(email.trim())
                                info = sentMsg
                                noCheck = false
                                mode = "forgot2"
                            } catch (e: Exception) {
                                msg = e.message ?: "Error"
                            }
                            busy = false
                        }
                    }, Modifier.fillMaxWidth(), enabled = !busy && email.isNotBlank()) {
                        Text(tr("শুধু ইমেইলে রিসেট কোড পাঠান", "Send reset code by email only"))
                    }
                }
            }
            "forgot2" -> {
                Text(tr("রিসেট কোড দিন", "Enter reset code"), style = MaterialTheme.typography.titleMedium)
                Text(tr("আপনার ইমেইলে একটি রিসেট লিংক গেছে। লিংকে চেপে ধরে 'Copy link' করে এখানে পেস্ট করুন (পুরো লিংক বা তার কোড, দুটোই চলবে)।",
                    "A reset link was emailed to you. Long-press the link, choose 'Copy link' and paste it here (the full link or just its code works)."),
                    textAlign = TextAlign.Center)
                OutlinedTextField(code, { code = it }, label = { Text(tr("ইমেইলের লিংক / কোড", "Link / code from email")) },
                    modifier = Modifier.fillMaxWidth())
                Button({
                    scope.launch {
                        busy = true; msg = null; info = null
                        try {
                            val c = extractCode(code)
                            if (c.isBlank()) {
                                msg = needCode
                            } else {
                                Cloud.verifyResetCode(c)
                                resetCode = c
                                pass = ""
                                pass2 = ""
                                mode = "forgot3"
                            }
                        } catch (e: Exception) {
                            msg = e.message ?: "Error"
                        }
                        busy = false
                    }
                }, Modifier.fillMaxWidth(), enabled = !busy) { Text(tr("পরবর্তী", "Next")) }
            }
            else -> {
                Text(tr("নতুন পাসওয়ার্ড সেট করুন", "Set new password"), style = MaterialTheme.typography.titleMedium)
                PasswordField(pass, { pass = it }, newLabel)
                PasswordField(pass2, { pass2 = it }, confirmLabel)
                Button({
                    if (pass.length < 6) {
                        msg = invalid
                    } else if (pass != pass2) {
                        msg = noMatch
                    } else {
                        scope.launch {
                            busy = true; msg = null; info = null
                            try {
                                Cloud.confirmReset(resetCode, pass)
                                pass = ""
                                pass2 = ""
                                mode = "login"
                                info = doneMsg
                            } catch (e: Exception) {
                                msg = e.message ?: "Error"
                            }
                            busy = false
                        }
                    }
                }, Modifier.fillMaxWidth(), enabled = !busy) { Text(tr("পাসওয়ার্ড সেট করুন", "Set password")) }
            }
        }
        msg?.let { Text(it, color = Red, textAlign = TextAlign.Center) }
        info?.let { Text(it, textAlign = TextAlign.Center) }
        if (busy) CircularProgressIndicator()
        if (mode != "login") TextButton({ goMode("login") }) { Text(tr("← লগইনে ফিরে যান", "← Back to login")) }
    }
}
