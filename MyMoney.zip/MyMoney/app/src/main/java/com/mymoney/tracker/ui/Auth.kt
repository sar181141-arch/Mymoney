package com.mymoney.tracker.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.dp
import com.mymoney.tracker.MoneyViewModel
import kotlinx.coroutines.launch

/** অ্যাকাউন্ট লগইন / নতুন অ্যাকাউন্ট (ইমেইল + পাসওয়ার্ড) */
@Composable
fun AuthScreen(vm: MoneyViewModel) {
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    val invalid = tr("সঠিক ইমেইল ও কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন", "Enter a valid email and a password of at least 6 characters")
    val needEmail = tr("আগে ইমেইল লিখুন", "Enter your email first")
    val resetSent = tr("পাসওয়ার্ড রিসেটের লিংক ইমেইলে পাঠানো হয়েছে", "Password reset link sent to your email")

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("My Hisab", style = MaterialTheme.typography.headlineMedium)
        Text(tr("আপনার অ্যাকাউন্টে লগইন করুন। ফোন বদলালেও একই অ্যাকাউন্টে লগইন করলে হিসাব ফিরে পাবেন।",
            "Log in to your account. On a new phone, log in with the same account to get your data back."))
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(pass, { pass = it }, label = { Text(tr("পাসওয়ার্ড", "Password")) }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth())
        msg?.let { Text(it, color = Red) }
        info?.let { Text(it) }
        if (busy) CircularProgressIndicator()
        Button({
            if (email.isBlank() || pass.length < 6) {
                msg = invalid
            } else {
                scope.launch {
                    busy = true; msg = null; info = null
                    msg = vm.signIn(email.trim(), pass, false)
                    busy = false
                }
            }
        }, Modifier.fillMaxWidth(), enabled = !busy) { Text(tr("লগইন", "Log in")) }
        OutlinedButton({
            if (email.isBlank() || pass.length < 6) {
                msg = invalid
            } else {
                scope.launch {
                    busy = true; msg = null; info = null
                    msg = vm.signIn(email.trim(), pass, true)
                    busy = false
                }
            }
        }, Modifier.fillMaxWidth(), enabled = !busy) { Text(tr("নতুন অ্যাকাউন্ট খুলুন", "Create new account")) }
        TextButton({
            if (email.isBlank()) {
                msg = needEmail
            } else {
                scope.launch {
                    busy = true; msg = null; info = null
                    val err = vm.resetPassword(email.trim())
                    if (err == null) info = resetSent else msg = err
                    busy = false
                }
            }
        }, enabled = !busy) { Text(tr("পাসওয়ার্ড ভুলে গেছেন?", "Forgot password?")) }
    }
}
