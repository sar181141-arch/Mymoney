package com.mymoney.tracker.sms

import android.content.Context
import android.provider.Telephony
import com.mymoney.tracker.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object SmsImporter {

    /** একটি SMS প্রসেস করে; নতুন এন্ট্রি হলে true */
    suspend fun importOne(ctx: Context, body: String, ts: Long): Boolean {
        val dao = AppDb.get(ctx).dao()
        val start = Prefs(ctx).read().startDate()
        val p = SmsParser.parse(body, ts, dao.accountsOnce(), dao.cardsOnce()) ?: return false
        if (p.date.isBefore(start)) return false
        val hash = sha256(body.trim())
        if (dao.insertSeen(SmsSeen(hash)) == -1L) return false
        dao.insertTxn(
            Txn(
                type = p.type,
                amount = p.amount,
                accountId = p.accountId,
                cardId = p.cardId,
                category = p.category,
                note = p.note,
                dateMillis = p.date.toMillis(),
                source = "SMS"
            )
        )
        return true
    }

    /** ইনবক্স থেকে শুরুর তারিখ পরবর্তী SMS ইমপোর্ট; কতটি নতুন এন্ট্রি হলো তা ফেরত দেয় */
    suspend fun importInbox(ctx: Context): Int = withContext(Dispatchers.IO) {
        var n = 0
        val startMs = Prefs(ctx).read().startDate().minusDays(1).toMillis()
        val cur = ctx.contentResolver.query(
            Telephony.Sms.Inbox.CONTENT_URI,
            arrayOf("body", "date"),
            "date>=?",
            arrayOf(startMs.toString()),
            "date ASC"
        )
        cur?.use { c ->
            while (c.moveToNext()) {
                val body = c.getString(0) ?: continue
                val ts = c.getLong(1)
                if (importOne(ctx, body, ts)) n++
            }
        }
        n
    }
}
