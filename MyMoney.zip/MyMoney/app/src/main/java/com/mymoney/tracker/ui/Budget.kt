package com.mymoney.tracker.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mymoney.tracker.data.*
import java.time.YearMonth

const val TOTAL_KEY = "__TOTAL__"

private val ORANGE = Color(0xFFFB8C00)
private val palette = listOf(
    Color(0xFF1E88E5), Color(0xFFE53935), Color(0xFF43A047), Color(0xFFFB8C00),
    Color(0xFF8E24AA), Color(0xFF00ACC1), Color(0xFF6D4C41), Color(0xFF7CB342)
)

data class BudgetAlert(val category: String, val spent: Double, val limit: Double)

fun catOf(t: Txn): String = t.category.ifBlank { "Other" }

/** নির্বাচিত মাসের খাতভিত্তিক মোট ব্যয় (ক্রেডিট কার্ড খরচসহ) */
fun monthSpendByCategory(txns: List<Txn>, ym: YearMonth): Map<String, Double> =
    txns.filter { it.type == "EXPENSE" && YearMonth.from(it.date()) == ym }
        .groupBy { catOf(it) }
        .mapValues { e -> e.value.sumOf { it.amount } }

/** বাজেটের ৮০% বা তার বেশি খরচ হয়ে গেলে সতর্কতার তালিকা */
fun budgetAlerts(txns: List<Txn>, budgets: List<Budget>, ym: YearMonth): List<BudgetAlert> {
    val spent = monthSpendByCategory(txns, ym)
    val total = spent.values.sum()
    val out = ArrayList<BudgetAlert>()
    for (b in budgets) {
        if (b.limitAmount <= 0) continue
        val s = if (b.category == TOTAL_KEY) total else (spent[b.category] ?: 0.0)
        if (s >= b.limitAmount * 0.8) out.add(BudgetAlert(b.category, s, b.limitAmount))
    }
    return out.sortedByDescending { it.spent / it.limit }
}

/** একটি ব্যয় সেভ করার পর বাজেট ছাড়ালে সতর্কবার্তা (ছাড়ানো না হলে null) */
fun budgetWarning(t: Txn, txns: List<Txn>, budgets: List<Budget>, bn: Boolean): String? {
    if (t.type != "EXPENSE") return null
    val ym = YearMonth.from(t.date())
    val cat = catOf(t)
    val spent = monthSpendByCategory(txns.filter { it.id != t.id } + t, ym)
    val total = spent.values.sum()
    val msgs = ArrayList<String>()
    for (b in budgets) {
        if (b.limitAmount <= 0) continue
        val isTotal = b.category == TOTAL_KEY
        if (!isTotal && b.category != cat) continue
        val s = if (isTotal) total else (spent[cat] ?: 0.0)
        if (s > b.limitAmount) {
            val name = if (isTotal) (if (bn) "মোট মাসিক বাজেট" else "Total monthly budget") else b.category
            val over = s - b.limitAmount
            msgs.add(
                if (bn) "$name: ${money(s)} / ${money(b.limitAmount)} — ${money(over)} ছাড়িয়ে গেছে"
                else "$name: ${money(s)} / ${money(b.limitAmount)} — exceeded by ${money(over)}"
            )
        }
    }
    return if (msgs.isEmpty()) null else msgs.joinToString("\n")
}

@Composable
fun budgetName(key: String): String =
    if (key == TOTAL_KEY) tr("মোট মাসিক বাজেট", "Total monthly budget") else key

@Composable
private fun Pie(values: List<Pair<String, Double>>) {
    val sum = values.sumOf { it.second }
    Canvas(Modifier.size(150.dp)) {
        var start = -90f
        values.forEachIndexed { i, p ->
            val sweep = (360.0 * p.second / sum).toFloat()
            drawArc(color = palette[i % palette.size], startAngle = start, sweepAngle = sweep, useCenter = true)
            start += sweep
        }
    }
}

@Composable
private fun BudgetRow(name: String, spent: Double, limit: Double?, color: Color, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { onClick() }) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).background(color))
                    Spacer(Modifier.width(8.dp))
                    Text(name, fontWeight = FontWeight.Medium)
                }
                Text(money(spent) + (if (limit != null && limit > 0) " / " + money(limit) else ""), fontWeight = FontWeight.Bold)
            }
            if (limit != null && limit > 0) {
                val ratio = spent / limit
                val barColor = when {
                    ratio > 1.0 -> Red
                    ratio >= 0.8 -> ORANGE
                    else -> Green
                }
                Box(Modifier.fillMaxWidth().height(8.dp).background(Color(0x22888888))) {
                    Box(Modifier.fillMaxWidth(ratio.coerceIn(0.0, 1.0).toFloat()).fillMaxHeight().background(barColor))
                }
                Text(
                    if (ratio > 1.0) tr("ছাড়িয়েছে ", "Over by ") + money(spent - limit)
                    else tr("বাকি ", "Left ") + money(limit - spent),
                    color = barColor, style = MaterialTheme.typography.bodySmall
                )
            } else {
                Text(tr("বাজেট সেট নেই — ট্যাপ করে দিন", "No budget set — tap to add"), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun BudgetScreen(
    txns: List<Txn>, budgets: List<Budget>, ym: YearMonth,
    onSave: (String, Double) -> Unit, onDelete: (String) -> Unit
) {
    val spent = remember(txns, ym) { monthSpendByCategory(txns, ym) }
    val total = spent.values.sum()
    val bmap = budgets.associate { it.category to it.limitAmount }
    val cats = (spent.keys + bmap.keys.filter { it != TOTAL_KEY }).distinct()
        .sortedByDescending { spent[it] ?: 0.0 }
    var dialogCat by remember { mutableStateOf<String?>(null) } // "" = নতুন খাত

    val sorted = spent.entries.sortedByDescending { it.value }
    val slices = ArrayList<Pair<String, Double>>()
    sorted.take(6).forEach { slices.add(it.key to it.value) }
    val others = sorted.drop(6).sumOf { it.value }
    if (others > 0) slices.add(tr("অন্যান্য", "Others") to others)

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(fmt(ym.atDay(1), "MMMM yyyy"), style = MaterialTheme.typography.titleMedium)
        }
        item {
            val tb = bmap[TOTAL_KEY]
            BudgetRow(tr("মোট মাসিক বাজেট", "Total monthly budget"), total, tb, Color(0xFF455A64)) { dialogCat = TOTAL_KEY }
        }
        item {
            Text(tr("খাত অনুযায়ী মাসিক খরচ", "Category-wise spending"), style = MaterialTheme.typography.titleSmall)
        }
        if (total > 0) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Pie(slices)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        slices.forEachIndexed { i, p ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(10.dp).background(palette[i % palette.size]))
                                Spacer(Modifier.width(6.dp))
                                Text("${p.first} · ${(p.second * 100 / total).toInt()}%",
                                    style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        } else {
            item { Text(tr("এই মাসে কোনো ব্যয় নেই", "No spending this month")) }
        }
        items(cats, key = { it }) { c ->
            val idx = sorted.indexOfFirst { it.key == c }
            val color = if (idx in 0..5) palette[idx % palette.size] else Color.Gray
            BudgetRow(c, spent[c] ?: 0.0, bmap[c], color) { dialogCat = c }
        }
        item {
            Button({ dialogCat = "" }, Modifier.fillMaxWidth()) {
                Text(tr("+ খাতের বাজেট যোগ করুন", "+ Add category budget"))
            }
        }
        item {
            Text(tr("কোনো খাতে ট্যাপ করে মাসিক বাজেট ঠিক করুন। ৮০% খরচ হলে ড্যাশবোর্ডে সতর্কতা আসবে, সীমা ছাড়ালে এন্ট্রি সেভের সময়ও জানাবে।",
                "Tap a category to set its monthly budget. You get a dashboard alert at 80% and a warning when saving an entry over the limit."),
                style = MaterialTheme.typography.bodySmall)
        }
    }

    dialogCat?.let { cat ->
        BudgetDialog(cat, bmap[cat], { name, amt -> onSave(name, amt); dialogCat = null },
            { onDelete(cat); dialogCat = null }) { dialogCat = null }
    }
}

@Composable
private fun BudgetDialog(
    cat: String, current: Double?, onSave: (String, Double) -> Unit, onClear: () -> Unit, onDismiss: () -> Unit
) {
    val isNew = cat.isEmpty()
    var name by remember { mutableStateOf(cat) }
    var amount by remember {
        mutableStateOf(current?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: "")
    }
    var error by remember { mutableStateOf<String?>(null) }
    val errName = tr("খাতের নাম লিখুন", "Enter a category name")
    val errAmt = tr("সঠিক বাজেট দিন", "Enter a valid budget amount")
    val title = if (isNew) tr("খাতের বাজেট", "Category budget") else budgetName(cat)

    fun save() {
        val a = amount.toDoubleOrNull()
        if (name.isBlank()) { error = errName; return }
        if (a == null || a <= 0) { error = errAmt; return }
        onSave(name.trim(), a)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (isNew) {
                    OutlinedTextField(name, { name = it }, singleLine = true,
                        label = { Text(tr("খাতের নাম (খরচের খাতের সাথে হুবহু মিলতে হবে)", "Category name (must match the expense category)")) })
                }
                OutlinedTextField(amount, { amount = it }, singleLine = true,
                    label = { Text(tr("মাসিক বাজেট (₹)", "Monthly budget (₹)")) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                error?.let { Text(it, color = Red) }
            }
        },
        confirmButton = { TextButton({ save() }) { Text(tr("সেভ", "Save")) } },
        dismissButton = {
            Row {
                if (current != null) TextButton(onClear) { Text(tr("বাজেট মুছুন", "Remove"), color = Red) }
                TextButton(onDismiss) { Text(tr("বাতিল", "Cancel")) }
            }
        }
    )
}
