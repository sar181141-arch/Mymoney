package com.mymoney.tracker.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mymoney.tracker.data.*
import java.time.LocalDate
import java.time.YearMonth

/** পরিকল্পিত ব্যয়: খাত বেছে বা নিজে লিখে, তার বিপরীতে টাকা যোগ; মাসভিত্তিক পরিকল্পনা বনাম আসল খরচ */
@Composable
fun PlannedScreen(
    planned: List<Planned>, txns: List<Txn>, onSave: (Planned) -> Unit, onDelete: (Planned) -> Unit
) {
    var ym by remember { mutableStateOf(YearMonth.now()) }
    var editing by remember { mutableStateOf<Planned?>(null) }
    var adding by remember { mutableStateOf(false) }
    val items = planned.filter { YearMonth.from(millisToDate(it.dueMillis)) == ym }
    val total = items.sumOf { it.amount }
    val doneSum = items.filter { it.done }.sumOf { it.amount }
    val actual = remember(txns, ym) { monthSpendByCategory(txns, ym) }
    val grouped = items.groupBy { it.category }.toSortedMap()
    val lbPlanned = tr("পরিকল্পিত ", "Planned ")
    val lbActual = tr("আসল খরচ ", "Actual ")

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton({ ym = ym.minusMonths(1) }) { Text("◀") }
                Text(fmt(ym.atDay(1), "MMMM yyyy"), style = MaterialTheme.typography.titleMedium)
                TextButton({ ym = ym.plusMonths(1) }) { Text("▶") }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard(tr("মোট পরিকল্পিত", "Total planned"), total, Modifier.weight(1f))
                StatCard(tr("সম্পন্ন", "Done"), doneSum, Modifier.weight(1f), Green)
                StatCard(tr("বাকি", "Pending"), total - doneSum, Modifier.weight(1f), Red)
            }
        }
        if (items.isEmpty()) item { Text(tr("এই মাসে কোনো পরিকল্পিত ব্যয় নেই", "No planned expenses this month")) }
        grouped.forEach { (cat, list) ->
            item(key = "h$cat") {
                Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Text(catLabel(cat), fontWeight = FontWeight.Bold)
                    Text(lbPlanned + money(list.sumOf { it.amount }) + " · " + lbActual + money(actual[cat] ?: 0.0),
                        style = MaterialTheme.typography.bodySmall)
                }
            }
            items(list, key = { it.id }) { p ->
                Card(Modifier.fillMaxWidth().clickable { editing = p }) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.note.ifBlank { catLabel(p.category) }, fontWeight = FontWeight.Medium)
                            Text(fmt(millisToDate(p.dueMillis), "dd MMM yyyy"), style = MaterialTheme.typography.bodySmall)
                        }
                        Text(money(p.amount) + if (p.done) " ✅" else "", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            Button({ adding = true }, Modifier.fillMaxWidth()) { Text(tr("+ পরিকল্পিত ব্যয় যোগ করুন", "+ Add planned expense")) }
        }
    }
    if (adding) PlannedDialog(null, ym, { onSave(it); adding = false }, null) { adding = false }
    editing?.let { e ->
        PlannedDialog(e, ym, { onSave(it); editing = null }, { onDelete(e); editing = null }) { editing = null }
    }
}

@Composable
private fun PlannedDialog(
    existing: Planned?, ym: YearMonth, onSave: (Planned) -> Unit, onDelete: (() -> Unit)?, onDismiss: () -> Unit
) {
    var category by remember { mutableStateOf(existing?.category ?: "") }
    var amount by remember {
        mutableStateOf(existing?.amount?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: "")
    }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    var due by remember {
        mutableStateOf<Long?>(
            existing?.dueMillis ?: (if (YearMonth.now() == ym) LocalDate.now() else ym.atDay(1)).toMillis()
        )
    }
    var done by remember { mutableStateOf(existing?.done ?: false) }
    var error by remember { mutableStateOf<String?>(null) }
    val errCat = tr("খাত বেছে নিন বা লিখুন", "Choose or type a category")
    val errAmt = tr("সঠিক টাকার পরিমাণ দিন", "Enter a valid amount")

    fun save() {
        val a = amount.toDoubleOrNull()
        if (category.isBlank()) { error = errCat; return }
        if (a == null || a <= 0) { error = errAmt; return }
        onSave(
            (existing ?: Planned(category = "", amount = 0.0, dueMillis = 0)).copy(
                category = category.trim(), amount = a, note = note.trim(),
                dueMillis = due ?: LocalDate.now().toMillis(), done = done
            )
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("পরিকল্পিত ব্যয়", "Planned expense") else tr("সম্পাদনা", "Edit")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("খাত", "Category"), style = MaterialTheme.typography.labelMedium)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Cats.expense.forEach { c -> FilterChip(category == c, { category = c }, { Text(catLabel(c)) }) }
                }
                OutlinedTextField(category, { category = it }, singleLine = true,
                    label = { Text(tr("খাত (নিজে যোগ করুন)", "Category (add your own)")) })
                OutlinedTextField(amount, { amount = it }, singleLine = true,
                    label = { Text(tr("টাকার পরিমাণ (₹)", "Amount (₹)")) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(note, { note = it }, label = { Text(tr("বিবরণ (ঐচ্ছিক)", "Details (optional)")) })
                DateField(tr("তারিখ", "Date"), due, { due = it })
                if (existing != null) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically) {
                        Text(tr("সম্পন্ন হয়েছে", "Marked done"))
                        Switch(done, { done = it })
                    }
                }
                error?.let { Text(it, color = Red) }
            }
        },
        confirmButton = { TextButton({ save() }) { Text(tr("সেভ", "Save")) } },
        dismissButton = {
            Row {
                if (onDelete != null) TextButton(onDelete) { Text(tr("মুছুন", "Delete"), color = Red) }
                TextButton(onDismiss) { Text(tr("বাতিল", "Cancel")) }
            }
        }
    )
}
