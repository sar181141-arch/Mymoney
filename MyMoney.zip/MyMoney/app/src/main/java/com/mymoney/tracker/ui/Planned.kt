package com.mymoney.tracker.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.mymoney.tracker.data.*
import java.time.LocalDate
import java.time.YearMonth

/** পরিকল্পিত ব্যয়: খাত বেছে বা নিজে লিখে টাকা যোগ; তারিখ ঐচ্ছিক, তারিখ দিলে সেই দিন রিমাইন্ডার আসে */
@Composable
fun PlannedScreen(
    planned: List<Planned>, txns: List<Txn>, onSave: (Planned) -> Unit, onDelete: (Planned) -> Unit
) {
    val ctx = LocalContext.current
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    var ym by remember { mutableStateOf(YearMonth.now()) }
    var editing by remember { mutableStateOf<Planned?>(null) }
    var adding by remember { mutableStateOf(false) }
    val items = planned.filter { YearMonth.from(millisToDate(it.dueMillis)) == ym }
    val total = items.sumOf { it.amount }
    val doneSum = items.filter { it.done }.sumOf { it.amount }
    val actual = remember(txns, ym) { monthSpendByCategory(txns, ym) }
    val grouped = items.groupBy { it.category }.toSortedMap()
    val lbPlanned = tr("পরিকল্পিত ", "Planned ")
    val lbActual = tr("আসল খরচ ", "Actual ")

    fun saved(p: Planned) {
        onSave(p)
        if (p.hasDate && !p.done && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton({ ym = ym.minusMonths(1) }) { Text("◀") }
                Text(fmt(ym.atDay(1), "MMMM yyyy"), style = MaterialTheme.typography.titleMedium)
                TextButton({ ym = ym.plusMonths(1) }) { Text("▶") }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard(tr("মোট পরিকল্পিত", "Total planned"), total, Modifier.weight(1f))
                StatCard(tr("সম্পন্ন", "Done"), doneSum, Modifier.weight(1f), Green)
                StatCard(tr("বাকি", "Pending"), total - doneSum, Modifier.weight(1f), Red)
            }
        }
        if (items.isEmpty()) item { Text(tr("এই মাসে কোনো পরিকল্পিত ব্যয় নেই", "No planned expenses this month")) }
        grouped.forEach { (cat, list) ->
            item(key = "h$cat") {
                Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Text(catLabel(cat), fontWeight = FontWeight.Bold)
                    Text(lbPlanned + money(list.sumOf { it.amount }) + " · " + lbActual + money(actual[cat] ?: 0.0),
                        style = MaterialTheme.typography.bodySmall)
                }
            }
            items(list, key = { it.id }) { p ->
                Card(Modifier.fillMaxWidth().clickable { editing = p }) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.note.ifBlank { catLabel(p.category) }, fontWeight = FontWeight.Medium)
                            if (p.hasDate) {
                                Text("🔔 " + fmt(millisToDate(p.dueMillis), "dd MMM yyyy"), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Text(money(p.amount) + if (p.done) " ✅" else "", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            Button({ adding = true }, Modifier.fillMaxWidth()) { Text(tr("+ পরিকল্পিত ব্যয় যোগ করুন", "+ Add planned expense")) }
        }
    }
    if (adding) PlannedDialog(null, ym, { saved(it); adding = false }, null) { adding = false }
    editing?.let { e ->
        PlannedDialog(e, ym, { saved(it); editing = null }, { onDelete(e); editing = null }) { editing = null }
    }
}

@Composable
private fun PlannedDialog(
    existing: Planned?, ym: YearMonth, onSave: (Planned) -> Unit, onDelete: (() -> Unit)?, onDismiss: () -> Unit
) {
    var category by remember { mutableStateOf(existing?.category ?: "") }
    var amount by remember {
        mutableStateOf(existing?.amount?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: "")
    }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    // null = তারিখ নেই
    var due by remember {
        mutableStateOf<Long?>(if (existing != null && existing.hasDate) existing.dueMillis else null)
    }
    var done by remember { mutableStateOf(existing?.done ?: false) }
    var error by remember { mutableStateOf<String?>(null) }
    val errCat = tr("খাত বেছে নিন বা লিখুন", "Choose or type a category")
    val errAmt = tr("সঠিক টাকার পরিমাণ দিন", "Enter a valid amount")

    fun save() {
        val a = amount.toDoubleOrNull()
        if (category.isBlank()) { error = errCat; return }
        if (a == null || a <= 0) { error = errAmt; return }
        // তারিখ না থাকলে dueMillis শুধু মাস ঠিক করতে (দেখানো হয় না)
        val anchor = existing?.dueMillis
            ?: (if (YearMonth.now() == ym) LocalDate.now() else ym.atDay(1)).toMillis()
        onSave(
            (existing ?: Planned(category = "", amount = 0.0, dueMillis = 0)).copy(
                category = category.trim(), amount = a, note = note.trim(),
                dueMillis = due ?: anchor, hasDate = due != null, done = done
            )
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("পরিকল্পিত ব্যয়", "Planned expense") else tr("সম্পাদনা", "Edit")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("খাত", "Category"), style = MaterialTheme.typography.labelMedium)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Cats.expense.forEach { c -> FilterChip(category == c, { category = c }, { Text(catLabel(c)) }) }
                }
                OutlinedTextField(category, { category = it }, singleLine = true,
                    label = { Text(tr("খাত (নিজে যোগ করুন)", "Category (add your own)")) })
                OutlinedTextField(amount, { amount = it }, singleLine = true,
                    label = { Text(tr("টাকার পরিমাণ (₹)", "Amount (₹)")) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(note, { note = it }, label = { Text(tr("বিবরণ (ঐচ্ছিক)", "Details (optional)")) })
                DateField(tr("তারিখ (ঐচ্ছিক)", "Date (optional)"), due, { due = it }, clearable = true)
                Text(
                    if (due == null) tr("তারিখ দেওয়া নেই — কোনো রিমাইন্ডার আসবে না।", "No date — no reminder will be sent.")
                    else tr("এই তারিখে সকাল ৯টায় রিমাইন্ডার আসবে।", "A reminder will arrive on this date at 9 AM."),
                    style = MaterialTheme.typography.bodySmall
                )
                if (existing != null) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically) {
                        Text(tr("সম্পন্ন হয়েছে", "Marked done"))
                        Switch(done, { done = it })
                    }
                }
                error?.let { Text(it, color = Red) }
            }
        },
        confirmButton = { TextButton({ save() }) { Text(tr("সেভ", "Save")) } },
        dismissButton = {
            Row {
                if (onDelete != null) TextButton(onDelete) { Text(tr("মুছুন", "Delete"), color = Red) }
                TextButton(onDismiss) { Text(tr("বাতিল", "Cancel")) }
            }
        }
    )
}
