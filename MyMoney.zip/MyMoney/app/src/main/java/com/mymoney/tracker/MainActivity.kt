package com.mymoney.tracker

import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mymoney.tracker.data.SettingsState
import com.mymoney.tracker.data.Txn
import com.mymoney.tracker.ui.*

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: MoneyViewModel = viewModel()
            val st by vm.settings.collectAsState()
            AppTheme(st) {
                Surface(Modifier.fillMaxSize()) { Root(vm, st) }
            }
        }
    }
}

@Composable
fun Root(vm: MoneyViewModel, st: SettingsState) {
    var unlocked by rememberSaveable { mutableStateOf(false) }
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { unlocked = false }
    when {
        st.pinHash.isEmpty() -> SetPinScreen { vm.setPin(it); unlocked = true }
        st.lockEnabled && !unlocked -> LockScreen(st, vm::verifyPin) { unlocked = true }
        else -> App(vm, st)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: MoneyViewModel, st: SettingsState) {
    val accs by vm.accounts.collectAsState()
    val cards by vm.cards.collectAsState()
    val txns by vm.txns.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var screen by rememberSaveable { mutableStateOf("main") }
    var showDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Txn?>(null) }

    LaunchedEffect(Unit) { vm.autoImportIfAllowed() }
    BackHandler(enabled = screen != "main") { screen = "main" }

    val title = when (screen) {
        "settings" -> tr("সেটিংস", "Settings")
        "cards" -> tr("ক্রেডিট কার্ড রিপোর্ট", "Credit card report")
        else -> tr("আমার হিসাব", "My Hisab")
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    if (screen != "main") TextButton({ screen = "main" }) { Text("←") }
                },
                actions = {
                    if (screen == "main") {
                        IconButton({ screen = "settings" }) {
                            Icon(Icons.Default.Settings, tr("সেটিংস", "Settings"))
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (screen == "main") {
                NavigationBar {
                    NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.Home, null) }, label = { Text(tr("ড্যাশবোর্ড", "Dashboard")) })
                    NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Default.List, null) }, label = { Text(tr("দৈনিক", "Daily")) })
                    NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Default.Person, null) }, label = { Text(tr("অ্যাকাউন্ট", "Accounts")) })
                }
            }
        },
        floatingActionButton = {
            if (screen == "main") {
                FloatingActionButton(onClick = { editing = null; showDialog = true }) {
                    Icon(Icons.Default.Add, tr("নতুন এন্ট্রি", "New entry"))
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (screen) {
                "settings" -> SettingsScreen(st, accs, cards, txns, vm)
                "cards" -> CardReportScreen(cards, txns)
                else -> when (tab) {
                    0 -> DashboardScreen(accs, cards, txns) { screen = "cards" }
                    1 -> DailyScreen(accs, cards, txns) { editing = it; showDialog = true }
                    else -> AccountsScreen(accs, cards, txns, { vm.saveAccount(it) }, { vm.saveCard(it) })
                }
            }
        }
    }

    if (showDialog) {
        val e = editing
        TxnDialog(
            accs = accs,
            cards = cards,
            existing = e,
            onSave = { vm.saveTxn(it); showDialog = false },
            onDelete = if (e != null) ({ vm.deleteTxn(e); showDialog = false }) else null,
            onDismiss = { showDialog = false }
        )
    }
}
