package com.mymoney.tracker

import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mymoney.tracker.cloud.Cloud
import com.mymoney.tracker.data.SettingsState
import com.mymoney.tracker.data.Txn
import com.mymoney.tracker.notify.PtpWorker
import com.mymoney.tracker.ui.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.YearMonth

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PtpWorker.schedule(applicationContext)
        setContent {
            val vm: MoneyViewModel = viewModel()
            val st by vm.settings.collectAsState()
            AppTheme(st) {
                Surface(Modifier.fillMaxSize()) {
                    if (BuildConfig.IS_MASTER) MasterRoot(vm, st) else Root(vm, st)
                }
            }
        }
    }
}

@Composable
fun Root(vm: MoneyViewModel, st: SettingsState) {
    val ctx = LocalContext.current
    val configured = remember { Cloud.configured(ctx) }
    val account by vm.account.collectAsState()
    var unlocked by rememberSaveable { mutableStateOf(false) }
    var stoppedAt by rememberSaveable { mutableStateOf(0L) }
    // অ্যাপ থেকে বের হওয়ার সময় মনে রাখি; ফিরে এসে নির্বাচিত সময় পার হলে আবার লক
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { stoppedAt = System.currentTimeMillis() }
    LifecycleEventEffect(Lifecycle.Event.ON_START) {
        if (unlocked && st.lockEnabled &&
            System.currentTimeMillis() - stoppedAt >= st.lockTimeout * 1000L
        ) unlocked = false
    }
    when {
        configured && account == null -> AuthScreen(vm)
        // MPIN তৈরি করা বা এড়িয়ে যাওয়া (নতুন বা পুরনো, যেকোনো লগইনের পর)
        st.pinHash.isEmpty() && !st.pinSkipped -> SetPinScreen(
            onSet = { vm.setPin(it); unlocked = true },
            onSkip = { vm.update { s -> s.copy(lockEnabled = false, pinSkipped = true) }; unlocked = true }
        )
        st.lockEnabled && !unlocked -> LockScreen(st, vm::verifyPin) { unlocked = true }
        else -> App(vm, st)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: MoneyViewModel, st: SettingsState) {
    val accs by vm.accounts.collectAsState()
    val cards by vm.cards.collectAsState()
    val txns by vm.txns.collectAsState()
    val budgets by vm.budgets.collectAsState()
    val debtors by vm.debtors.collectAsState()
    val pays by vm.debtorPayments.collectAsState()
    val planned by vm.planned.collectAsState()
    val account by vm.account.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    // পর্দার স্ট্যাক ("main|settings|banks" ধরনের); শেষটি এখনকার পর্দা
    var nav by rememberSaveable { mutableStateOf("main") }
    var selMonth by rememberSaveable { mutableStateOf(YearMonth.now().toString()) }
    var selAcc by rememberSaveable { mutableStateOf(0L) }
    var selDebtor by rememberSaveable { mutableStateOf(0L) }
    var editing by remember { mutableStateOf<Txn?>(null) }
    var editingLimited by remember { mutableStateOf(false) }
    var warn by remember { mutableStateOf<String?>(null) }
    var menu by remember { mutableStateOf(false) }
    var syncing by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    val showTick: () -> Unit = { tick++ }
    val scope = rememberCoroutineScope()
    val appCtx = LocalContext.current
    val lbNoLogin = tr("ক্লাউডে লগইন নেই", "Not logged in to the cloud")
    val screen = nav.substringAfterLast('|')
    val ym = YearMonth.parse(selMonth)
    val bn = st.lang == "bn"

    fun go(s: String) { nav = "$nav|$s" }
    fun back() { if (nav.contains('|')) nav = nav.substringBeforeLast('|') }

    LaunchedEffect(Unit) { vm.autoImportIfAllowed() }
    // অ্যাডমিন ক্লাউডে ডেটা বদলালে ইউজারের অ্যাপ খুললে সেটি নামিয়ে নেয়; আর অ্যাডমিন যাতে খুঁজে পায় সেজন্য ডিরেক্টরিতে নাম রাখে
    LaunchedEffect(account) { vm.pullAdminEdits() }
    LaunchedEffect(account, st.mobile, st.userName) { vm.ensureDirectory() }
    LifecycleEventEffect(Lifecycle.Event.ON_START) { vm.pullAdminEdits() }
    // অটো ব্যাকআপ: যেকোনো পরিবর্তনের (ছবিসহ) আধা সেকেন্ডের মধ্যে ক্লাউডে সিঙ্ক; শুধু বদলানো অংশই আপলোড হয়
    LaunchedEffect(accs, cards, txns, budgets, debtors, pays, planned, account, st.autoBackup, st.photoVersion) {
        if (account != null && st.autoBackup) {
            delay(500)
            vm.backupSilently()
        }
    }
    BackHandler(enabled = nav.contains('|')) { back() }

    val title = when (screen) {
        "settings" -> tr("সেটিংস", "Settings")
        "cards" -> tr("ক্রেডিট কার্ড রিপোর্ট", "Credit card report")
        "budget" -> tr("বাজেট ও খাতভিত্তিক চার্ট", "Budget & Category chart")
        "statement" -> tr("কনসোলিডেটেড স্টেটমেন্ট", "Consolidated Statement")
        "profile" -> tr("প্রোফাইল", "Profile")
        "debtors" -> tr("ঋণগ্রহীতার তালিকা", "Debtor list")
        "debtorDetail" -> debtors.firstOrNull { it.id == selDebtor }?.name ?: tr("ঋণগ্রহীতা", "Debtor")
        "planned" -> tr("পরিকল্পিত ব্যয়", "Planned Expenses")
        "banks" -> tr("ব্যাংক অ্যাকাউন্ট", "Bank Accounts")
        "bankDetail" -> accs.firstOrNull { it.id == selAcc }?.name ?: tr("ব্যাংক অ্যাকাউন্ট", "Bank Account")
        "modifyMenu" -> tr("মডিফাই", "Modify")
        "modExpense" -> tr("মডিফাই এক্সপেন্স", "Modify Expense")
        "modIncome" -> tr("মডিফাই ইনকাম", "Modify Income")
        "modOther" -> tr("মডিফাই সেলফ ট্রান্সফার ও ক্রেডিট কার্ড", "Modify Self Transfer & Credit Card")
        "modBanks" -> tr("মডিফাই ব্যাংক অ্যাকাউন্ট", "Modify Bank Account")
        "modCards" -> tr("মডিফাই ক্রেডিট কার্ড", "Modify Credit Card")
        "monthExpense" -> tr("ব্যয়", "Expenses") + " · " + fmt(ym.atDay(1), "MMM yyyy")
        "monthIncome" -> tr("আয়", "Income") + " · " + fmt(ym.atDay(1), "MMM yyyy")
        "selfTransfer" -> tr("সেলফ ট্রান্সফার", "Self Transfer")
        "paidBills" -> tr("পরিশোধিত বিল", "Paid bills")
        else -> if (tab == 3 && st.userName.isNotBlank()) st.userName else "My Hisab"
    }

    CompositionLocalProvider(LocalTick provides showTick) {
        Box(Modifier.fillMaxSize()) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (screen == "main" && tab == 3) {
                                    AppLogo(30.dp)
                                    Spacer(Modifier.width(8.dp))
                                }
                                Text(title)
                                if (screen == "main") {
                                    if (syncing) {
                                        CircularProgressIndicator(Modifier.padding(start = 12.dp).size(22.dp), strokeWidth = 2.dp)
                                    } else {
                                        IconButton({
                                            scope.launch {
                                                syncing = true
                                                val err = vm.syncNow()
                                                syncing = false
                                                when (err) {
                                                    null -> showTick()
                                                    "NOT_LOGGED_IN" -> Toast.makeText(appCtx, lbNoLogin, Toast.LENGTH_LONG).show()
                                                    else -> Toast.makeText(appCtx, err, Toast.LENGTH_LONG).show()
                                                }
                                            }
                                        }) { Icon(Icons.Default.Refresh, tr("সিঙ্ক", "Sync")) }
                                    }
                                }
                            }
                        },
                        navigationIcon = {
                            if (screen != "main") {
                                TextButton({ back() }) {
                                    Text("←", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                                }
                            } else {
                                Box {
                                    IconButton({ menu = true }) { Icon(Icons.Default.Menu, tr("মেনু", "Menu")) }
                                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                        DropdownMenuItem(text = { Text("👤 " + tr("প্রোফাইল", "Profile")) },
                                            onClick = { menu = false; go("profile") })
                                        DropdownMenuItem(text = { Text("🤝 " + tr("ঋণগ্রহীতার তালিকা", "Debtor list")) },
                                            onClick = { menu = false; go("debtors") })
                                        DropdownMenuItem(text = { Text("🗓 " + tr("পরিকল্পিত ব্যয়", "Planned Expenses")) },
                                            onClick = { menu = false; go("planned") })
                                        DropdownMenuItem(text = { Text("📊 " + tr("বাজেট ও খাতভিত্তিক চার্ট", "Budget & Category chart")) },
                                            onClick = { menu = false; go("budget") })
                                        HorizontalDivider()
                                        DropdownMenuItem(text = { Text("🏦 " + tr("ব্যাংক অ্যাকাউন্ট", "Bank Accounts")) },
                                            onClick = { menu = false; go("banks") })
                                        DropdownMenuItem(text = { Text("💳 " + tr("ক্রেডিট কার্ড", "Credit Cards")) },
                                            onClick = { menu = false; go("cards") })
                                        DropdownMenuItem(text = { Text("🧾 " + tr("কনসোলিডেটেড স্টেটমেন্ট", "Consolidated Statement")) },
                                            onClick = { menu = false; go("statement") })
                                        DropdownMenuItem(text = { Text("✏️ " + tr("মডিফাই", "Modify")) },
                                            onClick = { menu = false; go("modifyMenu") })
                                    }
                                }
                            }
                        },
                        actions = {
                            if (screen == "main") {
                                IconButton({ go("settings") }) {
                                    Icon(Icons.Default.Settings, tr("সেটিংস", "Settings"))
                                }
                            }
                        }
                    )
                },
                bottomBar = {
                    if (screen == "main") {
                        NavigationBar {
                            NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.Home, null) }, label = { Text(tr("ড্যাশবোর্ড", "Dashboard")) })
                            NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Default.List, null) }, label = { Text(tr("দৈনিক", "Daily")) })
                            NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Default.ShoppingCart, null) }, label = { Text("New Entry") })
                            NavigationBarItem(tab == 3, { tab = 3 }, { Icon(Icons.Default.Person, null) }, label = { Text(tr("অ্যাকাউন্ট", "Accounts")) })
                        }
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad)) {
                    when (screen) {
                        "settings" -> SettingsScreen(st, accs, cards, txns, vm) { go(it) }
                        "cards" -> CardReportScreen(cards, txns)
                        "budget" -> BudgetScreen(
                            txns, budgets, ym,
                            { c, a -> vm.saveBudget(c, a); showTick() },
                            { c -> vm.deleteBudget(c) }
                        )
                        "statement" -> StatementScreen(accs, cards, txns, ym, st.userName)
                        "profile" -> ProfileScreen(st, account, vm)
                        "debtors" -> DebtorsScreen(
                            debtors, pays,
                            { vm.saveDebtor(it); showTick() },
                            { selDebtor = it; go("debtorDetail") }
                        )
                        "debtorDetail" -> {
                            val d = debtors.firstOrNull { it.id == selDebtor }
                            if (d != null) {
                                DebtorDetailScreen(
                                    d, pays, st.userName, bn,
                                    { vm.saveDebtor(it); showTick() },
                                    { amt, full, ptp -> vm.payDebtor(d, amt, full, ptp); showTick() },
                                    { vm.deleteDebtor(d); back() }
                                )
                            }
                        }
                        "planned" -> PlannedScreen(
                            planned, txns,
                            { vm.savePlanned(it); showTick() },
                            { vm.deletePlanned(it) }
                        )
                        "banks" -> BanksScreen(accs, txns) { selAcc = it; go("bankDetail") }
                        "bankDetail" -> {
                            val a = accs.firstOrNull { it.id == selAcc }
                            if (a != null) AccountStatementScreen(a, accs, cards, txns, ym, st.userName)
                        }
                        "modifyMenu" -> ModifyMenuScreen { go(it) }
                        // মেনু → Modify: এখান থেকেই সব এন্ট্রি ও অ্যাকাউন্ট বদলানো যায় (টাকা, তারিখ, সময়সহ)
                        "modExpense" -> ModifyEntriesScreen(
                            accs, cards, txns, setOf("EXPENSE"), tr("এই মাসে কোনো ব্যয় নেই", "No expenses this month")
                        ) { editingLimited = false; editing = it }
                        "modIncome" -> ModifyEntriesScreen(
                            accs, cards, txns, setOf("INCOME"), tr("এই মাসে কোনো আয় নেই", "No income this month")
                        ) { editingLimited = false; editing = it }
                        "modOther" -> ModifyEntriesScreen(
                            accs, cards, txns, setOf("TRANSFER", "CARD_BILL"),
                            tr("এই মাসে কোনো সেলফ ট্রান্সফার বা ক্রেডিট কার্ড এন্ট্রি নেই", "No self transfers or credit card entries this month")
                        ) { editingLimited = false; editing = it }
                        "modBanks" -> ModifyAccountsScreen(accs, txns) { vm.saveAccount(it); showTick() }
                        "modCards" -> ModifyCardsScreen(cards, txns) { vm.saveCard(it); showTick() }
                        // ড্যাশবোর্ডের তালিকাগুলো শুধু দেখার জন্য (ট্যাপ করলে বিবরণ)
                        "monthExpense" -> MonthListScreen(
                            accs, cards, txns, ym, setOf("EXPENSE"),
                            tr("এই মাসে কোনো ব্যয় নেই", "No expenses this month"), editable = false
                        ) { }
                        "monthIncome" -> MonthListScreen(
                            accs, cards, txns, ym, setOf("INCOME"),
                            tr("এই মাসে কোনো আয় নেই", "No income this month"), editable = false
                        ) { }
                        "selfTransfer" -> SelfTransferDayScreen(accs, txns)
                        "paidBills" -> PaidBillsDayScreen(accs, cards, txns)
                        else -> when (tab) {
                            0 -> DashboardScreen(
                                accs = accs, cards = cards, txns = txns, budgets = budgets, ym = ym,
                                onMonth = { selMonth = it.toString() },
                                onCards = { go("cards") },
                                onExpense = { go("monthExpense") },
                                onIncome = { go("monthIncome") },
                                onSelfTransfer = { go("selfTransfer") },
                                onPaidBills = { go("paidBills") },
                                onBudget = { go("budget") }
                            )
                            1 -> DailyScreen(accs, cards, txns) { editingLimited = true; editing = it }
                            2 -> EntryScreen(accs, cards) { t ->
                                vm.saveTxn(t)
                                warn = budgetWarning(t, txns, budgets, bn)
                                showTick()
                            }
                            else -> AccountsScreen(accs, cards, txns)
                        }
                    }
                }
            }
            SuccessTick(tick)
        }

        editing?.let { e ->
            TxnDialog(
                accs = accs,
                cards = cards,
                existing = e,
                limited = editingLimited,
                onSave = { t ->
                    vm.saveTxn(t)
                    warn = budgetWarning(t, txns, budgets, bn)
                    editing = null
                    showTick()
                },
                onDelete = if (editingLimited) null else ({ vm.deleteTxn(e); editing = null }),
                onDismiss = { editing = null }
            )
        }

        warn?.let { w ->
            AlertDialog(
                onDismissRequest = { warn = null },
                title = { Text("⚠ " + tr("বাজেট সতর্কতা", "Budget warning")) },
                text = { Text(w) },
                confirmButton = { TextButton({ warn = null }) { Text("OK") } }
            )
        }
    }
}
