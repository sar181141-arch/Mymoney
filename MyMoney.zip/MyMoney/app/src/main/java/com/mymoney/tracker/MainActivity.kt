package com.mymoney.tracker

import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mymoney.tracker.cloud.Cloud
import com.mymoney.tracker.data.SettingsState
import com.mymoney.tracker.data.Txn
import com.mymoney.tracker.ui.*
import kotlinx.coroutines.delay
import java.time.YearMonth

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: MoneyViewModel = viewModel()
            val st by vm.settings.collectAsState()
            AppTheme(st) {
                Surface(Modifier.fillMaxSize()) { Root(vm, st) }
            }
        }
    }
}

@Composable
fun Root(vm: MoneyViewModel, st: SettingsState) {
    val ctx = LocalContext.current
    val configured = remember { Cloud.configured(ctx) }
    val account by vm.account.collectAsState()
    var unlocked by rememberSaveable { mutableStateOf(false) }
    var stoppedAt by rememberSaveable { mutableStateOf(0L) }
    // অ্যাপ থেকে বের হওয়ার সময় মনে রাখি; ফিরে এসে নির্বাচিত সময় পার হলে আবার লক
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { stoppedAt = System.currentTimeMillis() }
    LifecycleEventEffect(Lifecycle.Event.ON_START) {
        if (unlocked && st.lockEnabled &&
            System.currentTimeMillis() - stoppedAt >= st.lockTimeout * 1000L
        ) unlocked = false
    }
    when {
        configured && account == null -> AuthScreen(vm)
        st.pinHash.isEmpty() -> SetPinScreen { vm.setPin(it); unlocked = true }
        st.lockEnabled && !unlocked -> LockScreen(st, vm::verifyPin) { unlocked = true }
        else -> App(vm, st)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: MoneyViewModel, st: SettingsState) {
    val accs by vm.accounts.collectAsState()
    val cards by vm.cards.collectAsState()
    val txns by vm.txns.collectAsState()
    val account by vm.account.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var screen by rememberSaveable { mutableStateOf("main") }
    var selMonth by rememberSaveable { mutableStateOf(YearMonth.now().toString()) }
    var editing by remember { mutableStateOf<Txn?>(null) }
    val ym = YearMonth.parse(selMonth)

    LaunchedEffect(Unit) { vm.autoImportIfAllowed() }
    // পরিবর্তনের ২০ সেকেন্ড পর অটো ব্যাকআপ (লগইন থাকলে)
    LaunchedEffect(accs, cards, txns, account, st.autoBackup) {
        if (account != null && st.autoBackup) {
            delay(20000)
            vm.backupSilently()
        }
    }
    BackHandler(enabled = screen != "main") { screen = "main" }

    val title = when (screen) {
        "settings" -> tr("সেটিংস", "Settings")
        "cards" -> tr("ক্রেডিট কার্ড রিপোর্ট", "Credit card report")
        "monthExpense" -> tr("ব্যয়", "Expenses") + " · " + fmt(ym.atDay(1), "MMM yyyy")
        "monthIncome" -> tr("আয়", "Income") + " · " + fmt(ym.atDay(1), "MMM yyyy")
        "monthOther" -> tr("ট্রান্সফার ও কার্ড বিল", "Transfers & card bills") + " · " + fmt(ym.atDay(1), "MMM yy")
        else -> "My Hisab"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    if (screen != "main") TextButton({ screen = "main" }) { Text("←") }
                },
                actions = {
                    if (screen == "main") {
                        IconButton({ screen = "settings" }) {
                            Icon(Icons.Default.Settings, tr("সেটিংস", "Settings"))
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (screen == "main") {
                NavigationBar {
                    NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.Home, null) }, label = { Text(tr("ড্যাশবোর্ড", "Dashboard")) })
                    NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Default.List, null) }, label = { Text(tr("দৈনিক", "Daily")) })
                    NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Default.ShoppingCart, null) }, label = { Text(tr("ব্যয়", "Expense")) })
                    NavigationBarItem(tab == 3, { tab = 3 }, { Icon(Icons.Default.Person, null) }, label = { Text(tr("অ্যাকাউন্ট", "Accounts")) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (screen) {
                "settings" -> SettingsScreen(st, accs, cards, txns, vm)
                "cards" -> CardReportScreen(cards, txns)
                "monthExpense" -> MonthListScreen(
                    accs, cards, txns, ym, setOf("EXPENSE"),
                    tr("এই মাসে কোনো ব্যয় নেই", "No expenses this month")
                ) { editing = it }
                "monthIncome" -> MonthListScreen(
                    accs, cards, txns, ym, setOf("INCOME"),
                    tr("এই মাসে কোনো আয় নেই", "No income this month")
                ) { editing = it }
                "monthOther" -> MonthListScreen(
                    accs, cards, txns, ym, setOf("TRANSFER", "CARD_BILL"),
                    tr("এই মাসে কোনো ট্রান্সফার বা কার্ড বিল নেই", "No transfers or card bills this month")
                ) { editing = it }
                else -> when (tab) {
                    0 -> DashboardScreen(
                        accs, cards, txns, ym,
                        { selMonth = it.toString() },
                        { screen = "cards" },
                        { screen = "monthExpense" },
                        { screen = "monthIncome" },
                        { screen = "monthOther" }
                    )
                    1 -> DailyScreen(accs, cards, txns)
                    2 -> EntryScreen(accs, cards) { vm.saveTxn(it) }
                    else -> AccountsScreen(accs, cards, txns, { vm.saveAccount(it) }, { vm.saveCard(it) })
                }
            }
        }
    }

    editing?.let { e ->
        TxnDialog(
            accs = accs,
            cards = cards,
            existing = e,
            onSave = { vm.saveTxn(it); editing = null },
            onDelete = { vm.deleteTxn(e); editing = null },
            onDismiss = { editing = null }
        )
    }
}
