package com.mymoney.tracker

import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mymoney.tracker.cloud.Cloud
import com.mymoney.tracker.data.SettingsState
import com.mymoney.tracker.data.Txn
import com.mymoney.tracker.notify.PtpWorker
import com.mymoney.tracker.ui.*
import kotlinx.coroutines.delay
import java.time.YearMonth

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PtpWorker.schedule(applicationContext)
        setContent {
            val vm: MoneyViewModel = viewModel()
            val st by vm.settings.collectAsState()
            AppTheme(st) {
                Surface(Modifier.fillMaxSize()) { Root(vm, st) }
            }
        }
    }
}

@Composable
fun Root(vm: MoneyViewModel, st: SettingsState) {
    val ctx = LocalContext.current
    val configured = remember { Cloud.configured(ctx) }
    val account by vm.account.collectAsState()
    var unlocked by rememberSaveable { mutableStateOf(false) }
    var stoppedAt by rememberSaveable { mutableStateOf(0L) }
    // অ্যাপ থেকে বের হওয়ার সময় মনে রাখি; ফিরে এসে নির্বাচিত সময় পার হলে আবার লক
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { stoppedAt = System.currentTimeMillis() }
    LifecycleEventEffect(Lifecycle.Event.ON_START) {
        if (unlocked && st.lockEnabled &&
            System.currentTimeMillis() - stoppedAt >= st.lockTimeout * 1000L
        ) unlocked = false
    }
    when {
        configured && account == null -> AuthScreen(vm)
        st.pinHash.isEmpty() -> SetPinScreen { vm.setPin(it); unlocked = true }
        st.lockEnabled && !unlocked -> LockScreen(st, vm::verifyPin) { unlocked = true }
        else -> App(vm, st)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: MoneyViewModel, st: SettingsState) {
    val accs by vm.accounts.collectAsState()
    val cards by vm.cards.collectAsState()
    val txns by vm.txns.collectAsState()
    val budgets by vm.budgets.collectAsState()
    val debtors by vm.debtors.collectAsState()
    val pays by vm.debtorPayments.collectAsState()
    val planned by vm.planned.collectAsState()
    val account by vm.account.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    // পর্দার স্ট্যাক ("main|settings|banks" ধরনের); শেষটি এখনকার পর্দা
    var nav by rememberSaveable { mutableStateOf("main") }
    var selMonth by rememberSaveable { mutableStateOf(YearMonth.now().toString()) }
    var selAcc by rememberSaveable { mutableStateOf(0L) }
    var selDebtor by rememberSaveable { mutableStateOf(0L) }
    var editing by remember { mutableStateOf<Txn?>(null) }
    var warn by remember { mutableStateOf<String?>(null) }
    var menu by remember { mutableStateOf(false) }
    val screen = nav.substringAfterLast('|')
    val ym = YearMonth.parse(selMonth)
    val bn = st.lang == "bn"

    fun go(s: String) { nav = "$nav|$s" }
    fun back() { if (nav.contains('|')) nav = nav.substringBeforeLast('|') }

    LaunchedEffect(Unit) { vm.autoImportIfAllowed() }
    // যেকোনো পরিবর্তনের আধা সেকেন্ডের মধ্যে ক্লাউডে সিঙ্ক (লগইন থাকলে); শুধু বদলানো অংশই আপলোড হয়
    LaunchedEffect(accs, cards, txns, budgets, debtors, pays, planned, account, st.autoBackup) {
        if (account != null && st.autoBackup) {
            delay(500)
            vm.backupSilently()
        }
    }
    BackHandler(enabled = nav.contains('|')) { back() }

    val title = when (screen) {
        "settings" -> tr("সেটিংস", "Settings")
        "cards" -> tr("ক্রেডিট কার্ড রিপোর্ট", "Credit card report")
        "budget" -> tr("বাজেট ও খাতভিত্তিক চার্ট", "Budget & Category chart")
        "statement" -> tr("কনসোলিডেটেড স্টেটমেন্ট", "Consolidated Statement")
        "profile" -> tr("প্রোফাইল", "Profile")
        "debtors" -> tr("ঋণগ্রহীতার তালিকা", "Debtor list")
        "debtorDetail" -> debtors.firstOrNull { it.id == selDebtor }?.name ?: tr("ঋণগ্রহীতা", "Debtor")
        "planned" -> tr("পরিকল্পিত ব্যয়", "Planned Expenses")
        "banks" -> tr("ব্যাংক অ্যাকাউন্ট", "Bank Accounts")
        "bankDetail" -> accs.firstOrNull { it.id == selAcc }?.name ?: tr("ব্যাংক অ্যাকাউন্ট", "Bank Account")
        "modExpense" -> tr("মডিফাই এক্সপেন্স", "Modify Expense")
        "modIncome" -> tr("মডিফাই ইনকাম", "Modify Income")
        "modOther" -> tr("মডিফাই ট্রান্সফার ও কার্ড বিল", "Modify Transfers & Card bills")
        "modBanks" -> tr("মডিফাই ব্যাংক অ্যাকাউন্ট", "Modify Bank Account")
        "modCards" -> tr("মডিফাই ক্রেডিট কার্ড", "Modify Credit Card")
        "monthExpense" -> tr("ব্যয়", "Expenses") + " · " + fmt(ym.atDay(1), "MMM yyyy")
        "monthIncome" -> tr("আয়", "Income") + " · " + fmt(ym.atDay(1), "MMM yyyy")
        "monthOther" -> tr("ট্রান্সফার ও কার্ড বিল", "Transfers & card bills") + " · " + fmt(ym.atDay(1), "MMM yy")
        else -> if (tab == 3 && st.userName.isNotBlank()) st.userName else "My Hisab"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    if (screen != "main") {
                        TextButton({ back() }) { Text("←") }
                    } else if (tab == 0) {
                        Box {
                            IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, tr("মেনু", "Menu")) }
                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                DropdownMenuItem(text = { Text("👤 " + tr("প্রোফাইল", "Profile")) },
                                    onClick = { menu = false; go("profile") })
                                DropdownMenuItem(text = { Text("🤝 " + tr("ঋণগ্রহীতার তালিকা", "Debtor list")) },
                                    onClick = { menu = false; go("debtors") })
                                DropdownMenuItem(text = { Text("🗓 " + tr("পরিকল্পিত ব্যয়", "Planned Expenses")) },
                                    onClick = { menu = false; go("planned") })
                                DropdownMenuItem(text = { Text("📊 " + tr("বাজেট ও খাতভিত্তিক চার্ট", "Budget & Category chart")) },
                                    onClick = { menu = false; go("budget") })
                            }
                        }
                    }
                },
                actions = {
                    if (screen == "main") {
                        IconButton({ go("settings") }) {
                            Icon(Icons.Default.Settings, tr("সেটিংস", "Settings"))
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (screen == "main") {
                NavigationBar {
                    NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.Home, null) }, label = { Text(tr("ড্যাশবোর্ড", "Dashboard")) })
                    NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Default.List, null) }, label = { Text(tr("দৈনিক", "Daily")) })
                    NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Default.ShoppingCart, null) }, label = { Text("New Entry") })
                    NavigationBarItem(tab == 3, { tab = 3 }, { Icon(Icons.Default.Person, null) }, label = { Text(tr("অ্যাকাউন্ট", "Accounts")) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (screen) {
                "settings" -> SettingsScreen(st, accs, cards, txns, vm) { go(it) }
                "cards" -> CardReportScreen(cards, txns)
                "budget" -> BudgetScreen(txns, budgets, ym, { c, a -> vm.saveBudget(c, a) }, { c -> vm.deleteBudget(c) })
                "statement" -> StatementScreen(accs, cards, txns, ym, st.userName)
                "profile" -> ProfileScreen(st, account, vm)
                "debtors" -> DebtorsScreen(debtors, pays, { vm.saveDebtor(it) }, { selDebtor = it; go("debtorDetail") })
                "debtorDetail" -> {
                    val d = debtors.firstOrNull { it.id == selDebtor }
                    if (d != null) {
                        DebtorDetailScreen(
                            d, pays, st.userName, bn,
                            { vm.saveDebtor(it) },
                            { amt, full, ptp -> vm.payDebtor(d, amt, full, ptp) },
                            { vm.deleteDebtor(d); back() }
                        )
                    }
                }
                "planned" -> PlannedScreen(planned, txns, { vm.savePlanned(it) }, { vm.deletePlanned(it) })
                "banks" -> BanksScreen(accs, txns) { selAcc = it; go("bankDetail") }
                "bankDetail" -> {
                    val a = accs.firstOrNull { it.id == selAcc }
                    if (a != null) AccountStatementScreen(a, accs, cards, txns, ym, st.userName)
                }
                // সেটিংস → Modify: এখান থেকেই সব এন্ট্রি ও অ্যাকাউন্ট বদলানো যায়
                "modExpense" -> ModifyEntriesScreen(
                    accs, cards, txns, setOf("EXPENSE"), tr("এই মাসে কোনো ব্যয় নেই", "No expenses this month")
                ) { editing = it }
                "modIncome" -> ModifyEntriesScreen(
                    accs, cards, txns, setOf("INCOME"), tr("এই মাসে কোনো আয় নেই", "No income this month")
                ) { editing = it }
                "modOther" -> ModifyEntriesScreen(
                    accs, cards, txns, setOf("TRANSFER", "CARD_BILL"),
                    tr("এই মাসে কোনো ট্রান্সফার বা কার্ড বিল নেই", "No transfers or card bills this month")
                ) { editing = it }
                "modBanks" -> ModifyAccountsScreen(accs, txns) { vm.saveAccount(it) }
                "modCards" -> ModifyCardsScreen(cards, txns) { vm.saveCard(it) }
                // ড্যাশবোর্ডের তালিকা শুধু দেখার জন্য
                "monthExpense" -> MonthListScreen(
                    accs, cards, txns, ym, setOf("EXPENSE"),
                    tr("এই মাসে কোনো ব্যয় নেই", "No expenses this month"), editable = false
                ) { }
                "monthIncome" -> MonthListScreen(
                    accs, cards, txns, ym, setOf("INCOME"),
                    tr("এই মাসে কোনো আয় নেই", "No income this month"), editable = false
                ) { }
                "monthOther" -> MonthListScreen(
                    accs, cards, txns, ym, setOf("TRANSFER", "CARD_BILL"),
                    tr("এই মাসে কোনো ট্রান্সফার বা কার্ড বিল নেই", "No transfers or card bills this month"), editable = false
                ) { }
                else -> when (tab) {
                    0 -> DashboardScreen(
                        accs = accs, cards = cards, txns = txns, budgets = budgets, ym = ym,
                        onMonth = { selMonth = it.toString() },
                        onCards = { go("cards") },
                        onExpense = { go("monthExpense") },
                        onIncome = { go("monthIncome") },
                        onOther = { go("monthOther") },
                        onBudget = { go("budget") }
                    )
                    1 -> DailyScreen(accs, cards, txns)
                    2 -> EntryScreen(accs, cards) { t ->
                        vm.saveTxn(t)
                        warn = budgetWarning(t, txns, budgets, bn)
                    }
                    else -> AccountsScreen(accs, cards, txns)
                }
            }
        }
    }

    editing?.let { e ->
        TxnDialog(
            accs = accs,
            cards = cards,
            existing = e,
            onSave = { t ->
                vm.saveTxn(t)
                warn = budgetWarning(t, txns, budgets, bn)
                editing = null
            },
            onDelete = { vm.deleteTxn(e); editing = null },
            onDismiss = { editing = null }
        )
    }

    warn?.let { w ->
        AlertDialog(
            onDismissRequest = { warn = null },
            title = { Text("⚠ " + tr("বাজেট সতর্কতা", "Budget warning")) },
            text = { Text(w) },
            confirmButton = { TextButton({ warn = null }) { Text("OK") } }
        )
    }
}
