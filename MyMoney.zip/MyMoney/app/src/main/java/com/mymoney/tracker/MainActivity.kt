package com.mymoney.tracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mymoney.tracker.data.Txn
import com.mymoney.tracker.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface { App() } } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: MoneyViewModel = viewModel()) {
    val accs by vm.accounts.collectAsState()
    val txns by vm.txns.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Txn?>(null) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("আমার হিসাব") }) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.Home, null) }, label = { Text("ড্যাশবোর্ড") })
                NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Default.List, null) }, label = { Text("দৈনিক") })
                NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Default.Person, null) }, label = { Text("অ্যাকাউন্ট") })
            }
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { editing = null; showDialog = true }) {
                Icon(Icons.Default.Add, "নতুন এন্ট্রি")
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> DashboardScreen(accs, txns)
                1 -> DailyScreen(accs, txns) { editing = it; showDialog = true }
                else -> AccountsScreen(accs, txns) { vm.saveAccount(it) }
            }
        }
    }

    if (showDialog) {
        val e = editing
        TxnDialog(
            accs = accs,
            existing = e,
            onSave = { vm.saveTxn(it); showDialog = false },
            onDelete = if (e != null) ({ vm.deleteTxn(e); showDialog = false }) else null,
            onDismiss = { showDialog = false }
        )
    }
}
