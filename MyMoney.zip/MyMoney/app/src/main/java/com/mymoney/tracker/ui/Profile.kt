package com.mymoney.tracker.ui

import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mymoney.tracker.MoneyViewModel
import com.mymoney.tracker.data.*
import java.io.File
import java.time.LocalDate

@Composable
fun ProfileScreen(st: SettingsState, email: String?, vm: MoneyViewModel) {
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.setPhoto(uri)
    }
    var name by remember(st.userName) { mutableStateOf(st.userName) }
    var mobile by remember(st.mobile) { mutableStateOf(st.mobile) }
    var dob by remember(st.dob) {
        mutableStateOf<Long?>(runCatching { LocalDate.parse(st.dob).toMillis() }.getOrNull())
    }
    var saved by remember { mutableStateOf(false) }
    val file = File(ctx.filesDir, "profile.jpg")
    val bmp = remember(st.photoVersion) {
        if (file.exists()) BitmapFactory.decodeFile(file.path)?.asImageBitmap() else null
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (bmp != null) {
            Image(bmp, null, Modifier.size(110.dp).clip(CircleShape), contentScale = ContentScale.Crop)
        } else {
            Box(Modifier.size(110.dp).clip(CircleShape).background(Color(0x33888888)), contentAlignment = Alignment.Center) {
                Text(name.take(1).uppercase().ifEmpty { "?" }, style = MaterialTheme.typography.headlineLarge)
            }
        }
        OutlinedButton({ picker.launch("image/*") }) { Text(tr("ছবি বদলান", "Change photo")) }
        OutlinedTextField(name, { name = it; saved = false }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            label = { Text(tr("আপনার নাম", "Your name")) })
        OutlinedTextField(mobile, { mobile = it; saved = false }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            label = { Text(tr("ফোন নম্বর", "Phone number")) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
        DateField(tr("জন্মতারিখ", "Date of birth"), dob, { dob = it; saved = false })
        if (!email.isNullOrBlank()) Text("Email: $email", style = MaterialTheme.typography.bodyMedium)
        Button({
            vm.saveProfile(name.trim(), normMobile(mobile), dob?.let { millisToDate(it).toString() } ?: "")
            saved = true
        }, Modifier.fillMaxWidth()) { Text(tr("সেভ করুন", "Save")) }
        if (saved) Text(tr("প্রোফাইল সেভ হয়েছে ✅", "Profile saved ✅"), color = Green)
        Text(tr("নাম অ্যাকাউন্ট ট্যাবের উপরে ও PDF স্টেটমেন্টে দেখায়। মোবাইল ও জন্মতারিখ পাসওয়ার্ড রিসেটে কাজে লাগে। ছবি শুধু এই ফোনে থাকে।",
            "Your name shows on the Accounts tab and PDFs. Mobile and date of birth are used for password reset. The photo stays on this phone only."),
            style = MaterialTheme.typography.bodySmall)
    }
}
