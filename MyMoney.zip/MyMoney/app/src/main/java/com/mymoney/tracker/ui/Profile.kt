package com.mymoney.tracker.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.exifinterface.media.ExifInterface
import com.mymoney.tracker.MoneyViewModel
import com.mymoney.tracker.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate
import kotlin.math.roundToInt

/** গ্যালারির ছবি ছোট করে (সর্বোচ্চ ~১৬০০px) এবং EXIF অনুযায়ী ঘুরিয়ে কাটার জন্য খোলে */
private fun decodeForCrop(ctx: Context, uri: Uri): Bitmap? {
    return try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return null
        val orient = ctx.contentResolver.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } ?: ExifInterface.ORIENTATION_NORMAL
        val deg = when (orient) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (deg == 0f) raw else {
            val m = Matrix().apply { postRotate(deg) }
            Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
        }
    } catch (e: Exception) {
        null
    }
}

/** ছবি সেট করার আগে কাটার ডায়ালগ: টেনে সরান, দুই আঙুলে বড়/ছোট করুন; গোল ফ্রেমের ভেতরের অংশ থাকবে */
@Composable
private fun CropDialog(bmp: Bitmap, onDone: (Bitmap) -> Unit, onCancel: () -> Unit) {
    val img = remember(bmp) { bmp.asImageBitmap() }
    val bw = bmp.width.toFloat()
    val bh = bmp.height.toFloat()
    var zoom by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    var boxPx by remember { mutableFloatStateOf(0f) }

    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(tr("ছবি কেটে ঠিক করুন", "Crop photo")) },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("টেনে সরান, দুই আঙুলে বড়/ছোট করুন", "Drag to move, pinch to zoom"),
                    style = MaterialTheme.typography.bodySmall)
                Canvas(
                    Modifier.size(260.dp).clipToBounds().background(Color.Black)
                        .onSizeChanged { boxPx = it.width.toFloat() }
                        .pointerInput(bmp) {
                            detectTransformGestures { _, pan, zoomChange, _ ->
                                val s = size.width.toFloat()
                                val base = s / minOf(bw, bh)
                                zoom = (zoom * zoomChange).coerceIn(1f, 6f)
                                val w = bw * base * zoom
                                val h = bh * base * zoom
                                val maxX = (w - s) / 2f
                                val maxY = (h - s) / 2f
                                off = Offset(
                                    (off.x + pan.x).coerceIn(-maxX, maxX),
                                    (off.y + pan.y).coerceIn(-maxY, maxY)
                                )
                            }
                        }
                ) {
                    val s = size.width
                    val sc = (s / minOf(bw, bh)) * zoom
                    val w = bw * sc
                    val h = bh * sc
                    val maxX = (w - s) / 2f
                    val maxY = (h - s) / 2f
                    val left = (s - w) / 2f + off.x.coerceIn(-maxX, maxX)
                    val top = (s - h) / 2f + off.y.coerceIn(-maxY, maxY)
                    drawImage(
                        img,
                        dstOffset = IntOffset(left.roundToInt(), top.roundToInt()),
                        dstSize = IntSize(w.roundToInt(), h.roundToInt())
                    )
                    drawCircle(Color.White, radius = s / 2f - 2f, style = Stroke(width = 3f))
                }
            }
        },
        confirmButton = {
            TextButton({
                val s = boxPx
                if (s <= 0f) {
                    onCancel()
                } else {
                    val sc = (s / minOf(bw, bh)) * zoom
                    val w = bw * sc
                    val h = bh * sc
                    val maxX = (w - s) / 2f
                    val maxY = (h - s) / 2f
                    val left = (s - w) / 2f + off.x.coerceIn(-maxX, maxX)
                    val top = (s - h) / 2f + off.y.coerceIn(-maxY, maxY)
                    val side = (s / sc).coerceAtMost(minOf(bw, bh))
                    val sx = (-left / sc).coerceIn(0f, bw - side)
                    val sy = (-top / sc).coerceIn(0f, bh - side)
                    val px = side.toInt().coerceAtLeast(1)
                    onDone(Bitmap.createBitmap(bmp, sx.toInt(), sy.toInt(), px, px))
                }
            }) { Text(tr("এটাই রাখুন", "Use photo")) }
        },
        dismissButton = { TextButton(onCancel) { Text(tr("বাতিল", "Cancel")) } }
    )
}

@Composable
fun ProfileScreen(st: SettingsState, email: String?, vm: MoneyViewModel) {
    val ctx = LocalContext.current
    val tick = LocalTick.current
    var picked by remember { mutableStateOf<Uri?>(null) }
    var cropSrc by remember { mutableStateOf<Bitmap?>(null) }
    var big by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> picked = uri }
    LaunchedEffect(picked) {
        val u = picked
        if (u != null) {
            cropSrc = withContext(Dispatchers.IO) { decodeForCrop(ctx, u) }
            picked = null
        }
    }
    var name by remember(st.userName) { mutableStateOf(st.userName) }
    var mobile by remember(st.mobile) { mutableStateOf(st.mobile) }
    var dob by remember(st.dob) {
        mutableStateOf<Long?>(runCatching { LocalDate.parse(st.dob).toMillis() }.getOrNull())
    }
    var saved by remember { mutableStateOf(false) }
    val file = File(ctx.filesDir, vm.photoName)
    val bmp = remember(st.photoVersion) {
        if (file.exists()) BitmapFactory.decodeFile(file.path)?.asImageBitmap() else null
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (bmp != null) {
            Image(bmp, null, Modifier.size(110.dp).clip(CircleShape).clickable { big = true }, contentScale = ContentScale.Crop)
            Text(tr("ছবিতে ট্যাপ করলে বড় দেখা যাবে", "Tap the photo to enlarge"), style = MaterialTheme.typography.labelSmall)
        } else {
            Box(Modifier.size(110.dp).clip(CircleShape).background(Color(0x33888888)), contentAlignment = Alignment.Center) {
                Text(name.take(1).uppercase().ifEmpty { "?" }, style = MaterialTheme.typography.headlineLarge)
            }
        }
        OutlinedButton({ picker.launch("image/*") }) { Text(tr("ছবি বদলান", "Change photo")) }
        OutlinedTextField(name, { name = it; saved = false }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            label = { Text(tr("আপনার নাম", "Your name")) })
        OutlinedTextField(mobile, { mobile = it; saved = false }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            label = { Text(tr("ফোন নম্বর", "Phone number")) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
        DateField(tr("জন্মতারিখ", "Date of birth"), dob, { dob = it; saved = false })
        if (!email.isNullOrBlank()) Text("Email: $email", style = MaterialTheme.typography.bodyMedium)
        Button({
            vm.saveProfile(name.trim(), normMobile(mobile), dob?.let { millisToDate(it).toString() } ?: "")
            saved = true
            tick()
        }, Modifier.fillMaxWidth()) { Text(tr("সেভ করুন", "Save")) }
        if (saved) Text(tr("প্রোফাইল সেভ হয়েছে ✅", "Profile saved ✅"), color = Green)
        Text(tr("নাম, ছবি ও বিবরণ আপনার অ্যাকাউন্টের ক্লাউড ব্যাকআপে নিজে নিজে সেভ হয়, তাই অন্য ফোনে একই অ্যাকাউন্টে লগইন করলে এগুলোও আসবে।",
            "Your name, photo and details are backed up automatically with your account, so they appear when you log in on another phone."),
            style = MaterialTheme.typography.bodySmall)
    }

    cropSrc?.let { src ->
        CropDialog(src, { vm.setPhotoBitmap(it); cropSrc = null; tick() }, { cropSrc = null })
    }
    if (big && bmp != null) {
        Dialog(onDismissRequest = { big = false }) {
            Image(bmp, null,
                Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(16.dp)).clickable { big = false },
                contentScale = ContentScale.Fit)
        }
    }
}
