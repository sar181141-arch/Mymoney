package com.mymoney.tracker.data

import androidx.room.*
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** isCash=true হলে ক্যাশ অ্যাকাউন্ট। last5 = ব্যাংক অ্যাকাউন্টের শেষ ৫ ডিজিট। smsBalance = ব্যাংকের SMS-এ জানানো সর্বশেষ ব্যালেন্স। */
@Entity(tableName = "accounts")
data class Account(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val last5: String = "",
    val openingBalance: Double = 0.0,
    val isCash: Boolean = false,
    val smsBalance: Double? = null,
    @ColumnInfo(defaultValue = "0") val smsBalanceAt: Long = 0
)

/** ক্রেডিট কার্ড: ব্যাংকের নাম + শেষ ৪ ডিজিট। openingDue = শুরুর বকেয়া, creditLimit = কার্ড লিমিট। */
@Entity(tableName = "cards")
data class CreditCard(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bankName: String,
    val last4: String,
    val openingDue: Double = 0.0,
    @ColumnInfo(defaultValue = "0") val creditLimit: Double = 0.0
)

/**
 * type: INCOME | EXPENSE | TRANSFER | CARD_BILL
 * EXPENSE + cardId != null  => ক্রেডিট কার্ড খরচ (ব্যাংক/ক্যাশ ব্যালেন্স কমবে না, accountId = 0)
 * CARD_BILL => accountId ব্যাংক থেকে cardId কার্ডের বিল পেমেন্ট (আয়-ব্যয়ে গণনা হয় না)
 */
@Entity(tableName = "txns")
data class Txn(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val amount: Double,
    val accountId: Long,
    val toAccountId: Long? = null,
    val cardId: Long? = null,
    val category: String = "",
    val note: String = "",
    val dateMillis: Long,
    val source: String = "MANUAL"
)

/** মাসিক বাজেট: category = খাতের নাম; "__TOTAL__" = মোট মাসিক বাজেট */
@Entity(tableName = "budgets")
data class Budget(
    @PrimaryKey val category: String,
    val limitAmount: Double
)

/** যে SMS একবার প্রসেস হয়েছে তার hash, যাতে ডুপ্লিকেট না হয় (এন্ট্রি মুছলেও ফিরে আসবে না) */
@Entity(tableName = "sms_seen")
data class SmsSeen(@PrimaryKey val hash: String)

fun Txn.date(): LocalDate =
    Instant.ofEpochMilli(dateMillis).atZone(ZoneId.systemDefault()).toLocalDate()

fun LocalDate.toMillis(): Long =
    atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
