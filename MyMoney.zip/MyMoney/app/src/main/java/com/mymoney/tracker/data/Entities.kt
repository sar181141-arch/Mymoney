package com.mymoney.tracker.data

import androidx.room.*
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** isCash=true হলে এটি ক্যাশ অ্যাকাউন্ট। last5 = ব্যাংক অ্যাকাউন্টের শেষ ৫ ডিজিট (SMS মেলানোর জন্য)। */
@Entity(tableName = "accounts")
data class Account(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val last5: String = "",
    val openingBalance: Double = 0.0,
    val isCash: Boolean = false
)

/** type: INCOME | EXPENSE | TRANSFER (TRANSFER = এক অ্যাকাউন্ট থেকে আরেকটিতে, যেমন ATM থেকে ক্যাশ তোলা) */
@Entity(tableName = "txns")
data class Txn(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val amount: Double,
    val accountId: Long,
    val toAccountId: Long? = null,
    val category: String = "",
    val note: String = "",
    val dateMillis: Long,
    val source: String = "MANUAL" // পরে SMS ধাপে "SMS" হবে
)

fun Txn.date(): LocalDate =
    Instant.ofEpochMilli(dateMillis).atZone(ZoneId.systemDefault()).toLocalDate()

fun LocalDate.toMillis(): Long =
    atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
