package com.mymoney.tracker.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mymoney.tracker.data.*
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs

val Green = Color(0xFF43A047)
val Red = Color(0xFFE53935)

fun money(d: Double): String =
    (if (d < 0) "-₹" else "₹") + String.format(Locale("en", "IN"), "%,.2f", abs(d))

fun fmt(d: LocalDate, p: String): String = d.format(DateTimeFormatter.ofPattern(p, Locale.ENGLISH))

@Composable
fun StatCard(
    title: String, amount: Double, modifier: Modifier = Modifier, color: Color = Color.Unspecified,
    hint: String? = null, onClick: (() -> Unit)? = null
) {
    Card(if (onClick != null) modifier.clickable { onClick() } else modifier) {
        Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center)
            Text(money(amount), style = MaterialTheme.typography.titleLarge, color = color,
                fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            if (hint != null) Text(hint, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun KV(label: String, value: String, modifier: Modifier = Modifier, color: Color = Color.Unspecified) {
    Column(modifier.padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center)
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
            color = color, textAlign = TextAlign.Center)
    }
}

// ---------------- ড্যাশবোর্ড ----------------
@Composable
fun DashboardScreen(
    accs: List<Account>, cards: List<CreditCard>, txns: List<Txn>, budgets: List<Budget>,
    ym: YearMonth, onMonth: (YearMonth) -> Unit, onCards: () -> Unit, onExpense: () -> Unit,
    onIncome: () -> Unit, onOther: () -> Unit, onBudget: () -> Unit
) {
    val bal = remember(accs, txns) { accountBalances(accs, txns) }
    val cash = accs.filter { it.isCash }.sumOf { bal[it.id] ?: 0.0 }
    val banks = accs.filter { !it.isCash }
    val bank = banks.sumOf { bal[it.id] ?: 0.0 }
    val today = LocalDate.now()
    val nowYm = YearMonth.from(today)
    var menu by remember { mutableStateOf(false) }
    var showBanks by remember { mutableStateOf(false) }
    val months = remember(txns) {
        (txns.map { YearMonth.from(it.date()) } + (0..11).map { nowYm.minusMonths(it.toLong()) })
            .distinct().sortedDescending()
    }
    val alerts = remember(txns, budgets, ym) { budgetAlerts(txns, budgets, ym) }

    fun mTotal(type: String) = txns
        .filter { it.type == type && YearMonth.from(it.date()) == ym }.sumOf { it.amount }

    val cardMonth = txns
        .filter { it.type == "EXPENSE" && it.cardId != null && YearMonth.from(it.date()) == ym }
        .sumOf { it.amount }
    val totalLimit = cards.sumOf { it.creditLimit }
    val totalDue = cards.sumOf { cardDue(it, txns) }
    val monthLabel = (if (ym == nowYm) tr("এই মাস", "This month") + " · " else "") + fmt(ym.atDay(1), "MMM yyyy")
    val lbSms = tr("ব্যাংকের SMS ব্যালেন্স: ", "Bank SMS balance: ")
    val lbDiff = tr("অমিল: ", "Difference: ")

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Text(tr("আজ পর্যন্ত", "As on date") + " (${fmt(today, "dd MMM yyyy")})",
                Modifier.fillMaxWidth(), style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        }
        if (alerts.isNotEmpty()) {
            item {
                Card(Modifier.fillMaxWidth().clickable { onBudget() },
                    colors = CardDefaults.cardColors(containerColor = Color(0x33E53935))) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("⚠ " + tr("বাজেট সতর্কতা", "Budget alert"), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        alerts.take(3).forEach { a ->
                            val over = a.spent > a.limit
                            Text(
                                budgetName(a.category) + ": " + money(a.spent) + " / " + money(a.limit) +
                                    (if (over) " — " + tr("ছাড়িয়েছে", "exceeded") else ""),
                                color = if (over) Red else Color(0xFFFB8C00),
                                style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center
                            )
                        }
                        Text(tr("বিস্তারিত ▸", "Details ▸"), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        item {
            StatCard(tr("মোট ব্যালেন্স (সব অ্যাকাউন্ট + ক্যাশ)", "Consolidated balance (all accounts + cash)"),
                cash + bank, Modifier.fillMaxWidth())
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard(tr("ক্যাশ ব্যালেন্স", "Cash balance"), cash, Modifier.weight(1f))
                StatCard(tr("ব্যাংক ব্যালেন্স", "Bank balance"), bank, Modifier.weight(1f),
                    hint = if (showBanks) tr("লুকান ▴", "Hide ▴") else tr("অ্যাকাউন্ট দেখুন ▾", "Show accounts ▾"),
                    onClick = { showBanks = !showBanks })
            }
        }
        if (showBanks) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (banks.isEmpty()) Text(tr("কোনো ব্যাংক অ্যাকাউন্ট যোগ করা হয়নি", "No bank accounts added"), textAlign = TextAlign.Center)
                        banks.forEach { a ->
                            val computed = bal[a.id] ?: 0.0
                            val sb = a.smsBalance
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${a.name} ••••${a.last5}", textAlign = TextAlign.Center)
                                Text(money(computed), style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                                if (sb != null) {
                                    val at = Instant.ofEpochMilli(a.smsBalanceAt).atZone(ZoneId.systemDefault()).toLocalDate()
                                    Text(lbSms + money(sb) + " (" + fmt(at, "dd MMM") + ")",
                                        style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
                                    if (abs(computed - sb) > 0.5) {
                                        Text(lbDiff + money(computed - sb), color = Color(0xFFFB8C00),
                                            style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        item {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box {
                    OutlinedButton({ menu = true }) { Text("$monthLabel  ▼") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        months.forEach { m ->
                            DropdownMenuItem(
                                text = { Text(fmt(m.atDay(1), "MMMM yyyy")) },
                                onClick = { onMonth(m); menu = false }
                            )
                        }
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard(tr("আয়", "Income"), mTotal("INCOME"), Modifier.weight(1f), Green,
                    hint = tr("পুরো মাসের তালিকা ▸", "Full month list ▸"), onClick = onIncome)
                StatCard(tr("ব্যয়", "Expense"), mTotal("EXPENSE"), Modifier.weight(1f), Red,
                    hint = tr("পুরো মাসের তালিকা ▸", "Full month list ▸"), onClick = onExpense)
            }
        }
        item {
            val otherCount = txns.count {
                (it.type == "TRANSFER" || it.type == "CARD_BILL") && YearMonth.from(it.date()) == ym
            }
            Card(Modifier.fillMaxWidth().clickable { onOther() }) {
                Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(tr("ট্রান্সফার ও কার্ড বিল", "Transfers & card bills"), fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
                    Text("$otherCount", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(tr("দেখতে ও বদলাতে ট্যাপ করুন ▸", "Tap to view / edit ▸"), style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth().clickable { onCards() }) {
                Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("💳 " + tr("ক্রেডিট কার্ড রিপোর্ট", "Credit card report"), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Row(Modifier.fillMaxWidth()) {
                        KV(tr("মাসের খরচ", "Spent in month") + " (${fmt(ym.atDay(1), "MMM yy")})", money(cardMonth), Modifier.weight(1f), Red)
                        KV(tr("মোট খরচ (বকেয়া)", "Total spent (due)"), money(totalDue), Modifier.weight(1f))
                    }
                    if (totalLimit > 0) {
                        Row(Modifier.fillMaxWidth()) {
                            KV(tr("মোট লিমিট", "Total limit"), money(totalLimit), Modifier.weight(1f))
                            KV(tr("মোট outstanding (লিমিট − খরচ)", "Outstanding (limit − spent)"),
                                money(totalLimit - totalDue), Modifier.weight(1f), Green)
                        }
                    }
                    Text(
                        if (cards.isEmpty()) tr("কার্ড যোগ করুন: অ্যাকাউন্ট ট্যাব → + নতুন ক্রেডিট কার্ড", "Add a card: Accounts tab → + New credit card")
                        else tr("কার্ডভিত্তিক মাসিক খরচ দেখতে ট্যাপ করুন", "Tap for card-wise monthly spend"),
                        style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

// ---------------- লেনদেনের সারি (দৈনিক ও মাসের ব্যয় তালিকায় ব্যবহৃত) ----------------
@Composable
fun TxnRow(t: Txn, names: Map<Long, String>, cardNames: Map<Long, String>, onClick: (() -> Unit)?) {
    val other = "Other"
    val billLabel = tr("কার্ড বিল", "Card bill")
    val (color, sign) = when (t.type) {
        "INCOME" -> Green to "+"
        "EXPENSE" -> Red to "-"
        else -> Color.Gray to ""
    }
    val sub = when (t.type) {
        "TRANSFER" -> "${names[t.accountId]} → ${names[t.toAccountId]}"
        "CARD_BILL" -> "${names[t.accountId]} → ${cardNames[t.cardId]}"
        else -> if (t.cardId != null) "💳 ${cardNames[t.cardId]}" else names[t.accountId] ?: ""
    }
    val title = catLabel(t.category.ifEmpty { if (t.type == "CARD_BILL") billLabel else other })
    val base = Modifier.fillMaxWidth()
    Card(if (onClick != null) base.clickable { onClick() } else base) {
        Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Medium)
                Text(
                    listOf(sub, t.note, if (t.source == "SMS") "SMS" else "", fmtTime(t.dateMillis))
                        .filter { it.isNotBlank() }.joinToString(" • "),
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Text(sign + money(t.amount), color = color, fontWeight = FontWeight.Bold)
        }
    }
}

// ---------------- মাসের তালিকা: ব্যয় / আয় / ট্রান্সফার ও কার্ড বিল (ট্যাপ করে এডিট বা মোছা যায়) ----------------
@Composable
fun MonthListScreen(
    accs: List<Account>, cards: List<CreditCard>, txns: List<Txn>, ym: YearMonth,
    types: Set<String>, emptyText: String, editable: Boolean = true, onEdit: (Txn) -> Unit
) {
    val list = txns.filter { it.type in types && YearMonth.from(it.date()) == ym }
    val single = types.size == 1
    val headColor = if (types.contains("INCOME")) Green else Red
    val names = accs.associate { it.id to it.name }
    val cardNames = cards.associate { it.id to "${it.bankName} ••${it.last4}" }
    val grouped = list.groupBy { it.date() }.toSortedMap(compareByDescending { it })
    val countLabel = tr(" টি এন্ট্রি", " entries")

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(ym.atDay(1), "MMMM yyyy"), style = MaterialTheme.typography.titleMedium)
            if (single) Text(money(list.sumOf { it.amount }), color = headColor, fontWeight = FontWeight.Bold)
            else Text("${list.size}$countLabel", fontWeight = FontWeight.Bold)
        }
        if (editable) {
            Text(tr("বদলাতে বা মুছতে কোনো এন্ট্রিতে ট্যাপ করুন", "Tap an entry to edit or delete it"),
                Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodySmall)
        }
        HorizontalDivider(Modifier.padding(top = 8.dp))
        if (list.isEmpty()) Text(emptyText, Modifier.padding(16.dp))
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            grouped.forEach { (day, dayList) ->
                item(key = day.toString()) {
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(fmt(day, "EEE, dd MMM"), fontWeight = FontWeight.Bold)
                        if (single) Text(money(dayList.sumOf { it.amount }), style = MaterialTheme.typography.bodySmall)
                    }
                }
                items(dayList, key = { it.id }) { t ->
                    TxnRow(t, names, cardNames, if (editable) ({ onEdit(t) }) else null)
                }
            }
        }
    }
}

// ---------------- দৈনিক (তারিখ বেছে সেই দিনের সব এন্ট্রি দেখুন, শুধু দেখার জন্য) ----------------
@Composable
fun DailyScreen(accs: List<Account>, cards: List<CreditCard>, txns: List<Txn>) {
    var day by rememberSaveable { mutableStateOf(LocalDate.now().toString()) }
    val d = LocalDate.parse(day)
    val today = LocalDate.now()
    var menu by remember { mutableStateOf(false) }
    var picking by remember { mutableStateOf(false) }
    val list = txns.filter { it.date() == d }.sortedBy { it.dateMillis }
    val inc = list.filter { it.type == "INCOME" }.sumOf { it.amount }
    val exp = list.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    val names = accs.associate { it.id to it.name }
    val cardNames = cards.associate { it.id to "${it.bankName} ••${it.last4}" }
    val recent = remember(today) { (0..13).map { today.minusDays(it.toLong()) } }
    val lbToday = tr("আজ", "Today")
    val lbYest = tr("গতকাল", "Yesterday")

    fun label(x: LocalDate): String {
        val pre = if (x == today) "$lbToday · " else if (x == today.minusDays(1)) "$lbYest · " else ""
        return pre + fmt(x, "EEE, dd MMM yyyy")
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton({ day = d.minusDays(1).toString() }) { Text("◀") }
            Box {
                OutlinedButton({ menu = true }) { Text(label(d) + "  ▼") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    recent.forEach { x ->
                        DropdownMenuItem(
                            text = { Text(label(x)) },
                            onClick = { day = x.toString(); menu = false }
                        )
                    }
                    DropdownMenuItem(
                        text = { Text("📅 " + tr("অন্য তারিখ বেছে নিন…", "Pick another date…")) },
                        onClick = { menu = false; picking = true }
                    )
                }
            }
            TextButton({ day = d.plusDays(1).toString() }) { Text("▶") }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(tr("আয় ", "In ") + money(inc), color = Green, fontWeight = FontWeight.Bold)
            Text(tr("ব্যয় ", "Out ") + money(exp), color = Red, fontWeight = FontWeight.Bold)
        }
        HorizontalDivider(Modifier.padding(top = 8.dp))
        if (list.isEmpty()) Text(tr("এই তারিখে কোনো এন্ট্রি নেই", "No entries on this date"), Modifier.padding(16.dp))
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(list, key = { it.id }) { t -> TxnRow(t, names, cardNames, null) }
        }
    }
    if (picking) DatePickDialog(d, { day = it.toString() }, { picking = false })
}

// ---------------- ক্রেডিট কার্ড রিপোর্ট ----------------
@Composable
fun CardReportScreen(cards: List<CreditCard>, txns: List<Txn>) {
    var ym by remember { mutableStateOf(YearMonth.now()) }
    var open by remember { mutableStateOf<Long?>(null) }
    val lbLimit = tr("লিমিট: ", "Limit: ")
    val lbDue = tr("খরচ (বকেয়া): ", "Spent (due): ")
    val lbOut = tr("outstanding: ", "Outstanding: ")

    fun spend(cardId: Long, m: YearMonth) = txns
        .filter { it.cardId == cardId && it.type == "EXPENSE" && YearMonth.from(it.date()) == m }
        .sumOf { it.amount }

    val monthTotal = cards.sumOf { spend(it.id, ym) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton({ ym = ym.minusMonths(1) }) { Text("◀") }
            Text(fmt(ym.atDay(1), "MMMM yyyy"), style = MaterialTheme.typography.titleMedium)
            TextButton({ ym = ym.plusMonths(1) }) { Text("▶") }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(tr("সব কার্ড মিলিয়ে খরচ", "All cards spend"), fontWeight = FontWeight.Bold)
            Text(money(monthTotal), color = Red, fontWeight = FontWeight.Bold)
        }
        HorizontalDivider(Modifier.padding(top = 8.dp))
        if (cards.isEmpty()) {
            Text(tr("কোনো কার্ড যোগ করা হয়নি। অ্যাকাউন্ট ট্যাবে গিয়ে কার্ড যোগ করুন।", "No cards added yet. Add one in the Accounts tab."), Modifier.padding(16.dp))
        }
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(cards, key = { it.id }) { c ->
                val list = txns.filter { it.cardId == c.id && it.type == "EXPENSE" && YearMonth.from(it.date()) == ym }
                    .sortedByDescending { it.dateMillis }
                val due = cardDue(c, txns)
                Card(Modifier.fillMaxWidth().clickable { open = if (open == c.id) null else c.id }) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${c.bankName} ••${c.last4}", fontWeight = FontWeight.Bold)
                            Text(money(spend(c.id, ym)), color = Red, fontWeight = FontWeight.Bold)
                        }
                        if (c.creditLimit > 0) Text(lbLimit + money(c.creditLimit), style = MaterialTheme.typography.bodySmall)
                        Text(lbDue + money(due), style = MaterialTheme.typography.bodySmall)
                        if (c.creditLimit > 0) {
                            Text(lbOut + money(c.creditLimit - due), color = Green, style = MaterialTheme.typography.bodySmall)
                        }
                        if (open == c.id) {
                            HorizontalDivider(Modifier.padding(vertical = 4.dp))
                            if (list.isEmpty()) Text(tr("এই মাসে কোনো খরচ নেই", "No spend this month"))
                            list.forEach { t ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(fmt(t.date(), "dd MMM") + "  " +
                                        listOf(t.category, t.note).filter { it.isNotBlank() }.joinToString(" • "),
                                        Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                                    Text(money(t.amount), style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            HorizontalDivider(Modifier.padding(vertical = 4.dp))
                            Text(tr("মাসভিত্তিক খরচ (শেষ ৬ মাস)", "Monthly spend (last 6 months)"),
                                style = MaterialTheme.typography.labelMedium)
                            (0..5).map { ym.minusMonths(it.toLong()) }.forEach { m ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(fmt(m.atDay(1), "MMM yyyy"), style = MaterialTheme.typography.bodySmall)
                                    Text(money(spend(c.id, m)), style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- অ্যাকাউন্ট (শুধু দেখার জন্য: Cash, Bank Account, Credit Card) ----------------
@Composable
fun AccountsScreen(accs: List<Account>, cards: List<CreditCard>, txns: List<Txn>) {
    val bal = remember(accs, txns) { accountBalances(accs, txns) }
    val cash = accs.filter { it.isCash }
    val banks = accs.filter { !it.isCash }
    val ym = YearMonth.now()
    val lbSms = tr("ব্যাংকের SMS ব্যালেন্স: ", "Bank SMS balance: ")
    val lbLimit = tr("লিমিট: ", "Limit: ")
    val lbDue = tr("খরচ (বকেয়া): ", "Spent (due): ")
    val lbOut = tr("outstanding: ", "Outstanding: ")
    val lbMonth = tr("এই মাসের খরচ: ", "This month: ")

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        CollapsibleCard("💵 Cash", startOpen = true) {
            cash.forEach { a ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(tr("ক্যাশ ব্যালেন্স", "Cash balance"))
                    Text(money(bal[a.id] ?: 0.0), fontWeight = FontWeight.Bold)
                }
            }
        }
        CollapsibleCard("🏦 " + tr("ব্যাংক অ্যাকাউন্ট · Bank Account", "Bank Account")) {
            if (banks.isEmpty()) Text(tr("কোনো ব্যাংক অ্যাকাউন্ট যোগ করা হয়নি", "No bank accounts added"))
            banks.forEach { a ->
                val sb = a.smsBalance
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(a.name, fontWeight = FontWeight.Bold)
                            Text("A/c ••••${a.last5}", style = MaterialTheme.typography.bodySmall)
                        }
                        Text(money(bal[a.id] ?: 0.0), fontWeight = FontWeight.Bold)
                    }
                    if (sb != null) Text(lbSms + money(sb), style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        CollapsibleCard("💳 " + tr("ক্রেডিট কার্ড · Credit Card", "Credit Card")) {
            if (cards.isEmpty()) Text(tr("কোনো ক্রেডিট কার্ড যোগ করা হয়নি", "No credit cards added"))
            cards.forEach { c ->
                val due = cardDue(c, txns)
                val month = txns.filter {
                    it.cardId == c.id && it.type == "EXPENSE" && YearMonth.from(it.date()) == ym
                }.sumOf { it.amount }
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("${c.bankName} ••${c.last4}", fontWeight = FontWeight.Bold)
                    if (c.creditLimit > 0) Text(lbLimit + money(c.creditLimit), style = MaterialTheme.typography.bodySmall)
                    Text(lbDue + money(due), style = MaterialTheme.typography.bodySmall)
                    if (c.creditLimit > 0) {
                        Text(lbOut + money(c.creditLimit - due), color = Green, style = MaterialTheme.typography.bodySmall)
                    }
                    Text(lbMonth + money(month), style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Text(tr("অ্যাকাউন্ট বা কার্ড যোগ/বদলাতে: সেটিংস → Modify", "To add or edit accounts/cards: Settings → Modify"),
            style = MaterialTheme.typography.bodySmall)
    }
}
