package com.mymoney.tracker.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mymoney.tracker.data.*
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs

val Green = Color(0xFF43A047)
val Red = Color(0xFFE53935)

fun money(d: Double): String =
    (if (d < 0) "-₹" else "₹") + String.format(Locale("en", "IN"), "%,.2f", abs(d))

fun fmt(d: LocalDate, p: String): String = d.format(DateTimeFormatter.ofPattern(p, Locale.ENGLISH))

@Composable
fun StatCard(title: String, amount: Double, modifier: Modifier = Modifier, color: Color = Color.Unspecified) {
    Card(modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.labelMedium)
            Text(money(amount), style = MaterialTheme.typography.titleLarge, color = color, fontWeight = FontWeight.Bold)
        }
    }
}

// ---------------- ড্যাশবোর্ড ----------------
@Composable
fun DashboardScreen(accs: List<Account>, cards: List<CreditCard>, txns: List<Txn>, onCards: () -> Unit) {
    val bal = remember(accs, txns) { accountBalances(accs, txns) }
    val cash = accs.filter { it.isCash }.sumOf { bal[it.id] ?: 0.0 }
    val bank = accs.filter { !it.isCash }.sumOf { bal[it.id] ?: 0.0 }
    val today = LocalDate.now()
    val ym = YearMonth.from(today)

    fun total(type: String, monthOnly: Boolean) = txns
        .filter { it.type == type && (!monthOnly || YearMonth.from(it.date()) == ym) }
        .sumOf { it.amount }

    val cardMonth = txns
        .filter { it.type == "EXPENSE" && it.cardId != null && YearMonth.from(it.date()) == ym }
        .sumOf { it.amount }
    val cardTotalDue = cards.sumOf { cardDue(it, txns) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(tr("আজ পর্যন্ত", "As on date") + " (${fmt(today, "dd MMM yyyy")})",
                style = MaterialTheme.typography.titleMedium)
        }
        item {
            StatCard(tr("মোট ব্যালেন্স (সব অ্যাকাউন্ট + ক্যাশ)", "Consolidated balance (all accounts + cash)"),
                cash + bank, Modifier.fillMaxWidth())
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard(tr("ক্যাশ ব্যালেন্স", "Cash balance"), cash, Modifier.weight(1f))
                StatCard(tr("ব্যাংক ব্যালেন্স", "Bank balance"), bank, Modifier.weight(1f))
            }
        }
        item { Text(tr("এই মাস", "This month"), style = MaterialTheme.typography.titleSmall) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard(tr("আয়", "Income"), total("INCOME", true), Modifier.weight(1f), Green)
                StatCard(tr("ব্যয়", "Expense"), total("EXPENSE", true), Modifier.weight(1f), Red)
            }
        }
        item { Text(tr("সর্বমোট (শুরু থেকে)", "All time"), style = MaterialTheme.typography.titleSmall) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard(tr("আয়", "Income"), total("INCOME", false), Modifier.weight(1f), Green)
                StatCard(tr("ব্যয়", "Expense"), total("EXPENSE", false), Modifier.weight(1f), Red)
            }
        }
        if (cards.isNotEmpty()) {
            item {
                Card(Modifier.fillMaxWidth().clickable { onCards() }) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("💳 " + tr("ক্রেডিট কার্ড রিপোর্ট", "Credit card report"), fontWeight = FontWeight.Bold)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(tr("এই মাসের খরচ", "Spent this month"))
                            Text(money(cardMonth), color = Red, fontWeight = FontWeight.Bold)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(tr("মোট বকেয়া", "Total outstanding"))
                            Text(money(cardTotalDue), fontWeight = FontWeight.Bold)
                        }
                        Text(tr("কার্ডভিত্তিক মাসিক খরচ দেখতে ট্যাপ করুন", "Tap for card-wise monthly spend"),
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        item { Text(tr("অ্যাকাউন্ট ভিত্তিক ব্যালেন্স", "Balance by account"), style = MaterialTheme.typography.titleSmall) }
        items(accs, key = { it.id }) { a ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(if (a.isCash) "Cash" else "${a.name} ••••${a.last5}")
                    Text(money(bal[a.id] ?: 0.0), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ---------------- ক্রেডিট কার্ড রিপোর্ট ----------------
@Composable
fun CardReportScreen(cards: List<CreditCard>, txns: List<Txn>) {
    var ym by remember { mutableStateOf(YearMonth.now()) }
    var open by remember { mutableStateOf<Long?>(null) }

    fun spend(cardId: Long, m: YearMonth) = txns
        .filter { it.cardId == cardId && it.type == "EXPENSE" && YearMonth.from(it.date()) == m }
        .sumOf { it.amount }

    val monthTotal = cards.sumOf { spend(it.id, ym) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton({ ym = ym.minusMonths(1) }) { Text("◀") }
            Text(fmt(ym.atDay(1), "MMMM yyyy"), style = MaterialTheme.typography.titleMedium)
            TextButton({ ym = ym.plusMonths(1) }) { Text("▶") }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(tr("সব কার্ড মিলিয়ে খরচ", "All cards spend"), fontWeight = FontWeight.Bold)
            Text(money(monthTotal), color = Red, fontWeight = FontWeight.Bold)
        }
        HorizontalDivider(Modifier.padding(top = 8.dp))
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(cards, key = { it.id }) { c ->
                val list = txns.filter { it.cardId == c.id && it.type == "EXPENSE" && YearMonth.from(it.date()) == ym }
                    .sortedByDescending { it.dateMillis }
                Card(Modifier.fillMaxWidth().clickable { open = if (open == c.id) null else c.id }) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${c.bankName} ••${c.last4}", fontWeight = FontWeight.Bold)
                            Text(money(spend(c.id, ym)), color = Red, fontWeight = FontWeight.Bold)
                        }
                        Text(tr("মোট বকেয়া: ", "Outstanding: ") + money(cardDue(c, txns)),
                            style = MaterialTheme.typography.bodySmall)
                        if (open == c.id) {
                            HorizontalDivider(Modifier.padding(vertical = 4.dp))
                            if (list.isEmpty()) Text(tr("এই মাসে কোনো খরচ নেই", "No spend this month"))
                            list.forEach { t ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(fmt(t.date(), "dd MMM") + "  " +
                                        listOf(t.category, t.note).filter { it.isNotBlank() }.joinToString(" • ")
                                            .ifEmpty { tr("অন্যান্য", "Other") },
                                        Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                                    Text(money(t.amount), style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            HorizontalDivider(Modifier.padding(vertical = 4.dp))
                            Text(tr("মাসভিত্তিক খরচ (শেষ ৬ মাস)", "Monthly spend (last 6 months)"),
                                style = MaterialTheme.typography.labelMedium)
                            (0..5).map { ym.minusMonths(it.toLong()) }.forEach { m ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(fmt(m.atDay(1), "MMM yyyy"), style = MaterialTheme.typography.bodySmall)
                                    Text(money(spend(c.id, m)), style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- দৈনিক হিসাব ----------------
@Composable
fun DailyScreen(accs: List<Account>, cards: List<CreditCard>, txns: List<Txn>, onEdit: (Txn) -> Unit) {
    var ym by remember { mutableStateOf(YearMonth.now()) }
    val inMonth = txns.filter { YearMonth.from(it.date()) == ym }
    val inc = inMonth.filter { it.type == "INCOME" }.sumOf { it.amount }
    val exp = inMonth.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    val names = accs.associate { it.id to it.name }
    val cardNames = cards.associate { it.id to "${it.bankName} ••${it.last4}" }
    val grouped = inMonth.groupBy { it.date() }.toSortedMap(compareByDescending { it })
    val other = tr("অন্যান্য", "Other")
    val billLabel = tr("কার্ড বিল", "Card bill")

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton({ ym = ym.minusMonths(1) }) { Text("◀") }
            Text(fmt(ym.atDay(1), "MMMM yyyy"), style = MaterialTheme.typography.titleMedium)
            TextButton({ ym = ym.plusMonths(1) }) { Text("▶") }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(tr("আয় ", "In ") + money(inc), color = Green, fontWeight = FontWeight.Bold)
            Text(tr("ব্যয় ", "Out ") + money(exp), color = Red, fontWeight = FontWeight.Bold)
            Text(tr("সঞ্চয় ", "Net ") + money(inc - exp), fontWeight = FontWeight.Bold)
        }
        HorizontalDivider(Modifier.padding(top = 8.dp))
        if (inMonth.isEmpty()) {
            Text(tr("এই মাসে কোনো এন্ট্রি নেই", "No entries this month"), Modifier.padding(16.dp))
        }
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            grouped.forEach { (day, list) ->
                item(key = day.toString()) {
                    val dIn = list.filter { it.type == "INCOME" }.sumOf { it.amount }
                    val dEx = list.filter { it.type == "EXPENSE" }.sumOf { it.amount }
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(fmt(day, "EEE, dd MMM"), fontWeight = FontWeight.Bold)
                        Text(tr("আয় ", "In ") + money(dIn) + " | " + tr("ব্যয় ", "Out ") + money(dEx),
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
                items(list, key = { it.id }) { t ->
                    val (color, sign) = when (t.type) {
                        "INCOME" -> Green to "+"
                        "EXPENSE" -> Red to "-"
                        else -> Color.Gray to ""
                    }
                    val sub = when (t.type) {
                        "TRANSFER" -> "${names[t.accountId]} → ${names[t.toAccountId]}"
                        "CARD_BILL" -> "${names[t.accountId]} → ${cardNames[t.cardId]}"
                        else -> if (t.cardId != null) "💳 ${cardNames[t.cardId]}" else names[t.accountId] ?: ""
                    }
                    val title = t.category.ifEmpty { if (t.type == "CARD_BILL") billLabel else other }
                    Card(Modifier.fillMaxWidth().clickable { onEdit(t) }) {
                        Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(title, fontWeight = FontWeight.Medium)
                                Text(
                                    listOf(sub, t.note, if (t.source == "SMS") "SMS" else "")
                                        .filter { it.isNotBlank() }.joinToString(" • "),
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            Text(sign + money(t.amount), color = color, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// ---------------- অ্যাকাউন্ট ----------------
@Composable
fun AccountsScreen(
    accs: List<Account>, cards: List<CreditCard>, txns: List<Txn>,
    onSaveAccount: (Account) -> Unit, onSaveCard: (CreditCard) -> Unit
) {
    val bal = remember(accs, txns) { accountBalances(accs, txns) }
    var editing by remember { mutableStateOf<Account?>(null) }
    var adding by remember { mutableStateOf(false) }
    var editingCard by remember { mutableStateOf<CreditCard?>(null) }
    var addingCard by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(accs, key = { "a${it.id}" }) { a ->
            Card(Modifier.fillMaxWidth().clickable { editing = a }) {
                Row(Modifier.padding(14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(a.name, fontWeight = FontWeight.Bold)
                        Text(if (a.isCash) tr("ক্যাশ", "Cash") else "A/c ••••${a.last5}", style = MaterialTheme.typography.bodySmall)
                    }
                    Text(money(bal[a.id] ?: 0.0), fontWeight = FontWeight.Bold)
                }
            }
        }
        item { Button({ adding = true }, Modifier.fillMaxWidth()) { Text(tr("+ নতুন ব্যাংক অ্যাকাউন্ট", "+ New bank account")) } }
        item { Text("💳 " + tr("ক্রেডিট কার্ড", "Credit cards"), style = MaterialTheme.typography.titleSmall) }
        items(cards, key = { "c${it.id}" }) { c ->
            Card(Modifier.fillMaxWidth().clickable { editingCard = c }) {
                Row(Modifier.padding(14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(c.bankName, fontWeight = FontWeight.Bold)
                        Text("Card ••${c.last4}", style = MaterialTheme.typography.bodySmall)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(tr("বকেয়া", "Due"), style = MaterialTheme.typography.labelSmall)
                        Text(money(cardDue(c, txns)), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item { Button({ addingCard = true }, Modifier.fillMaxWidth()) { Text(tr("+ নতুন ক্রেডিট কার্ড", "+ New credit card")) } }
        item {
            Text(tr("কার্ডে ট্যাপ করে তথ্য বদলানো যাবে।", "Tap a card to edit it."),
                style = MaterialTheme.typography.bodySmall)
        }
    }
    if (adding) AccountDialog(null, { onSaveAccount(it); adding = false }) { adding = false }
    editing?.let { e -> AccountDialog(e, { onSaveAccount(it); editing = null }) { editing = null } }
    if (addingCard) CardDialog(null, { onSaveCard(it); addingCard = false }) { addingCard = false }
    editingCard?.let { e -> CardDialog(e, { onSaveCard(it); editingCard = null }) { editingCard = null } }
}
