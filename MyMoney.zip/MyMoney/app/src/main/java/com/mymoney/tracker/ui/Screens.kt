package com.mymoney.tracker.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mymoney.tracker.data.*
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs

val Green = Color(0xFF2E7D32)
val Red = Color(0xFFC62828)

fun money(d: Double): String =
    (if (d < 0) "-₹" else "₹") + String.format(Locale("en", "IN"), "%,.2f", abs(d))

@Composable
fun StatCard(title: String, amount: Double, modifier: Modifier = Modifier, color: Color = Color.Unspecified) {
    Card(modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.labelMedium)
            Text(money(amount), style = MaterialTheme.typography.titleLarge, color = color, fontWeight = FontWeight.Bold)
        }
    }
}

// ---------------- ড্যাশবোর্ড ----------------
@Composable
fun DashboardScreen(accs: List<Account>, txns: List<Txn>) {
    val bal = remember(accs, txns) { accountBalances(accs, txns) }
    val cash = accs.filter { it.isCash }.sumOf { bal[it.id] ?: 0.0 }
    val bank = accs.filter { !it.isCash }.sumOf { bal[it.id] ?: 0.0 }
    val today = LocalDate.now()
    val ym = YearMonth.from(today)

    fun total(type: String, monthOnly: Boolean) = txns
        .filter { it.type == type && (!monthOnly || YearMonth.from(it.date()) == ym) }
        .sumOf { it.amount }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("আজ পর্যন্ত (${today.format(DateTimeFormatter.ofPattern("dd MMM yyyy"))})",
                style = MaterialTheme.typography.titleMedium)
        }
        item { StatCard("মোট ব্যালেন্স (সব অ্যাকাউন্ট + ক্যাশ)", cash + bank, Modifier.fillMaxWidth()) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("ক্যাশ ব্যালেন্স", cash, Modifier.weight(1f))
                StatCard("ব্যাংক ব্যালেন্স", bank, Modifier.weight(1f))
            }
        }
        item { Text("এই মাস", style = MaterialTheme.typography.titleSmall) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("আয়", total("INCOME", true), Modifier.weight(1f), Green)
                StatCard("ব্যয়", total("EXPENSE", true), Modifier.weight(1f), Red)
            }
        }
        item { Text("সর্বমোট (শুরু থেকে)", style = MaterialTheme.typography.titleSmall) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("আয়", total("INCOME", false), Modifier.weight(1f), Green)
                StatCard("ব্যয়", total("EXPENSE", false), Modifier.weight(1f), Red)
            }
        }
        item { Text("অ্যাকাউন্ট ভিত্তিক ব্যালেন্স", style = MaterialTheme.typography.titleSmall) }
        items(accs, key = { it.id }) { a ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(if (a.isCash) "Cash" else "${a.name} ••••${a.last5}")
                    Text(money(bal[a.id] ?: 0.0), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ---------------- দৈনিক হিসাব ----------------
@Composable
fun DailyScreen(accs: List<Account>, txns: List<Txn>, onEdit: (Txn) -> Unit) {
    var ym by remember { mutableStateOf(YearMonth.now()) }
    val inMonth = txns.filter { YearMonth.from(it.date()) == ym }
    val inc = inMonth.filter { it.type == "INCOME" }.sumOf { it.amount }
    val exp = inMonth.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    val names = accs.associate { it.id to it.name }
    val grouped = inMonth.groupBy { it.date() }.toSortedMap(compareByDescending { it })

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton({ ym = ym.minusMonths(1) }) { Text("◀") }
            Text(ym.format(DateTimeFormatter.ofPattern("MMMM yyyy")), style = MaterialTheme.typography.titleMedium)
            TextButton({ ym = ym.plusMonths(1) }) { Text("▶") }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("আয় ${money(inc)}", color = Green, fontWeight = FontWeight.Bold)
            Text("ব্যয় ${money(exp)}", color = Red, fontWeight = FontWeight.Bold)
            Text("সঞ্চয় ${money(inc - exp)}", fontWeight = FontWeight.Bold)
        }
        HorizontalDivider(Modifier.padding(top = 8.dp))
        if (inMonth.isEmpty()) {
            Text("এই মাসে কোনো এন্ট্রি নেই", Modifier.padding(16.dp))
        }
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            grouped.forEach { (day, list) ->
                item(key = day.toString()) {
                    val dIn = list.filter { it.type == "INCOME" }.sumOf { it.amount }
                    val dEx = list.filter { it.type == "EXPENSE" }.sumOf { it.amount }
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(day.format(DateTimeFormatter.ofPattern("EEE, dd MMM")), fontWeight = FontWeight.Bold)
                        Text("আয় ${money(dIn)} | ব্যয় ${money(dEx)}", style = MaterialTheme.typography.bodySmall)
                    }
                }
                items(list, key = { it.id }) { t ->
                    val (color, sign) = when (t.type) {
                        "INCOME" -> Green to "+"
                        "EXPENSE" -> Red to "-"
                        else -> Color.Gray to ""
                    }
                    val sub = if (t.type == "TRANSFER")
                        "${names[t.accountId]} → ${names[t.toAccountId]}"
                    else names[t.accountId] ?: ""
                    Card(Modifier.fillMaxWidth().clickable { onEdit(t) }) {
                        Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(t.category.ifEmpty { "Other" }, fontWeight = FontWeight.Medium)
                                Text(listOf(sub, t.note).filter { it.isNotBlank() }.joinToString(" • "),
                                    style = MaterialTheme.typography.bodySmall)
                            }
                            Text(sign + money(t.amount), color = color, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// ---------------- অ্যাকাউন্ট ----------------
@Composable
fun AccountsScreen(accs: List<Account>, txns: List<Txn>, onSave: (Account) -> Unit) {
    val bal = remember(accs, txns) { accountBalances(accs, txns) }
    var editing by remember { mutableStateOf<Account?>(null) }
    var adding by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(accs, key = { it.id }) { a ->
            Card(Modifier.fillMaxWidth().clickable { editing = a }) {
                Row(Modifier.padding(14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(a.name, fontWeight = FontWeight.Bold)
                        Text(if (a.isCash) "ক্যাশ" else "A/c ••••${a.last5}", style = MaterialTheme.typography.bodySmall)
                    }
                    Text(money(bal[a.id] ?: 0.0), fontWeight = FontWeight.Bold)
                }
            }
        }
        item { Button({ adding = true }, Modifier.fillMaxWidth()) { Text("+ নতুন ব্যাংক অ্যাকাউন্ট") } }
        item { Text("কার্ডে ট্যাপ করে নাম বা শুরুর ব্যালেন্স বদলানো যাবে।", style = MaterialTheme.typography.bodySmall) }
    }
    if (adding) AccountDialog(null, { onSave(it); adding = false }) { adding = false }
    editing?.let { e -> AccountDialog(e, { onSave(it); editing = null }) { editing = null } }
}
