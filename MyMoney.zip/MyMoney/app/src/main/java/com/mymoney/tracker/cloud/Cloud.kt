package com.mymoney.tracker.cloud

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FirebaseFirestore
import com.mymoney.tracker.data.Account
import com.mymoney.tracker.data.Budget
import com.mymoney.tracker.data.CreditCard
import com.mymoney.tracker.data.Debtor
import com.mymoney.tracker.data.DebtorPayment
import com.mymoney.tracker.data.Planned
import com.mymoney.tracker.data.Txn
import com.mymoney.tracker.data.sha256
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject

/** Firebase লগইন (ইমেইল+পাসওয়ার্ড) ও Firestore ব্যাকআপ/রিস্টোর */
object Cloud {
    class ProfileData(val name: String, val mobile: String, val dob: String)

    class BackupData(
        val accs: List<Account>,
        val cards: List<CreditCard>,
        val txns: List<Txn>,
        val seen: List<String>,
        val budgets: List<Budget>,
        val debtors: List<Debtor>,
        val payments: List<DebtorPayment>,
        val planned: List<Planned>,
        val profile: ProfileData
    )

    fun configured(ctx: Context): Boolean = FirebaseApp.getApps(ctx).isNotEmpty()

    fun email(ctx: Context): String? = try {
        if (!configured(ctx)) null else FirebaseAuth.getInstance().currentUser?.email
    } catch (e: Exception) {
        null
    }

    fun displayName(): String? = try {
        FirebaseAuth.getInstance().currentUser?.displayName
    } catch (e: Exception) {
        null
    }

    suspend fun setName(name: String) {
        val u = FirebaseAuth.getInstance().currentUser ?: return
        u.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(name).build()).await()
    }

    suspend fun signIn(email: String, pass: String) {
        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, pass).await()
    }

    suspend fun signUp(email: String, pass: String) {
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, pass).await()
    }

    suspend fun reset(email: String) {
        FirebaseAuth.getInstance().sendPasswordResetEmail(email).await()
    }

    /** ইমেইলে আসা রিসেট কোড/লিংয়ের কোড যাচাই করে; সফল হলে অ্যাকাউন্টের ইমেইল ফেরত দেয় */
    suspend fun verifyResetCode(code: String): String =
        FirebaseAuth.getInstance().verifyPasswordResetCode(code).await()

    suspend fun confirmReset(code: String, newPass: String) {
        FirebaseAuth.getInstance().confirmPasswordReset(code, newPass).await()
    }

    fun signOut() {
        FirebaseAuth.getInstance().signOut()
    }

    // ---------- পাসওয়ার্ড রিসেটের আগে মোবাইল + জন্মতারিখ মেলানো ----------
    private fun checkId(email: String) = sha256("id|" + email.trim().lowercase())
    private fun checkHash(email: String, mobile: String, dob: String) =
        sha256("h|" + email.trim().lowercase() + "|" + mobile + "|" + dob)

    /** লগইন করা অবস্থায় মোবাইল + জন্মতারিখের hash সেভ করে (আসল নম্বর/তারিখ সেভ হয় না) */
    suspend fun saveResetCheck(email: String, mobile: String, dob: String) {
        val u = FirebaseAuth.getInstance().currentUser ?: return
        if (email.isBlank() || mobile.isBlank() || dob.isBlank()) return
        FirebaseFirestore.getInstance().collection("resetCheck").document(checkId(email))
            .set(hashMapOf("h" to checkHash(email, mobile, dob), "ownerUid" to u.uid)).await()
    }

    /** 0 = মিলেছে, 1 = মেলেনি, 2 = এই অ্যাকাউন্টে মোবাইল/জন্মতারিখ সেট করা নেই */
    suspend fun verifyResetCheck(email: String, mobile: String, dob: String): Int {
        val d = FirebaseFirestore.getInstance().collection("resetCheck").document(checkId(email)).get().await()
        if (!d.exists()) return 2
        return if (d.getString("h") == checkHash(email, mobile, dob)) 0 else 1
    }

    // ---------- ব্যাকআপ ----------
    private fun backupCol() = FirebaseFirestore.getInstance()
        .collection("users")
        .document(FirebaseAuth.getInstance().currentUser?.uid ?: throw IllegalStateException("Not logged in"))
        .collection("backup")

    suspend fun backup(d: BackupData) {
        val col = backupCol()
        col.document("accounts").set(hashMapOf("json" to accsJson(d.accs))).await()
        col.document("cards").set(hashMapOf("json" to cardsJson(d.cards))).await()
        col.document("budgets").set(hashMapOf("json" to budgetsJson(d.budgets))).await()
        col.document("debtors").set(hashMapOf("json" to debtorsJson(d.debtors))).await()
        col.document("debtor_payments").set(hashMapOf("json" to paymentsJson(d.payments))).await()
        col.document("planned").set(hashMapOf("json" to plannedJson(d.planned))).await()
        col.document("profile").set(
            hashMapOf("name" to d.profile.name, "mobile" to d.profile.mobile, "dob" to d.profile.dob)
        ).await()
        val tChunks = d.txns.chunked(800)
        tChunks.forEachIndexed { i, c ->
            col.document("txns_$i").set(hashMapOf("json" to txnsJson(c))).await()
        }
        val sChunks = d.seen.chunked(1000)
        sChunks.forEachIndexed { i, c ->
            col.document("seen_$i").set(hashMapOf("json" to JSONArray(c).toString())).await()
        }
        col.document("meta").set(
            hashMapOf(
                "updatedAt" to System.currentTimeMillis(),
                "txnChunks" to tChunks.size,
                "seenChunks" to sChunks.size,
                "txnCount" to d.txns.size
            )
        ).await()
    }

    suspend fun fetch(): BackupData? {
        val col = backupCol()
        val meta = col.document("meta").get().await()
        if (!meta.exists()) return null
        val tc = (meta.getLong("txnChunks") ?: 0L).toInt()
        val sc = (meta.getLong("seenChunks") ?: 0L).toInt()
        val accs = parseAccs(col.document("accounts").get().await().getString("json") ?: "[]")
        val cards = parseCards(col.document("cards").get().await().getString("json") ?: "[]")
        val budgets = parseBudgets(col.document("budgets").get().await().getString("json") ?: "[]")
        val debtors = parseDebtors(col.document("debtors").get().await().getString("json") ?: "[]")
        val pays = parsePayments(col.document("debtor_payments").get().await().getString("json") ?: "[]")
        val planned = parsePlanned(col.document("planned").get().await().getString("json") ?: "[]")
        val pf = col.document("profile").get().await()
        val profile = ProfileData(pf.getString("name") ?: "", pf.getString("mobile") ?: "", pf.getString("dob") ?: "")
        val txns = ArrayList<Txn>()
        for (i in 0 until tc) {
            txns.addAll(parseTxns(col.document("txns_$i").get().await().getString("json") ?: "[]"))
        }
        val seen = ArrayList<String>()
        for (i in 0 until sc) {
            val arr = JSONArray(col.document("seen_$i").get().await().getString("json") ?: "[]")
            for (k in 0 until arr.length()) seen.add(arr.getString(k))
        }
        return BackupData(accs, cards, txns, seen, budgets, debtors, pays, planned, profile)
    }

    // ---------- JSON ----------
    private fun accsJson(l: List<Account>): String {
        val a = JSONArray()
        l.forEach {
            val o = JSONObject().put("id", it.id).put("name", it.name).put("last5", it.last5)
                .put("openingBalance", it.openingBalance).put("isCash", it.isCash)
                .put("smsBalanceAt", it.smsBalanceAt)
            val sb = it.smsBalance
            if (sb != null) o.put("smsBalance", sb)
            a.put(o)
        }
        return a.toString()
    }

    private fun cardsJson(l: List<CreditCard>): String {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("id", it.id).put("bankName", it.bankName).put("last4", it.last4)
                    .put("openingDue", it.openingDue).put("creditLimit", it.creditLimit)
            )
        }
        return a.toString()
    }

    private fun budgetsJson(l: List<Budget>): String {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("category", it.category).put("limitAmount", it.limitAmount)) }
        return a.toString()
    }

    private fun debtorsJson(l: List<Debtor>): String {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("id", it.id).put("name", it.name).put("mobile", it.mobile)
                    .put("amount", it.amount).put("dateMillis", it.dateMillis)
                    .put("ptpMillis", it.ptpMillis ?: JSONObject.NULL)
                    .put("closed", it.closed).put("note", it.note)
            )
        }
        return a.toString()
    }

    private fun paymentsJson(l: List<DebtorPayment>): String {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("id", it.id).put("debtorId", it.debtorId).put("amount", it.amount)
                    .put("dateMillis", it.dateMillis).put("isFull", it.isFull)
            )
        }
        return a.toString()
    }

    private fun plannedJson(l: List<Planned>): String {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("id", it.id).put("category", it.category).put("note", it.note)
                    .put("amount", it.amount).put("dueMillis", it.dueMillis).put("done", it.done)
            )
        }
        return a.toString()
    }

    private fun txnsJson(l: List<Txn>): String {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("id", it.id).put("type", it.type).put("amount", it.amount)
                    .put("accountId", it.accountId)
                    .put("toAccountId", it.toAccountId ?: JSONObject.NULL)
                    .put("cardId", it.cardId ?: JSONObject.NULL)
                    .put("category", it.category).put("note", it.note)
                    .put("dateMillis", it.dateMillis).put("source", it.source)
            )
        }
        return a.toString()
    }

    private fun parseAccs(s: String): List<Account> {
        val a = JSONArray(s)
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            val sb = o.optDouble("smsBalance", Double.NaN)
            Account(
                o.getLong("id"), o.getString("name"), o.getString("last5"),
                o.getDouble("openingBalance"), o.getBoolean("isCash"),
                if (sb.isNaN()) null else sb, o.optLong("smsBalanceAt", 0L)
            )
        }
    }

    private fun parseCards(s: String): List<CreditCard> {
        val a = JSONArray(s)
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            CreditCard(o.getLong("id"), o.getString("bankName"), o.getString("last4"),
                o.getDouble("openingDue"), o.optDouble("creditLimit", 0.0))
        }
    }

    private fun parseBudgets(s: String): List<Budget> {
        val a = JSONArray(s)
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            Budget(o.getString("category"), o.getDouble("limitAmount"))
        }
    }

    private fun parseDebtors(s: String): List<Debtor> {
        val a = JSONArray(s)
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            Debtor(
                id = o.getLong("id"), name = o.getString("name"), mobile = o.getString("mobile"),
                amount = o.getDouble("amount"), dateMillis = o.getLong("dateMillis"),
                ptpMillis = if (o.isNull("ptpMillis")) null else o.getLong("ptpMillis"),
                closed = o.getBoolean("closed"), note = o.getString("note")
            )
        }
    }

    private fun parsePayments(s: String): List<DebtorPayment> {
        val a = JSONArray(s)
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            DebtorPayment(o.getLong("id"), o.getLong("debtorId"), o.getDouble("amount"),
                o.getLong("dateMillis"), o.getBoolean("isFull"))
        }
    }

    private fun parsePlanned(s: String): List<Planned> {
        val a = JSONArray(s)
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            Planned(o.getLong("id"), o.getString("category"), o.getString("note"),
                o.getDouble("amount"), o.getLong("dueMillis"), o.getBoolean("done"))
        }
    }

    private fun parseTxns(s: String): List<Txn> {
        val a = JSONArray(s)
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            Txn(
                id = o.getLong("id"),
                type = o.getString("type"),
                amount = o.getDouble("amount"),
                accountId = o.getLong("accountId"),
                toAccountId = if (o.isNull("toAccountId")) null else o.getLong("toAccountId"),
                cardId = if (o.isNull("cardId")) null else o.getLong("cardId"),
                category = o.getString("category"),
                note = o.getString("note"),
                dateMillis = o.getLong("dateMillis"),
                source = o.getString("source")
            )
        }
    }
}
