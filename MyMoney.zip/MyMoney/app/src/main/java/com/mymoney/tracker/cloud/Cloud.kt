package com.mymoney.tracker.cloud

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.ActionCodeSettings
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FirebaseFirestore
import com.mymoney.tracker.data.Account
import com.mymoney.tracker.data.Budget
import com.mymoney.tracker.data.CreditCard
import com.mymoney.tracker.data.Debtor
import com.mymoney.tracker.data.DebtorPayment
import com.mymoney.tracker.data.Planned
import com.mymoney.tracker.data.Txn
import com.mymoney.tracker.data.sha256
import com.google.firebase.firestore.CollectionReference
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject

/** Firebase লগইন (ইমেইল+পাসওয়ার্ড) ও Firestore ব্যাকআপ/রিস্টোর */
object Cloud {
    /** মাস্টার অ্যাপের ডেভেলপার ইমেইল (Firestore rules-এও এই ইমেইল বসাতে হবে) */
    const val DEV_EMAIL = "sahinakterrana@gmail.com"

    class DirEntry(val uid: String, val email: String, val mobile: String, val name: String)

    class ProfileData(val name: String, val mobile: String, val dob: String)

    class BackupData(
        val accs: List<Account>,
        val cards: List<CreditCard>,
        val txns: List<Txn>,
        val seen: List<String>,
        val budgets: List<Budget>,
        val debtors: List<Debtor>,
        val payments: List<DebtorPayment>,
        val planned: List<Planned>,
        val profile: ProfileData
    )

    fun configured(ctx: Context): Boolean = FirebaseApp.getApps(ctx).isNotEmpty()

    fun email(ctx: Context): String? = try {
        if (!configured(ctx)) null else FirebaseAuth.getInstance().currentUser?.email
    } catch (e: Exception) {
        null
    }

    fun displayName(): String? = try {
        FirebaseAuth.getInstance().currentUser?.displayName
    } catch (e: Exception) {
        null
    }

    suspend fun setName(name: String) {
        val u = FirebaseAuth.getInstance().currentUser ?: return
        u.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(name).build()).await()
    }

    suspend fun signIn(email: String, pass: String) {
        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, pass).await()
    }

    suspend fun signUp(email: String, pass: String) {
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, pass).await()
    }

    suspend fun reset(email: String) {
        FirebaseAuth.getInstance().sendPasswordResetEmail(email).await()
    }

    /** ইমেইলে আসা রিসেট কোড/লিংয়ের কোড যাচাই করে; সফল হলে অ্যাকাউন্টের ইমেইল ফেরত দেয় */
    suspend fun verifyResetCode(code: String): String =
        FirebaseAuth.getInstance().verifyPasswordResetCode(code).await()

    suspend fun confirmReset(code: String, newPass: String) {
        FirebaseAuth.getInstance().confirmPasswordReset(code, newPass).await()
    }

    fun signOut() {
        FirebaseAuth.getInstance().signOut()
    }

    // ---------- পাসওয়ার্ড রিসেটের আগে মোবাইল + জন্মতারিখ মেলানো ----------
    private fun checkId(email: String) = sha256("id|" + email.trim().lowercase())
    private fun checkHash(email: String, mobile: String, dob: String) =
        sha256("h|" + email.trim().lowercase() + "|" + mobile + "|" + dob)

    /** লগইন করা অবস্থায় মোবাইল + জন্মতারিখের hash সেভ করে (আসল নম্বর/তারিখ সেভ হয় না) */
    suspend fun saveResetCheck(email: String, mobile: String, dob: String) {
        val u = FirebaseAuth.getInstance().currentUser ?: return
        if (email.isBlank() || mobile.isBlank() || dob.isBlank()) return
        FirebaseFirestore.getInstance().collection("resetCheck").document(checkId(email))
            .set(hashMapOf("h" to checkHash(email, mobile, dob), "ownerUid" to u.uid)).await()
    }

    /** 0 = মিলেছে, 1 = মেলেনি, 2 = এই অ্যাকাউন্টে মোবাইল/জন্মতারিখ সেট করা নেই */
    suspend fun verifyResetCheck(email: String, mobile: String, dob: String): Int {
        val d = FirebaseFirestore.getInstance().collection("resetCheck").document(checkId(email)).get().await()
        if (!d.exists()) return 2
        return if (d.getString("h") == checkHash(email, mobile, dob)) 0 else 1
    }

    // ---------- ডেভেলপার লগইন: ইমেইলে আসা সাইন-ইন লিংক (OTP-র মতো কাজ করে) ----------
    suspend fun sendSignInLink(email: String) {
        val project = FirebaseApp.getInstance().options.projectId ?: ""
        val s = ActionCodeSettings.newBuilder()
            .setUrl("https://$project.firebaseapp.com")
            .setHandleCodeInApp(true)
            .build()
        FirebaseAuth.getInstance().sendSignInLinkToEmail(email, s).await()
    }

    suspend fun signInWithLink(email: String, link: String) {
        val auth = FirebaseAuth.getInstance()
        if (!auth.isSignInWithEmailLink(link)) throw IllegalArgumentException("This is not a valid sign-in link")
        auth.signInWithEmailLink(email, link).await()
    }

    fun emailVerified(): Boolean = try {
        FirebaseAuth.getInstance().currentUser?.isEmailVerified == true
    } catch (e: Exception) {
        false
    }

    fun uid(): String? = try {
        FirebaseAuth.getInstance().currentUser?.uid
    } catch (e: Exception) {
        null
    }

    // ---------- ইউজার ডিরেক্টরি: মোবাইল/ইমেইল থেকে ইউজারের আইডি খোঁজার জন্য (শুধু অ্যাডমিন পড়তে পারে) ----------
    suspend fun saveDirectory(uid: String, email: String, mobile: String, name: String) {
        val col = FirebaseFirestore.getInstance().collection("directory")
        val data = hashMapOf<String, Any>(
            "uid" to uid, "email" to email.trim().lowercase(), "mobile" to mobile, "name" to name
        )
        if (email.isNotBlank()) col.document("e_" + email.trim().lowercase()).set(data).await()
        if (mobile.isNotBlank()) col.document("m_$mobile").set(data).await()
    }

    suspend fun lookup(byMobile: Boolean, value: String): DirEntry? {
        val key = if (byMobile) "m_" + value.filter { it.isDigit() }.takeLast(10) else "e_" + value.trim().lowercase()
        val d = FirebaseFirestore.getInstance().collection("directory").document(key).get().await()
        if (!d.exists()) return null
        val uid = d.getString("uid") ?: return null
        return DirEntry(uid, d.getString("email") ?: "", d.getString("mobile") ?: "", d.getString("name") ?: "")
    }

    // ---------- ব্যাকআপ: শুধু বদলানো ডকুমেন্টই আপলোড হয়, তাই নতুন এন্ট্রি প্রায় সাথে সাথে সিঙ্ক হয় ----------
    private val lastHash = HashMap<String, Int>()
    private const val CHUNK = 500L
    private const val HEX = "0123456789abcdef"

    /** অ্যাকাউন্ট বদলালে বা লগআউটে ক্যাশ মুছে ফেলা */
    fun resetCache() {
        lastHash.clear()
    }

    private fun ownerUid(uid: String?): String =
        uid ?: FirebaseAuth.getInstance().currentUser?.uid ?: throw IllegalStateException("Not logged in")

    private fun backupCol(uid: String?) = FirebaseFirestore.getInstance()
        .collection("users")
        .document(ownerUid(uid))
        .collection("backup")

    private suspend fun put(col: CollectionReference, scope: String, doc: String, fields: HashMap<String, Any>) {
        val key = "$scope/$doc"
        val h = fields.toString().hashCode()
        if (lastHash[key] == h) return
        col.document(doc).set(fields).await()
        lastHash[key] = h
    }

    /** uid = null হলে নিজের ডেটা; অ্যাডমিন অন্য ইউজারের uid দিয়ে সেই ইউজারের ডেটা লেখে। ফেরত দেয় মেটার সময়। */
    suspend fun backup(d: BackupData, uid: String? = null, by: String = "user"): Long {
        val scope = ownerUid(uid)
        var stamp = 0L
        coroutineScope {
            val col = backupCol(uid)
            val jobs = ArrayList<Deferred<Unit>>()
            fun add(doc: String, json: String) {
                jobs.add(async { put(col, scope, doc, hashMapOf<String, Any>("json" to json)) })
            }
            add("accounts", accsJson(d.accs))
            add("cards", cardsJson(d.cards))
            add("budgets", budgetsJson(d.budgets))
            add("debtors", debtorsJson(d.debtors))
            add("debtor_payments", paymentsJson(d.payments))
            add("planned", plannedJson(d.planned))
            jobs.add(async {
                put(col, scope, "profile",
                    hashMapOf<String, Any>("name" to d.profile.name, "mobile" to d.profile.mobile, "dob" to d.profile.dob))
            })
            // এন্ট্রি: আইডি অনুযায়ী ৫০০টির খণ্ডে (নতুন এন্ট্রিতে শুধু শেষ খণ্ড বদলায়)
            val maxId = d.txns.maxOfOrNull { it.id } ?: 0L
            val tc = (maxId / CHUNK).toInt() + 1
            val byChunk = d.txns.groupBy { (it.id / CHUNK).toInt() }
            for (i in 0 until tc) add("txns_$i", txnsJson(byChunk[i] ?: emptyList()))
            // SMS hash: প্রথম হেক্স অক্ষর অনুযায়ী ১৬ ভাগে
            val seenBy = d.seen.groupBy { it.take(1) }
            for (c in HEX) add("seen_$c", JSONArray(seenBy[c.toString()] ?: emptyList<String>()).toString())
            jobs.awaitAll()
            stamp = System.currentTimeMillis()
            col.document("meta").set(
                hashMapOf<String, Any>(
                    "updatedAt" to stamp,
                    "editedBy" to by,
                    "txnChunks" to tc,
                    "txnCount" to d.txns.size
                )
            ).await()
        }
        return stamp
    }

    /** নিজের ডেটার মেটা: (সর্বশেষ বদলের সময়, কে বদলেছে: "user" বা "admin") */
    suspend fun metaInfo(): Pair<Long, String>? {
        val m = backupCol(null).document("meta").get().await()
        if (!m.exists()) return null
        return Pair(m.getLong("updatedAt") ?: 0L, m.getString("editedBy") ?: "user")
    }

    suspend fun fetch(uid: String? = null): BackupData? {
        val col = backupCol(uid)
        val meta = col.document("meta").get().await()
        if (!meta.exists()) return null
        val tc = (meta.getLong("txnChunks") ?: 0L).toInt()
        val accs = parseAccs(col.document("accounts").get().await().getString("json") ?: "[]")
        val cards = parseCards(col.document("cards").get().await().getString("json") ?: "[]")
        val budgets = parseBudgets(col.document("budgets").get().await().getString("json") ?: "[]")
        val debtors = parseDebtors(col.document("debtors").get().await().getString("json") ?: "[]")
        val pays = parsePayments(col.document("debtor_payments").get().await().getString("json") ?: "[]")
        val planned = parsePlanned(col.document("planned").get().await().getString("json") ?: "[]")
        val pf = col.document("profile").get().await()
        val profile = ProfileData(pf.getString("name") ?: "", pf.getString("mobile") ?: "", pf.getString("dob") ?: "")
        val txns = ArrayList<Txn>()
        for (i in 0 until tc) {
            txns.addAll(parseTxns(col.document("txns_$i").get().await().getString("json") ?: "[]"))
        }
        val seen = ArrayList<String>()
        for (c in HEX) {
            val arr = JSONArray(col.document("seen_$c").get().await().getString("json") ?: "[]")
            for (k in 0 until arr.length()) seen.add(arr.getString(k))
        }
        return BackupData(accs, cards, txns, seen, budgets, debtors, pays, planned, profile)
    }

    // ---------- JSON ----------
    private fun accsJson(l: List<Account>): String {
        val a = JSONArray()
        l.forEach {
            val o = JSONObject().put("id", it.id).put("name", it.name).put("last5", it.last5)
                .put("openingBalance", it.openingBalance).put("isCash", it.isCash)
                .put("smsBalanceAt", it.smsBalanceAt)
            val sb = it.smsBalance
            if (sb != null) o.put("smsBalance", sb)
            a.put(o)
        }
        return a.toString()
    }

    private fun cardsJson(l: List<CreditCard>): String {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("id", it.id).put("bankName", it.bankName).put("last4", it.last4)
                    .put("openingDue", it.openingDue).put("creditLimit", it.creditLimit)
            )
        }
        return a.toString()
    }

    private fun budgetsJson(l: List<Budget>): String {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("category", it.category).put("limitAmount", it.limitAmount)) }
        return a.toString()
    }

    private fun debtorsJson(l: List<Debtor>): String {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("id", it.id).put("name", it.name).put("mobile", it.mobile)
                    .put("amount", it.amount).put("dateMillis", it.dateMillis)
                    .put("ptpMillis", it.ptpMillis ?: JSONObject.NULL)
                    .put("closed", it.closed).put("note", it.note)
            )
        }
        return a.toString()
    }

    private fun paymentsJson(l: List<DebtorPayment>): String {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("id", it.id).put("debtorId", it.debtorId).put("amount", it.amount)
                    .put("dateMillis", it.dateMillis).put("isFull", it.isFull)
            )
        }
        return a.toString()
    }

    private fun plannedJson(l: List<Planned>): String {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("id", it.id).put("category", it.category).put("note", it.note)
                    .put("amount", it.amount).put("dueMillis", it.dueMillis).put("done", it.done)
                    .put("hasDate", it.hasDate)
            )
        }
        return a.toString()
    }

    private fun txnsJson(l: List<Txn>): String {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("id", it.id).put("type", it.type).put("amount", it.amount)
                    .put("accountId", it.accountId)
                    .put("toAccountId", it.toAccountId ?: JSONObject.NULL)
                    .put("cardId", it.cardId ?: JSONObject.NULL)
                    .put("category", it.category).put("note", it.note)
                    .put("dateMillis", it.dateMillis).put("source", it.source)
            )
        }
        return a.toString()
    }

    private fun parseAccs(s: String): List<Account> {
        val a = JSONArray(s)
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            val sb = o.optDouble("smsBalance", Double.NaN)
            Account(
                o.getLong("id"), o.getString("name"), o.getString("last5"),
                o.getDouble("openingBalance"), o.getBoolean("isCash"),
                if (sb.isNaN()) null else sb, o.optLong("smsBalanceAt", 0L)
            )
        }
    }

    private fun parseCards(s: String): List<CreditCard> {
        val a = JSONArray(s)
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            CreditCard(o.getLong("id"), o.getString("bankName"), o.getString("last4"),
                o.getDouble("openingDue"), o.optDouble("creditLimit", 0.0))
        }
    }

    private fun parseBudgets(s: String): List<Budget> {
        val a = JSONArray(s)
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            Budget(o.getString("category"), o.getDouble("limitAmount"))
        }
    }

    private fun parseDebtors(s: String): List<Debtor> {
        val a = JSONArray(s)
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            Debtor(
                id = o.getLong("id"), name = o.getString("name"), mobile = o.getString("mobile"),
                amount = o.getDouble("amount"), dateMillis = o.getLong("dateMillis"),
                ptpMillis = if (o.isNull("ptpMillis")) null else o.getLong("ptpMillis"),
                closed = o.getBoolean("closed"), note = o.getString("note")
            )
        }
    }

    private fun parsePayments(s: String): List<DebtorPayment> {
        val a = JSONArray(s)
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            DebtorPayment(o.getLong("id"), o.getLong("debtorId"), o.getDouble("amount"),
                o.getLong("dateMillis"), o.getBoolean("isFull"))
        }
    }

    private fun parsePlanned(s: String): List<Planned> {
        val a = JSONArray(s)
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            Planned(o.getLong("id"), o.getString("category"), o.getString("note"),
                o.getDouble("amount"), o.getLong("dueMillis"), o.getBoolean("done"), o.optBoolean("hasDate", true))
        }
    }

    private fun parseTxns(s: String): List<Txn> {
        val a = JSONArray(s)
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            Txn(
                id = o.getLong("id"),
                type = o.getString("type"),
                amount = o.getDouble("amount"),
                accountId = o.getLong("accountId"),
                toAccountId = if (o.isNull("toAccountId")) null else o.getLong("toAccountId"),
                cardId = if (o.isNull("cardId")) null else o.getLong("cardId"),
                category = o.getString("category"),
                note = o.getString("note"),
                dateMillis = o.getLong("dateMillis"),
                source = o.getString("source")
            )
        }
    }
}
