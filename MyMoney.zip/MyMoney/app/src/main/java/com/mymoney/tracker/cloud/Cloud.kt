package com.mymoney.tracker.cloud

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FirebaseFirestore
import com.mymoney.tracker.data.Account
import com.mymoney.tracker.data.Budget
import com.mymoney.tracker.data.CreditCard
import com.mymoney.tracker.data.Txn
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject

/** Firebase লগইন (ইমেইল+পাসওয়ার্ড) ও Firestore ব্যাকআপ/রিস্টোর */
object Cloud {
    class Snapshot(
        val accs: List<Account>,
        val cards: List<CreditCard>,
        val txns: List<Txn>,
        val seen: List<String>,
        val budgets: List<Budget>
    )

    fun configured(ctx: Context): Boolean = FirebaseApp.getApps(ctx).isNotEmpty()

    fun email(ctx: Context): String? = try {
        if (!configured(ctx)) null else FirebaseAuth.getInstance().currentUser?.email
    } catch (e: Exception) {
        null
    }

    fun displayName(): String? = try {
        FirebaseAuth.getInstance().currentUser?.displayName
    } catch (e: Exception) {
        null
    }

    suspend fun setName(name: String) {
        val u = FirebaseAuth.getInstance().currentUser ?: return
        u.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(name).build()).await()
    }

    suspend fun signIn(email: String, pass: String) {
        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, pass).await()
    }

    suspend fun signUp(email: String, pass: String) {
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, pass).await()
    }

    suspend fun reset(email: String) {
        FirebaseAuth.getInstance().sendPasswordResetEmail(email).await()
    }

    fun signOut() {
        FirebaseAuth.getInstance().signOut()
    }

    private fun backupCol() = FirebaseFirestore.getInstance()
        .collection("users")
        .document(FirebaseAuth.getInstance().currentUser?.uid ?: throw IllegalStateException("Not logged in"))
        .collection("backup")

    suspend fun backup(
        accs: List<Account>, cards: List<CreditCard>, txns: List<Txn>, seen: List<String>, budgets: List<Budget>
    ) {
        val col = backupCol()
        col.document("accounts").set(hashMapOf("json" to accsJson(accs))).await()
        col.document("cards").set(hashMapOf("json" to cardsJson(cards))).await()
        col.document("budgets").set(hashMapOf("json" to budgetsJson(budgets))).await()
        val tChunks = txns.chunked(800)
        tChunks.forEachIndexed { i, c ->
            col.document("txns_$i").set(hashMapOf("json" to txnsJson(c))).await()
        }
        val sChunks = seen.chunked(1000)
        sChunks.forEachIndexed { i, c ->
            col.document("seen_$i").set(hashMapOf("json" to JSONArray(c).toString())).await()
        }
        col.document("meta").set(
            hashMapOf(
                "updatedAt" to System.currentTimeMillis(),
                "txnChunks" to tChunks.size,
                "seenChunks" to sChunks.size,
                "txnCount" to txns.size
            )
        ).await()
    }

    suspend fun fetch(): Snapshot? {
        val col = backupCol()
        val meta = col.document("meta").get().await()
        if (!meta.exists()) return null
        val tc = (meta.getLong("txnChunks") ?: 0L).toInt()
        val sc = (meta.getLong("seenChunks") ?: 0L).toInt()
        val accs = parseAccs(col.document("accounts").get().await().getString("json") ?: "[]")
        val cards = parseCards(col.document("cards").get().await().getString("json") ?: "[]")
        val budgets = parseBudgets(col.document("budgets").get().await().getString("json") ?: "[]")
        val txns = ArrayList<Txn>()
        for (i in 0 until tc) {
            txns.addAll(parseTxns(col.document("txns_$i").get().await().getString("json") ?: "[]"))
        }
        val seen = ArrayList<String>()
        for (i in 0 until sc) {
            val arr = JSONArray(col.document("seen_$i").get().await().getString("json") ?: "[]")
            for (k in 0 until arr.length()) seen.add(arr.getString(k))
        }
        return Snapshot(accs, cards, txns, seen, budgets)
    }

    // ---------- JSON ----------
    private fun accsJson(l: List<Account>): String {
        val a = JSONArray()
        l.forEach {
            val o = JSONObject().put("id", it.id).put("name", it.name).put("last5", it.last5)
                .put("openingBalance", it.openingBalance).put("isCash", it.isCash)
                .put("smsBalanceAt", it.smsBalanceAt)
            val sb = it.smsBalance
            if (sb != null) o.put("smsBalance", sb)
            a.put(o)
        }
        return a.toString()
    }

    private fun cardsJson(l: List<CreditCard>): String {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("id", it.id).put("bankName", it.bankName).put("last4", it.last4)
                    .put("openingDue", it.openingDue).put("creditLimit", it.creditLimit)
            )
        }
        return a.toString()
    }

    private fun budgetsJson(l: List<Budget>): String {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("category", it.category).put("limitAmount", it.limitAmount)) }
        return a.toString()
    }

    private fun txnsJson(l: List<Txn>): String {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("id", it.id).put("type", it.type).put("amount", it.amount)
                    .put("accountId", it.accountId)
                    .put("toAccountId", it.toAccountId ?: JSONObject.NULL)
                    .put("cardId", it.cardId ?: JSONObject.NULL)
                    .put("category", it.category).put("note", it.note)
                    .put("dateMillis", it.dateMillis).put("source", it.source)
            )
        }
        return a.toString()
    }

    private fun parseAccs(s: String): List<Account> {
        val a = JSONArray(s)
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            val sb = o.optDouble("smsBalance", Double.NaN)
            Account(
                o.getLong("id"), o.getString("name"), o.getString("last5"),
                o.getDouble("openingBalance"), o.getBoolean("isCash"),
                if (sb.isNaN()) null else sb, o.optLong("smsBalanceAt", 0L)
            )
        }
    }

    private fun parseCards(s: String): List<CreditCard> {
        val a = JSONArray(s)
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            CreditCard(o.getLong("id"), o.getString("bankName"), o.getString("last4"),
                o.getDouble("openingDue"), o.optDouble("creditLimit", 0.0))
        }
    }

    private fun parseBudgets(s: String): List<Budget> {
        val a = JSONArray(s)
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            Budget(o.getString("category"), o.getDouble("limitAmount"))
        }
    }

    private fun parseTxns(s: String): List<Txn> {
        val a = JSONArray(s)
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            Txn(
                id = o.getLong("id"),
                type = o.getString("type"),
                amount = o.getDouble("amount"),
                accountId = o.getLong("accountId"),
                toAccountId = if (o.isNull("toAccountId")) null else o.getLong("toAccountId"),
                cardId = if (o.isNull("cardId")) null else o.getLong("cardId"),
                category = o.getString("category"),
                note = o.getString("note"),
                dateMillis = o.getLong("dateMillis"),
                source = o.getString("source")
            )
        }
    }
}
